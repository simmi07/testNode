<?php

return [
    'options' => [
    	'login' => 'Dashboard Login',
        'title' => 'Manage Users',
        'newUser' => 'Create New User',
        'edit' => 'Edit User',
        'accTitle' => 'Super Admin Portal Accounts - New',
        'viewAcc' => 'Manage Accounts',
        'editAcc' => 'Super Admin Portal Account - Edit',
        'audit' => 'Audit Log',
        'newNoti' => 'Create New Notification',
        'viewNotifi' => 'Notifications',
        'editNotifi' => 'Edit Notification',
        'config' => 'Configuration',
        'userPortal' => "Welcome to Kissinger's Dashboard Web-Stor Portal",
        'userLogin' => 'Web-Stor Login'
    ]
];