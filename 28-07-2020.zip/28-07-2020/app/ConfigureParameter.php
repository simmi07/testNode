<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class ConfigureParameter extends Authenticatable
{
    use Notifiable;
    
    protected $guard = 'configure_parameters';

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'notification_id', 'auth_id', 'parameter', 'account_id', 'description', 'parameter_level', 'parameter_type', 'parameter_value', 'parameter_status',
    ];
}
