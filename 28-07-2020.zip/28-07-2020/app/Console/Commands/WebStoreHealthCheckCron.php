<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Notifications\KissingerNotifications;
use App\Helper\Helper;
use App\Configuration;
use Notification;
use SoapClient;
use App\KaiConnectionStatus;
use DB;

class WebStoreHealthCheckCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'webstore:healthCheck';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send email to users';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $qry = DB::table('kaiconnection_with_accounts')->select('account_id')->get()->toArray();
        $accId = [];       
        foreach($qry as $data)
        {
            $accId[] = $data->account_id;
        }
        $connQry = DB::table('kaiconnection_with_accounts')->select('id', 'name', 'connectionstring', 'phpoverlay', 'username', 'password', 'account_id', 'dashboard_name')->whereIn('account_id', $accId)->get()->toArray();
        if(!empty($connQry))
        {
            //$accName = [];
            foreach($connQry as $storData)
            { 
                $kaiConnAccId = $storData->account_id;
                $getAccName = DB::table('new_accounts')->select('name')->where('id', $kaiConnAccId)->get()->toArray();
                $accName = $getAccName[0]->name;
                $kaiConnectionName = $storData->name;
                $get_data[] = array('name' => $kaiConnectionName);
                $connectionString = $storData->connectionstring;
                $connStrng = explode(";", $connectionString);
                //define an array
                $connectionData = [];
                foreach ($connStrng as $result) {
                  if(!empty($result)){
                    $b = explode('->', $result);
                    if(is_array($b))
                    {
                      $connectionData[$b[0]] = $b[1];
                    }
                  }
                }
                $phpOverLay = $storData->phpoverlay; 
                $this->webStorHealthCheck($phpOverLay, $storData, $connectionData, $accName);             
            }
            //die; 
        }     
    }

    /**
     * this function is use for check stor front status.
     *
     * @param $phpOverLay, $storData, $connectionData
     */
    public function webStorHealthCheck($phpOverLay, $storData, $connectionData, $accName)
    {
        switch($phpOverLay)
        {
            case $phpOverLay=="MySQL":
                $server = $connectionData['host'];
                $username = $storData->username;
                $password = $storData->password;
                $database_name = $connectionData['database'];
                $port = $connectionData['port'];
                $conn = @mysqli_connect($server, $username, $password, $database_name, $port);
                if(! $conn ) 
                {
                    $this->saveErrorStorfront($storData, $accName);
                    
                } else {
                    echo 'connection success';
                    $this->archiveData($storData, $accName);
                }
            break;
            case $phpOverLay=="PrestaShop":
                $prestashopUrl = $connectionData['url'];
                $token = $storData->password;
                $url = $prestashopUrl . "/api/configurations/1?&ws_key=" . $token;
                $prestashop_output = Helper::curlStatusCheck($url);
                $obj = simplexml_load_string($prestashop_output, 'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($obj);
                $res = json_decode($json, TRUE);
                if (!empty($res['configuration']['id']) && !empty($res['configuration']['value'])) 
                {
                    $this->archiveData($storData, $accName);
                } else {
                    $this->saveErrorStorfront($storData, $accName);
                    
                }
            break;
            case $phpOverLay=="Magento":
                $magentoUrl = $connectionData['url'];
                $proxy = new SoapClient($magentoUrl); // TODO : change url
                $sessionId = $proxy->login($storData->username, $storData->password); // TODO : change login and pwd if necessary
                if(!$sessionId)
                {
                    $this->saveErrorStorfront($storData, $accName);
                }else{
                    $result = $proxy->catalogCategoryCurrentStore($sessionId, '1');
                    if(is_int($result)==true)
                    {
                      echo 'connection success';
                      $this->archiveData($storData, $accName);
                    }
                }
            break;
            case $phpOverLay=="BigCommerce":
                $store_hash = $connectionData['store_hash'];
                $client_id = $connectionData['client_id'];
                $auth_token = $connectionData['auth_token'];
                $headers = array(
                    'Accept: application/json',
                    'Content-Type: application/json',
                    "X-Auth-Client: " . $client_id . "",  
                    "X-Auth-Token: " . $auth_token . ""
                );
                $url = "https://api.bigcommerce.com/stores/".$store_hash."/v2/time";
                $added_output = Helper::curlStatusCheck($url, $headers);
                $time = json_decode($added_output, true);
                if(!empty($time['time']))
                {
                    echo 'bigCommerce';
                    $this->archiveData($storData, $accName);
                    
                } else {
                    $this->saveErrorStorfront($storData, $accName);
                }
            break;
            case $phpOverLay=="ShopifyConn":
                $shopifyToken = $storData->password;
                $shopifyUrl = $connectionData['url'];
                $ch = curl_init();
                $headers = array(
                  "X-Shopify-Access-Token: " . $shopifyToken . ""           
                );
                $url = "https://".$shopifyUrl."/admin/api/2020-04/countries.json";
                
                $shopify_output = Helper::curlStatusCheck($url, $headers);
                $countries = json_decode($shopify_output, true);
                if(!empty($countries['countries'][0]['id'])){
                    echo 'ShopifyConn';
                    $this->archiveData($storData, $accName);
                }else {
                    $this->saveErrorStorfront($storData, $accName);
                }
            break;
            default:
                echo "No Connection available";
            break;            
        }
    }

    /**
     * Increase health counter, if error in any storefront of account.
     *
     * @param $storData, $accName
     */
    public function saveErrorStorfront($storData, $accName)
    {        
        $dashboard_name = $storData->dashboard_name;
        $log_message = $dashboard_name.' offline '.$accName;
        $saveData = array(
            'account_id' => $storData->account_id,
            'connection_id' => $storData->id,
            'connection_name' => $dashboard_name,
            'failure_message' => $log_message,
            'health_counter' => "1",
            'archived' => ""
        );
        $getAuditAccId = DB::table('kai_connection_statuses')->select('account_id', 'connection_id', 'health_counter', 'archived')->where('account_id', $storData->account_id)->where('failure_message', $log_message)->get()->toArray(); 
        $healthCount = [];
        $archived = [];
        foreach($getAuditAccId as $connId)
        {
            $healthCount[] = $connId->health_counter;
            $archived[] = $connId->archived;
        } 
        if(empty($getAuditAccId))
        {
            $modal = new KaiConnectionStatus();
            $modal->fill($saveData);
            $modal->save();
        } else if($archived[0] == 0){
            $saveData = array(            
                'health_counter' => 1 + $healthCount[0]
            );
            DB::table('kai_connection_statuses')->where('connection_id', $storData->id)->update($saveData);
        }else {
            $qry = DB::table('kai_connection_statuses')->select('id', 'account_id', 'connection_id', 'health_counter', 'archived')->where('account_id', $storData->account_id)->where('connection_id', $storData->id)->where('archived', 0)->orderBy('id', 'desc')->first();
            if(!$qry)
            {
                $dashboard_name = $storData->dashboard_name;
                $log_message = $dashboard_name.' offline '.$accName;
                $saveData = array(
                    'account_id' => $storData->account_id,
                    'connection_id' => $storData->id,
                    'connection_name' => $dashboard_name,
                    'failure_message' => $log_message,
                    'health_counter' => "1",
                    'archived' => ""
                );
                $modal = new KaiConnectionStatus();
                $modal->fill($saveData);
                $modal->save();
            }else {
                $saveData = array(            
                    'health_counter' => 1 + $qry->health_counter
                );
                DB::table('kai_connection_statuses')->where('id', $qry->id)->update($saveData);
            }
        }
    }

    /**
     * Increase and update archived value, if status is success in any storefront of account.
     *
     * @param $storData
     */
    public function archiveData($storData, $accName){
        $dashboard_name = $storData->dashboard_name;
        $log_message = $dashboard_name.' offline '.$accName;
        $getAuditAccId = DB::table('kai_connection_statuses')->select('account_id', 'connection_id', 'health_counter', 'archived')->where('account_id', $storData->account_id)->where('failure_message', $log_message)->get()->toArray();        
        $healthCount = [];
        $archived = [];
        foreach($getAuditAccId as $connId)
        {
             
            $healthCount[] = $connId->health_counter;
            $archived[] = $connId->archived;
        }
        if(!empty($getAuditAccId))
        {
            $saveData = array(            
                'archived' => 1
            );
            DB::table('kai_connection_statuses')->where('connection_id', $storData->id)->update($saveData);  
        }
    }
}
