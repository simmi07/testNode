<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class KaiConnectionStatus extends Authenticatable
{
    use Notifiable;
    
    protected $guard = 'kaiconnectionstatus';

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'account_id', 'connection_id', 'connection_name', 'failure_message', 'health_counter', 'archived',
    ];
}
