<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class KaiConnectionWithAccount extends Authenticatable {

    use Notifiable;
    use HasRoles;

    protected $guard = 'kaiconnection_with_accounts';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'type', 'connectionstring', 'username', 'password', 'phpoverlay', 'heading', 'dashboard_name', 'active', 'status', 'created', 'modified',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
