<?php
/**
 * This controller handles authenticating users for the application and
 * redirecting them to your home screen. The controller uses a trait
 * to conveniently provide its functionality to your applications.
 */

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Auth;
use Lang;

class LoginController extends Controller
{

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    //protected $redirectTo = '/';//RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        Auth::viaRemember();
        $this->middleware('guest')->except('logout');
    }

    public function index() {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $email = $request->email;
        $password = $request->password;
        $remember = $request->has('remember') ? true : false;
        $this->validate($request, [
                'email' => 'required|email|regex:/(.*)@(kissingersolutions)\.com/i',
                'password' => 'required'
            ],
            ['email.regex' => Lang::get('message.emailRelated'),
            'email.email' => Lang::get('message.email')
        ]);

        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
            //user sent their email 
            $this->guard()->attempt(['email' => $email, 'password' => $password], $remember);
        } 

        // if (Auth::viaRemember()) {
        //    true;
        // }
        //was any of those correct ?
        if ( Auth::check() ) {
            
            //send them where they are going 
            return redirect()->intended('home');
        }
        //Nope, something wrong during authentication 
        return redirect()->back()->withErrors([
            'credentials' => Lang::get('message.userLogin')
        ]); 
        //dd($request->has('remember'));
               
    }
}
