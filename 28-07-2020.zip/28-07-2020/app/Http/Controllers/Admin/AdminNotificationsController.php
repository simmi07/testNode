<?php
/**
 * This controller handles the notification as well as their
 * validation , creation, update and delete from super admin.
 */

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;
use Log;

/**
 * Class AdminNotificationsController
 * @package App\Http\Controllers
 */
class AdminNotificationsController extends Controller {
    
    /**
     * View notification from admin.
     *
     * @return view
     */
    public function index() {
        try {
            $get_notification = DB::table('new_notifications')
                            ->select('*')
                            ->where('notification_type', '=', 'both')
                            ->get()->toArray();
            return view('users.userNotification.viewUserNotification', compact('get_notification'));
        } catch (Exception $e) {
            DB::rollback();
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * View particular notification.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function userGetNotificationById(Request $request) {
        $notificationId = $request->all();
        $res = DB::table('new_notifications')->where('id', $notificationId['id'])->get();
        if($res){
            Log::info(__METHOD__ . print_r($res));
            return response()->json(['res' => $res]);
        } else {
            Log::error(__METHOD__ . 'Notification id is not found');
            return false;
        }
    }

    /**
     * Update the specified notification in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateNotifiStatus(Request $request) {
        $info = $request->all();
        $id = $info['id'];
        $qry = DB::table('new_notifications')->select('status', 'enable_number')->where('id', $info['id'])->get();
        $status = $qry[0]->status;
        $enable_number = $qry[0]->enable_number;
        try {
            if ($status == 0 && $enable_number == "") {
                $increment = 0;
                $data = DB::table('new_notifications')->where('id', $info['id'])->update(['status' => $info['status'], 'enable_number' => DB::raw($increment + 1)]);
                $res = [
                    'success' => true,
                    'url' => url('users/configureNotification/' . $id)
                ];
                return response()->json($res);
            } else {
                $data = DB::table('new_notifications')->where('id', $info['id'])->update(['status' => $info['status'], 'enable_number' => DB::raw(1 + 1)]);
                $res = [
                    'success' => false,
                    'status' => $status,
                    'url' => url('view/notifications')
                ];
                return response()->json($res);
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }
}
