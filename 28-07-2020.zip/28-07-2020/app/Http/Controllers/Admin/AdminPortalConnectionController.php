<?php

/**
 *  This controller handles the This module holds a collection of functions 
 *  to be used for the status of all storefronts. By default this controller
 *  uses a trait to either online or offline. It also shows the processed data
 *  and the latest error logs from webstore.
 */

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use SoapClient;
use App\Helper\Helper;
use Log;
use App\KaiAudit;

/**
 * Class AdminPortalConnectionController
 * @package App\Http\Controllers
 */
class AdminPortalConnectionController extends Controller {

    /**
     * Get audit log error details .
     *
     * @return \Illuminate\View\View
     */
    public function getStatus() {
        $accountId = session()->get('id');
        try {
            if ($accountId) {
                Log::info(__METHOD__ . 'getting account id as ' . $accountId);
                $data = DB::table('kai_connection_statuses as m1')
                    ->select('m1.id', 'm1.connection_id', 'm1.account_id', 'm1.archived', 'm1.connection_name')
                    ->leftJoin('kai_connection_statuses as m2', function($join)
                        {
                            $join->on('m1.connection_name', '=', 'm2.connection_name');
                            $join->on('m1.id','<',DB::raw('m2.id'));
                            //$join->on('m1.id','>',DB::raw('m2.id'));
                            $join->on('m1.connection_id','<=',DB::raw('m2.connection_id'));
                            $join->on('m1.connection_id','>=',DB::raw('m2.connection_id'));
                        })
                    ->where('m2.id', '=', NULL)
                    ->where('m2.connection_id', '=', NULL)
                    ->where('m1.account_id', '=', $accountId)
                    ->get()->toArray();
                //get data for connection check
                $getConnection = DB::table('new_accounts')->select('username', 'port', 'database_name', 'server', 'password')->where('id', '=', $accountId)->get();
                $getConnection = json_decode(json_encode($getConnection), true);
                $server = $getConnection[0]['server'];
                $username = $getConnection[0]['username'];
                $password = $getConnection[0]['password'];
                $database_name = $getConnection[0]['database_name'];
                $port = $getConnection[0]['port'];
                //create a connection with different database
                $con = mysqli_connect($server, $username, $password, $database_name, $port);
                //get recently 5 errdor in desc order
                $query = "SELECT * FROM kaiauditlogdetail where logtype='Error' order by created desc limit 5";
                $getError = mysqli_query($con, $query);
                return view('users.status', compact('data', 'getError'));
            } else {
                Log::error(__METHOD__ . 'account id is not found');
                return false;
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * Show status by Date for storefronts of account.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function showProcessedStatusByDate(Request $request) {
        $info = $request->all();
        $accountId = $info['id'];
        $startDate = substr($info['dateProcess'], 0,10);
        $endDate = substr($info['dateProcess'], 14,25);
        $getConnection = DB::table('new_accounts')->select('username', 'port', 'database_name', 'server', 'password')->where('id', '=', $accountId)->get();
        $getConnection = json_decode(json_encode($getConnection), true);
        $server = $getConnection[0]['server'];
        $username = $getConnection[0]['username'];
        $password = $getConnection[0]['password'];
        $database_name = $getConnection[0]['database_name'];
        $port = $getConnection[0]['port'];
        $con = mysqli_connect($server, $username, $password, $database_name, $port);
        try {
            if ($con) {
                Log::info(__METHOD__ . 'Connection success ');
                //For number of product
                $qry = "SELECT count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND category = 'Product' group by category";
                $res = mysqli_query($con, $qry);
                $numOfProducts = mysqli_fetch_array($res);
                //For number of order
                $getQry = mysqli_query($con, "SELECT count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND category = 'Order' group by category");
                $numOfOrders = mysqli_fetch_array($getQry);
                //For number of customer
                $getCus = mysqli_query($con, "SELECT count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND category = 'Customer' group by category");
                $numOfCustomers = mysqli_fetch_array($getCus);
                $response = [
                    'numOfProducts' => $numOfProducts,
                    'numOfOrders' => $numOfOrders,
                    'numOfCustomers' => $numOfCustomers,
                    'startDate' => $startDate,
                    'endDate' => $endDate
                ];
                return response()->json($response);
            } else {
                Log::error(__METHOD__ . 'Connection failed');
                return false;
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * Show failed status by Date for storefronts of account.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function showFailedStatus(Request $request) {
        $info = $request->all();
        $accountId = $info['id'];
        $startDate = substr($info['dateFailed'], 0,10);
        $endDate = substr($info['dateFailed'], 14,25);
        $getConnection = DB::table('new_accounts')->select('username', 'port', 'database_name', 'server', 'password')->where('id', '=', $accountId)->get();
        $getConnection = json_decode(json_encode($getConnection), true);
        $server = $getConnection[0]['server'];
        $username = $getConnection[0]['username'];
        $password = $getConnection[0]['password'];
        $database_name = $getConnection[0]['database_name'];
        $port = $getConnection[0]['port'];
        $con = mysqli_connect($server, $username, $password, $database_name, $port);
        try {
            if ($con) {
                Log::info(__METHOD__ . 'Connection success ');
                $countFailedCustomer = mysqli_query($con, "SELECT category,count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND status='F' AND category = 'Customer' group by category");
                //get number of failed customer
                $failedCustomer = mysqli_fetch_array($countFailedCustomer);
                //get number of failed order
                $countFailedOrder = mysqli_query($con, "SELECT category,count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND status='F' AND category = 'Order' group by category");
                $failedOrder = mysqli_fetch_array($countFailedOrder);  
                //get number of failed item                
                $countFailedItem = mysqli_query($con, "SELECT category,count(*) FROM kaihistory WHERE updated BETWEEN '" . $startDate . "' AND  '" . $endDate . "' AND status='F' AND category = 'Product' group by category");
                $failedItem = mysqli_fetch_array($countFailedItem);
                $response = [
                    'startDate' => $startDate,
                    'failedCustomer' => $failedCustomer,
                    'failedOrder' => $failedOrder,
                    'failedItem' => $failedItem
                ];
                return response()->json($response);
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }      
    }

    /**
     * Create a connection from database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkStatus(Request $request)
    {
        $accountsId = $request->all();
        $accountId = session()->get('id');
        $data = DB::table('kai_connection_statuses as m1')
                    ->select('m1.id', 'm1.connection_id', 'm1.account_id', 'm1.archived', 'm1.connection_name')
                    ->leftJoin('kai_connection_statuses as m2', function($join)
                        {
                            $join->on('m1.connection_name', '=', 'm2.connection_name');
                            $join->on('m1.id','<',DB::raw('m2.id'));
                            $join->on('m1.connection_id','<=',DB::raw('m2.connection_id'));
                            $join->on('m1.connection_id','>=',DB::raw('m2.connection_id'));
                        })
                    ->where('m2.id', '=', NULL)
                    ->where('m2.connection_id', '=', NULL)
                    ->where('m1.account_id', '=', $accountId)
                    ->where('m1.connection_id', '=', $accountsId)
                    ->get()->toArray();
        $data = json_decode( json_encode($data), true);
        $accId = $data[0]['account_id'];
        $kaiconnectionWithAccounts = DB::table('kaiconnection_with_accounts')->select('name', 'connectionstring', 'phpoverlay', 'username', 'password', 'account_id', 'dashboard_name')->where('id', '=', $accountsId)->get();
        $kaiconnectionWithAccounts = json_decode( json_encode($kaiconnectionWithAccounts), true);
        $getAccName = DB::table('new_accounts')->select('name')->where('id', $accId)->get()->toArray();
        $accName = $getAccName[0]->name;
        foreach ($data as $value) {
            $connectionName = array('name' => $value['connection_name']);
            if ($data[0]['archived'] == 1) {
                return $this->saveTrueValueKaiAudit($connectionName, $accId, $kaiconnectionWithAccounts, $accName);
            } else {
                return $this->saveFalseValueKaiAudit($connectionName, $accId, $kaiconnectionWithAccounts, $accName);
            }           
        }           
    }
    
    public function saveFalseValueKaiAudit($connectionName, $accId, $kaiconnectionWithAccounts, $accName)
    {
        $dashboard_name = $kaiconnectionWithAccounts[0]['dashboard_name'];
                $log_message = $dashboard_name.' offline for '.$accName;
                $datas  = array(
                        'account_id' => $accId,
                        'log_type' => 'Error',
                        'log_category' => 'System',
                        'log_message' => $log_message,
                        'processed' => 0,
                        'status' => 0,
                );
                $getAuditAccId = DB::table('kai_audits')->select('account_id')->where('account_id', $accId)->where('log_message', $log_message)->get()->toArray();
                //print_r($getAuditAccId); die;
                
                if(empty($getAuditAccId))
                {
                    $modal = new KaiAudit();
                    $modal->fill($datas);
                    $modal->save();
                } else {
                    $datas = array('status' => 0);
                    $dashboard_name = $kaiconnectionWithAccounts[0]['dashboard_name'];
                    $log_message = $dashboard_name.' offline for '.$accName;
                    $getAuditAccId = DB::table('kai_audits')->select('account_id', 'id')->where('account_id', $accId)->where('log_message', $log_message)->get()->toArray();
                    if($getAuditAccId)
                    {
                        $updateStatus = DB::table('kai_audits')->where('id', $getAuditAccId[0]->id)->update($datas);
                    }
                }
                $res = [
                    'success'    => false,
                    'message'    => 'Offline',
                    'acountName' => $connectionName
                ];
            
            return response()->json($res);
    }

    public function saveTrueValueKaiAudit($connectionName, $accId, $kaiconnectionWithAccounts, $accName)
    {
        $datas = array('status' => 1);
        $dashboard_name = $kaiconnectionWithAccounts[0]['dashboard_name'];
        $log_message = $dashboard_name.' offline for '.$accName;
        $getAuditAccId = DB::table('kai_audits')->select('account_id', 'id')->where('account_id', $accId)->where('log_message', $log_message)->get()->toArray();
        if($getAuditAccId)
        {
            $updateStatus = DB::table('kai_audits')->where('id', $getAuditAccId[0]->id)->update($datas);
        }
        $res = [
            'success'    => true,
            'message'    => 'Online',
            'acountName' => $connectionName
        ];
        return response()->json($res);
    }

    /**
     * Display a form for audit log error.
     * 
     * @return void
     */
    public function getAuditLog() {
        return view('users.auditLog');
    }

    /**
     * Display a listing for audit log error of specific account.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function viewUserAuditLog(Request $request) {
        $response = Helper::auditLog($request);
        if ($response) {
            return response()->json($response);
        } else {
            Log::error(__METHOD__ . 'account id is not found');
            return false;
        }
    }
}
