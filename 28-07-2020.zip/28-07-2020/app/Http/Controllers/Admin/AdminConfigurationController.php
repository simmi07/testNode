<?php
/**
 * This controller handles the configuration as well as their
 * validation , creation and update from admin.
 */

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Configuration;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use App\Notifications\KissingerNotifications;
use App\Http\Controllers\App\User;
use App\Http\Controllers\Superadmin\ConfigurationController;
use App\ConfigureParameter;
use DB;
use Log;

/**
 * Class AdminConfigurationController
 * @package App\Http\Controllers
 */
class AdminConfigurationController extends Controller {

    /**
     * Display the configuration in admin.
     *
     * @param  $id
     */
    public function configureAdminNotification($id) {
        try {
            $getNotification = DB::table('new_notifications')->select('id', 'notification_type')->where('id', '=', $id)->get()->toArray();
            $notificationId = $getNotification[0]->id;
            $notificationType = $getNotification[0]->notification_type;
            $accountId = session()->get('id');
            $userId = Auth::id();
            $getUserConfiguration = DB::table('configurations')->select('notification_id', 'notification_type', 'account_id', 'recipeintemail')->where('auth_id', '=', $userId)->where('notification_id', '=', $notificationId)->where('account_id', '=', $accountId)
                            ->groupBy('recipeintemail')
                            ->get()->toArray();
            return view('users.userNotification.userConfigure', compact('notificationId', 'notificationType', 'getUserConfiguration'));
        } catch (Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * Show the form for creating a configuration.
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function saveAdminConfiguration(Request $request) {
        $this->validate($request, [
            'recipeintemail' => 'required',
        ],
        [
            'recipeintemail.required' => 'Recipient Email is required'
        ]);
        $info = $request->all();
        $actualLink = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $userId = Auth::id();
        $accountId = session()->get('id');
        $notificationId = $info['notification_id'];
    	$recipientEmail = $info['recipeintemail'];
        try{
            Configuration::whereNotIn('recipeintemail', $recipientEmail)->where('notification_id', '=', $notificationId)->where('auth_id', '=', $userId)->where('configure_url', $actualLink)->where('account_id', $accountId)->delete();
            foreach ($recipientEmail as $recipEmail) {
                $data = array(
                    'auth_id' => $userId,
                    'notification_id' => $notificationId,
                    'notification_type' => $info['notification_type'],
                    'account_id' => $accountId,
                    'recipeintemail' => $recipEmail,
                    'configure_url' => $actualLink
                );
                $modal = new Configuration();
                $modal->fill($data);
                $modal->save();
            }
            return Redirect::to('view/notifications')->with('success', Lang::get('message.configurationSuccess'));
        } catch (Exception $e) {
            DB::rollback();
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * Get data of configure parameter of particualr notification.
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function userNotificationId(Request $request)
    {
        try {  
            $authId = Auth::id();
            //echo $authId; die;
            $notificationId = $request->all();
            //print_r($notificationId); die;
            $accountId = session()->get('id');
            $getParameter = DB::table('configure_parameters')->select('id', 'auth_id', 'account_id', 'parameter', 'description', 'parameter_type', 'parameter_value', 'notification_id', 'parameter_status')->where('notification_id', $notificationId)->where('account_id', NULL)->get()->toArray(); 
            echo '<pre>getParameter'; print_r($getParameter);
            //$getQry = json_decode( json_encode($getQry), true);
            $arr = [];
            $i = 0;
            foreach ($getParameter as $key => $value) {

                echo '<pre>val'; print_r($value); 
                $getQry = DB::table('configure_parameters')->select('id', 'auth_id', 'account_id', 'parameter', 'description', 'parameter_type', 'parameter_value', 'notification_id', 'parameter_status')->where('notification_id', $notificationId)->where('account_id', $accountId)->where('parameter', $value->parameter)->get()->toArray();
                 //die;
                $getQry = json_decode( json_encode($getQry), true);
                //echo '<pre>que'; print_r($getQry); die;
                if(!empty($getQry))
                {
                    //die('if');
                    //echo '<pre>que'; print_r($getQry);
                    $arr[$i] = $getQry[0];
                    print_r($arr[$i]);
                }else {
                    //die('else');
       //echo "<pre>val";print_r(json_decode( json_encode($value), true));
                    $arr[$i] = json_decode( json_encode($value), true);
                }
                $i++;
            }  
            die;     
            $res = [
                'success' => true,
                'result' => $arr
            ];       
            return response()->json($res);                
        } catch(Exception $e) {
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }
    }

    /**
     * Save Notification Parameter
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveUserParameter(Request $request)
    {
        //die('AAA');
        try {
            $info = $request->all();
            //echo '<pre>'; print_r($info); die;
            $authId = Auth::id();
            $notifiId = $info['notification_id'];
            $accountId = session()->get('id');
            $getQry = ConfigureParameter::select('notification_id', 'parameter_value', 'account_id')->where('notification_id', $notifiId)->get()->toArray();
            $notificationId = [];
            //$accIdVal = [];
            foreach ($getQry as $key => $value) {
                $notificationId[] = $value['notification_id'];
                $accIdVal = $value['account_id'];
            }

            
                //die('dsdsd');
                $parameterType = $info['parameter_type'];       
                foreach ($parameterType as $key => $pType) {
                    $data = array(
                        'notification_id' => $info['notification_id'],
                        'auth_id' => $authId,
                        'account_id' => $accountId,
                        'parameter' => $info['parameter'][$key],
                        'parameter_type' => $pType,
                        'description' => $info['description'][$key],
                        'parameter_value' => $info['parameter_value'][$key],
                        'parameter_status' => 'new'
                    );
                    //print_r($data); die;
                    $modal = ConfigureParameter::where('notification_id', $info['notification_id'])->where('auth_id', $authId)->where('account_id', $accountId)->where('description', $info['description'][$key])->whereNotNull('parameter_value')->first();
                    //echo '<pre>'; print_r($modal); die;
                    if(!$modal)
                    {
                        $modal = new ConfigureParameter();
                    }
                    $modal->fill($data);
                    $modal->save();

                    $parameterStatus = array(
                        'parameter_status' => 'old'
                    );
                    $updateParameterStatus = DB::table('configure_parameters')->where('id', $info['id'][$key])->update($parameterStatus); 
                }            
            
            $res = [
                'success' => true
            ];
            return response()->json($res);
        } catch(Exception $e){
            return redirect()->back()->with('error', Lang::get('message.accException'));
        }       
    }
}
