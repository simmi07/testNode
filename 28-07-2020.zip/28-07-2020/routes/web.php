<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::auth();

# Dashboard / Index
Route::get('/', 'Auth\LoginController@index');

Route::get('login', 'Auth\LoginController@login');
Route::get('/home', 'Superadmin\SuperAdminController@viewHome')->middleware('auth', 'admin')->name('index');
Route::resource('roles','RoleController');
Route::resource('users','Superadmin\SuperAdminController');
Route::get('getDataById/{id}','Superadmin\SuperAdminController@getDataById');
Route::get('/editUser/{id}', 'Superadmin\SuperAdminController@edit')->name('editUser');
Route::post('/updateUser', 'Superadmin\SuperAdminController@update')->name('updateUser');
Route::get('/deleteUser/{id}', 'Superadmin\SuperAdminController@destroy')->name('deleteUser');
Route::get('/changePassword/{id}', 'Superadmin\SuperAdminController@changePassword')->name('changePassword');
Route::post('/updatePassword', 'Superadmin\SuperAdminController@updatePasswordForUser')->name('updatePassword');

///////// this route use for SuperaAminAccount Controller////////
Route::get('new', 'Superadmin\SuperAdminAccountController@createNewAccount')->name('new');
Route::post('account_new', 'Superadmin\SuperAdminAccountController@newAccountForUser')->name('account_new');
Route::get('accounts', 'Superadmin\SuperAdminAccountController@viewAccountUsers')->name('accounts');
Route::get('getAccountUserById/{id}','Superadmin\SuperAdminAccountController@viewAccountUsersById');
Route::get('/editAccountUser/{id}', 'Superadmin\SuperAdminAccountController@editAccountUser')->name('editAccountUser');
Route::post('/updateAccountUser', 'Superadmin\SuperAdminAccountController@updateAccountUser')->name('updateAccountUser');
Route::get('/getAccountPassword/{id}', 'Superadmin\SuperAdminAccountController@getAccountPassword')->name('getAccountPassword');
Route::POST('/deleteAccountUser', 'Superadmin\SuperAdminAccountController@deleteAccountUser')->name('deleteAccountUser');
Route::post('status/{id}/{status}','Superadmin\SuperAdminAccountController@updateMultipleStatus');
Route::post('getTestConnection','Superadmin\SuperAdminAccountController@testConnection');
Route::post('/getEditTestConnection','Superadmin\SuperAdminAccountController@editTestConnection');
Route::post('/refreshConnection', 'Superadmin\SuperAdminAccountController@refreshConnection')->name('refreshConnection');

////// this route use for SuperAdminAuditLog Controller//////
Route::get('viewers', 'Superadmin\SuperAdminAuditLogController@viewers')->name('viewers');
Route::get('getKaiauditlog/{id}', 'Superadmin\SuperAdminAuditLogController@getKaiauditlog')->name('getKaiauditlog');

////// this route use for SuperAdminNotification Controller//////
Route::get('notification', 'Superadmin\NotificationController@index')->name('notification');
Route::get('createnotification', 'Superadmin\NotificationController@createNotification')->name('createnotification');
Route::post('saveNotification', 'Superadmin\NotificationController@saveNotification')->name('saveNotification');
Route::get('editNotification/{id}', 'Superadmin\NotificationController@editNotification')->name('editNotification');
Route::post('updateNotification', 'Superadmin\NotificationController@updateNotification')->name('updateNotification');
Route::get('deleteNotification/{id}', 'Superadmin\NotificationController@deleteNotification')->name('deleteNotification');
Route::get('getNotificationById/{id}','Superadmin\NotificationController@getNotificationById');
Route::post('notificationStatus/{id}/{status}','Superadmin\NotificationController@updateNotificationStatus');
Route::get('configureNotification/{id}','Superadmin\NotificationController@configureNotification')->name('configureNotification');

////// this route use for ConfigurationController Controller//////
Route::get('configureNotification/{id}','Superadmin\ConfigurationController@configureNotification')->name('configureNotification');
Route::post('saveConfiguration','Superadmin\ConfigurationController@saveConfiguration')->name('saveConfiguration');
Route::post('/test_notification', 'Superadmin\ConfigurationController@test_notification');
Route::post('/sendNotification', 'Superadmin\ConfigurationController@sendNotification');
Route::post('/notificationId', 'Superadmin\ConfigurationController@notificationId')->name('notificationId');
Route::post('/saveParameter', 'Superadmin\ConfigurationController@saveParameter')->name('saveParameter');

Route::get('/dashboard', 'UserController@viewUser')->name('customer');
Route::prefix('{portal_url}')->group(function () {
    Route::get('/', 'UserController@index');
});
Route::get('user', 'UserController@viewUser')->name('customer');
Route::post('/dashboard', 'UserController@userLogin')->name('dashboard');
Route::post('/logoutAccount', 'UserController@logoutAccount')->name('logoutAccount');
Route::get('users/create/new', 'UserController@userCreate')->name('users/create/new');
Route::post('users/create/insertUser', 'UserController@insertUser')->name('users/create/insertUser');
Route::get('view/users', 'UserController@viewUsersData')->name('view/users');
Route::get('/getUserDataById/{id}', 'UserController@getUserDataById');
Route::get('/editUserById/{id}', 'UserController@editUserById')->name('editUserById');
Route::post('/updateUserData', 'UserController@updateUserData')->name('updateUserData');
Route::get('/deleteUserDetails/{id}', 'UserController@deleteUserDetails')->name('deleteUserDetails');
Route::get('/checkMysqlConnection/{id}', 'UserController@checkMysqlConnection');

/////////// this route use for AdminPortalConnection Controller ////////
Route::get('view/status', 'Admin\AdminPortalConnectionController@getStatus')->name('view/status');
Route::get('/checkStatus/{id}', 'Admin\AdminPortalConnectionController@checkStatus');
Route::post('/showStatusByDate', 'Admin\AdminPortalConnectionController@showProcessedStatusByDate')->name('showStatusByDate');
Route::get('/view/auditlog', 'Admin\AdminPortalConnectionController@getAuditLog')->name('view/auditlog');
Route::get('/auditlog/{id}', 'Admin\AdminPortalConnectionController@viewUserAuditLog');
Route::post('/showFailedStatus', 'Admin\AdminPortalConnectionController@showFailedStatus')->name('showFailedStatus');


////// this route use for SuperAdminNotification Controller//////
Route::get('view/notifications', 'Admin\AdminNotificationsController@index')->name('view/notifications');
Route::get('/getNotficatinById/{id}', 'Admin\AdminNotificationsController@userGetNotificationById');
Route::post('/userNotification/{id}/{status}','Admin\AdminNotificationsController@updateNotifiStatus');

////// this route use for SuperAdminConfiguration Controller//////
Route::get('users/configureNotification/{id}','Admin\AdminConfigurationController@configureAdminNotification')->name('users/configureNotifi');
Route::post('users/saveAdminConfiguration','Admin\AdminConfigurationController@saveAdminConfiguration')->name('users/saveAdminConfiguration');
Route::post('/userNotificationId', 'Admin\AdminConfigurationController@userNotificationId')->name('userNotificationId');
Route::post('/saveUserParameter', 'Admin\AdminConfigurationController@saveUserParameter')->name('saveUserParameter');
