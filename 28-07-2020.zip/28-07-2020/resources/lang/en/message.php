<?php 

return [

    'success' => 'User created successfully.',   
    'userUpdatesuccess' => 'User Update successfully.',
    'userDelete' => 'User deleted.',
    'accountCreated' => 'User account created successfully.',
    'updateAccount' => 'User account updated successfully.',
    'createNotifi' => 'Notifications created successfully.',
    'updateNotifi' => 'Notification updated successfully.',
    'deleteNotifi' => 'Notification deleted',
    'accException' => 'Something went wrong.',
    'configurationSuccess' => 'Configuration created successfully.',
    'userLogin' => 'Wrong Password, check your credentials',
    'username' => 'Username is not valid',
    'uNameExist' => 'Username doesnt exists',
    'emailRelated' => 'Email format related to kissingsolutions.com',
    'email' => 'Email is not valid',
    'pwdExst' => 'Password is not valid',
    'pwdCheck' => 'Password should be one capital chracter and one special character with one number',
    'role' => 'Role is required',
    'newPwd' => 'New Password field is required',
    'confirmPwd' => 'Confirm password field is required',
    'matchPwd' => 'The confirm password and new password must match',
    'updatePwd' => 'Update Password',
    'getPwd' => 'Get Password.',
    'delAcc' => 'Delete Account.',
    'notDelAcc' => 'not Delete Account.',
    'notConnect' => 'Could not connect.',
    'connect' => 'Connection connect',
    'faild' => 'Connection Failed',
    'conSuccess' => 'Connection successfull'
];