<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.users.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.users.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">              
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.config')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                @if (count($errors) > 0)
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-danger">
                        <strong></strong> <br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                             <li>{{ $error }}</li>
                            @endforeach                            
                        </ul>
                    </div>
                    @endif
                    <form method="POST" action="{{ route('users/saveAdminConfiguration') }}">
                        @csrf
                        <input type="hidden" name="notification_id" value="{{ $notificationId }}" id="notificationId">
                        <input type="hidden" name="notification_type" value="{{ $notificationType }}">
                        <div class="form-group row">
                            <label for="recipentemail" class="col-md-4 col-form-label text-md-right">{{ __('Recipient Email Address') }}</label>
                            <div class="col-md-6 wrapper">
                                <input id="recipentemail" type="text" class="form-control recipentemail @error('recipentemail') is-invalid @enderror" name="recipEmail" autocomplete="name" autofocus>
                                <label id="error_email" style="color: red;"></label>
                                @error('recipentemail')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <p><button class="btn btn-primary add_recipeint">Add Recipient</button></p>
                        </div>
                        <div class="form-group row">
                            <label for="recipeint_list" class="col-md-4 col-form-label text-md-right">{{ __('Recipient List') }}</label>
                            <div class="col-md-6">
                                <select class="form-control" id="recipeint_list" style="height:150px;" rows="10" multiple="multiple" name="recipeintemail[]">
                                    @foreach($getUserConfiguration as $recipEmail)
                                    <option value="{{$recipEmail->recipeintemail}}" selected>{{$recipEmail->recipeintemail}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <p><button class="btn btn-danger remove_recipeint">Remove</button></p>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <a class="btn btn-primary" href="{{ route('view/notifications') }}"> Cancel</a>
                                <button type="submit" class="btn btn-primary" style="margin-left: 54px;">
                                    {{ __('Submit') }}
                                </button>

                                <a class="btn btn-primary addUserParameter" data-toggle="modal" data-target="#addUserParameterPopup" data-id="{{ $notificationId }}" id="addUserParameter" style="color:white;margin-top: -64px;margin-left: 371px;">Edit Parameter</a>
                            </div>
                        </div>
                    </form>
                    <!-- Modal Popup for delete account-->
                    @include('modal.users.addUserParameter')
                    <!-- End of Main Content -->
                    <!-- Footer -->      
                    @include('includes.footer')      
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
    </body>
</html>