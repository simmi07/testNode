<html lang="en">
    <head>  
        @include('includes.header')
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="{{ URL::asset('css/statusLoader.css')}}" rel="stylesheet" type="text/css"/>
        <link href="{{ URL::asset('js/datepicker/dist/daterangepicker.min.css')}}" rel="stylesheet" type="text/css"/>
        <script type="text/javascript" src="{{ URL::asset('js/datepicker/moment.min.js')}}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/datepicker/jquery.min.js')}}"></script>        
        <script type="text/javascript" src="{{ URL::asset('js/datepicker/dist/jquery.daterangepicker.min.js')}}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/datepicker/dist/demo.js')}}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/datepicker/src/jquery.daterangepicker.js')}}"></script>
    </head>

    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.users.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.users.nav')
                    <!-- End of Topbar -->
                    <!-- Begin Page Content -->
                    <div class="container-fluid">
                        <h1 class="h3 mb-2 text-gray-800">Dashboard Status</h1>
                        @if ($message = Session::get('error'))
                        <div class="alert alert-danger">
                            <p>{{ $message }}</p>
                        </div>
                        @endif
                        <input type="hidden" id="accountId" value="{{ session('id') }}">
                        <div class="card  mb-4">
                            <div class="card-body gfgf shadow"> 
                                <div class="row status_row">
                                    @if($data)
                                    @foreach($data as $val)                
                                    <input type="hidden" class="form-control accountName" id="kaiConnectionId" placeholder="text" value="{{$val->connection_id}}" name="connection_id[]">
                                    @endforeach
                                    @else
                                    <div class="row connAvalable"></div>
                                    @endif
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card  mb-4">
                                            <div id="processedLoader" style="display: none;">
                                                <div id="status">&nbsp;</div>
                                            </div>
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Processed</h6>
                                            </div>
                                            <!-- It is fine -->
                                            <div class="bootstrap mt-2 ml-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-lg-12 ml-3">
                                                                    <form method="post"  action="">
                                                                        @csrf
                                                                        <input id="date-range0" class="" size="40" value="{{ date('Y-m-d') }} to {{ date('Y-m-d') }}" name="process_datepicker" placeholder="Start date To End date">
                                                                        <div class="processBtn" style="display: none" id="processBtn"><input type="submit" name="submit" value="Apply" class="setApply btn btn-info process showProcessedStatus"></div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="preloader" style="display: none">
                                                <div id="status">&nbsp;</div>
                                            </div>
                                            <!-- End -->
                                            <div class="card-body">
                                                <!-- Content Column -->
                                                <div class="col-lg-6 mb-4">
                                                    <!-- Project Card Example -->
                                                    <div class="card  mb-4">
                                                        <div class="card-header py-3">
                                                        </div>
                                                        <!-- Card Body -->
                                                        <div class="card-body">                              
                                                            <div class="chart-pie pt-4 pb-2">
                                                                <canvas id="myPieChart"></canvas>
                                                            </div>
                                                            <div class="mt-4 text-center small" style="display: flex; margin-left: 102px;">
                                                                <span class="mr-2">
                                                                    <i class="fas fa-circle text-primary"></i> Orders
                                                                </span> 
                                                                <div class="processedOrders"></div>&nbsp;&nbsp;
                                                                <span class="mr-2">
                                                                    <i class="fas fa-circle text-success"></i> Items
                                                                </span> 
                                                                <div class="processedItems"></div>&nbsp;&nbsp;
                                                                <span class="mr-2">
                                                                    <i class="fas fa-circle text-info"></i> Customers
                                                                </span> 
                                                                <div class="processedCustomers"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Failures</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="bootstrap">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div>
                                                                <div class="row">
                                                                    <div class="col-lg-12 pl-3 mb-5">
                                                                        <input type="hidden" id="date-range1" size="40" value="">
                                                                        <input type="hidden" id="date-range1-1" size="40" value="">
                                                                        <input type="hidden" id="date-range2" size="40" value="">
                                                                        <input type="hidden" id="date-range3" size="40" value="">                                                                  
                                                                        <input id="date-range4" size="40" value="{{ date('Y-m-d') }} to {{ date('Y-m-d') }}" placeholder="Start date To End date">
                                                                        <div class="failedBtn" id="failedBtn"> <input type="submit" name="submit" value="Apply" class="setApply btn btn-info failed showFailStatus"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Content Column -->
                                                <div class="col-lg-6 mb-4">
                                                    <!-- Project Card Example -->
                                                    <div class="card mb-4">
                                                        <div class="card-header py-3">
                                                            <!-- <h6 class="m-0 font-weight-bold text-primary">Projects</h6> -->
                                                        </div>
                                                        <div id="preloader" style="display: none">
                                                            <div id="status">&nbsp;</div>
                                                        </div>
                                                        <div class="card-body">
                                                            <h4 class="small font-weight-bold">Orders<span class="float-right failOfOrders"></span></h4>
                                                            <div class="progress mb-4 orderProgressBar1">

                                                            </div>
                                                            <h4 class="small font-weight-bold">Items <span class="float-right failOfItems"></span></h4>
                                                            <div class="progress mb-4 itemProgressBar1">

                                                            </div>
                                                            <h4 class="small font-weight-bold">Customers <span class="float-right failOfCustomers"></span></h4>
                                                            <div class="progress mb-4 customersProgressBar1">

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Content Row -->
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card  mb-4">
                                        <!-- Card Header - Dropdown -->
                                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                            <h6 class="m-0 font-weight-bold text-primary">Recent Error Message</h6>
                                            <div class="dropdown no-arrow">
                                                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right  animated--fade-in" aria-labelledby="dropdownMenuLink">
                                                    <div class="dropdown-header">Audit Log:</div>
                                                    <a class="dropdown-item" href="{{url('view/auditlog')}}">Audit Log</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered error-message" id="" width="100%" cellspacing="0">
                                                    <thead>
                                                        <tr>
                                                            <th>Type</th>
                                                            <th>Category</th>
                                                            <th>Message</th>
                                                            <th>Created</th>                      
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($getError as $row)
                                                        <tr>                 
                                                            <td>{{ $row['logtype'] }}</td>                      
                                                            <td>{{ $row['logcategory'] }}</td>
                                                            <td>{{ $row['logmessage'] }}</td>
                                                            <td>{{ $row['created'] }}</td>
                                                        </tr>                    
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>         
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
                <!-- End of Main Content -->
                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    @include('includes.footer')
                </footer>
                <!-- End of Footer -->
            </div>
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <!-- Bootstrap core JavaScript
    <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>-->
    <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Core plugin JavaScript-->
    <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
    <!-- Custom scripts for all pages-->
    <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
    <!-- Page level plugins -->
    <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
    <!-- Page level custom scripts -->
    <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
    <!-- add custom js -->
    <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
    <!-- Page level plugins -->
    <script src="{{ URL::asset('vendor/chart.js/Chart.min.js') }}"></script> 
    <!-- Page level custom scripts -->
    <script src="{{ URL::asset('js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ URL::asset('js/demo/chart-pie-demo.js') }}"></script> 
    <script type="text/javascript">
        let orders = new Array();
        let items = new Array();
        let customers = new Array();
        $(document).ready(function () {
          $(document).on('click', '.showProcessedStatus', function () {
              $("#preloader").show();
              $('.date-picker-wrapper').hide();
                $('.processBtn').hide();
              let accountId = $("#accountId").val();
              let dateProcess = $("#date-range0").val();
              let url = "{{url('/showStatusByDate')}}";
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
              $.ajax({
                  type: "POST",
                  url: url,
                  data: {"id": accountId, "dateProcess": dateProcess},
                  dataType: 'json',
                  success: function (data) {
                    $('.date-picker-wrapper').hide();
                    $('.processBtn').hide();
                    $("#preloader").hide();
                    let items = "";
                    let orders = "";
                    let customers = "";
                    if (data.numOfCustomers === null && data.numOfOrders === null && data.numOfProducts === null)
                    {
                        $('.processedOrders').html("");
                        $('.processedItems').html("");
                        $('.processedCustomers').html("");
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                        swal('Data not found  for this date-' + data.startDate);
                        paiChart(ctx, orders, items, customers);
                    } else if (data.numOfCustomers !== null && data.numOfOrders !== null && data.numOfProducts !== null){                        
                        orders = data.numOfOrders[0];
                        customers = data.numOfCustomers[0];
                        items = data.numOfProducts[0];
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    } else if (data.numOfCustomers !== null && data.numOfOrders === null && data.numOfProducts === null){                        
                        orders = "";
                        customers = data.numOfCustomers[0];
                        items = "";
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    } else if (data.numOfCustomers !== null && data.numOfOrders !== null && data.numOfProducts === null){                        
                        orders = data.numOfOrders[0];
                        customers = data.numOfCustomers[0];
                        items = "";
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    } else if (data.numOfCustomers === null && data.numOfOrders !== null && data.numOfProducts !== null){                        
                        orders = data.numOfOrders[0];
                        customers = "";
                        items = data.numOfProducts[0];
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    }  else if (data.numOfCustomers === null && data.numOfOrders === null && data.numOfProducts !== null){                        
                        orders = "";
                        customers = "";
                        items = data.numOfProducts[0];
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    }   else if (data.numOfCustomers === null && data.numOfOrders !== null && data.numOfProducts === null){                        
                        orders = data.numOfOrders[0];
                        customers = "";
                        items = items = "";
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    }   else if (data.numOfCustomers !== null && data.numOfOrders === null && data.numOfProducts !== null){                        
                        orders = "";
                        customers = data.numOfCustomers[0];
                        items = data.numOfProducts[0];
                        $('.processedOrders').html(orders);
                        $('.processedItems').html(items);
                        $('.processedCustomers').html(customers);
                        var ctx = document.getElementById("myPieChart");
                        paiChart(ctx, orders, items, customers);
                    } 
                }
            });
            return false;
          });
            function paiChart(ctx, orders, items, customers)
            {
                console.log(ctx);
                var myPieChart = new Chart(ctx, {
               type: 'doughnut',
              data: {
                  labels: ["Orders", "Items", "Customers"],
                  datasets: [{
                          data: [orders, items, customers],
                          backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
                          hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
                          hoverBorderColor: "rgba(234, 236, 244, 1)",
                      }],
              },
              //paiChart()
              options: {  
                maintainAspectRatio: false,
                tooltips: {
                    backgroundColor: "rgb(255,255,255)",
                    bodyFontColor: "#858796",
                    borderColor: '#dddfeb',
                    borderWidth: 1,
                    xPadding: 15,
                    yPadding: 15,
                    displayColors: false,
                    caretPadding: 10,
                },
                legend: {
                    display: false
                },
                cutoutPercentage: 80,
              },                              
          });
        }
    });
    </script>
</body>
</html>