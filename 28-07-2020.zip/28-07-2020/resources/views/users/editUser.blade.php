<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.users.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.users.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.edit')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                <form action="/updateUserData" method="post">
                                    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                                    <input type="hidden" name="id" value="{{$user[0]['id']}}">
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $user[0]['name'] }}" autocomplete="name" autofocus>
                                            @error('name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>
                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $user[0]['email'] }}" autocomplete="email">
                                            @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row select_role">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role role_id @error('role_id') is-invalid @enderror" name="role_id">
                                                <option value="{{ $roles[0]['id'] }}">{{$roles[0]['name']}}</option> 
                                                <option value="{{ $roles[1]['id'] }}">{{$roles[1]['name']}}</option>
                                            </select>
                                            @error('role_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @if($roles == '7')
                                    <div class="form-group row account_users">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Account Users') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role" name="new_account_user_id">
                                                @foreach($getAccountUsers as $accountUsers)                
                                                <option value="{{$accountUsers->id}}">{{ucfirst($accountUsers->username)}}</option>    
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @endif
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <a class="btn btn-primary" href="{{ route('view/users') }}">Cancel</a>
                                            <button type="submit" class="btn btn-primary" style="margin-left: 54px;">
                                                {{ __('Submit') }}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    @if (count($errors) > 0)
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <!-- Footer -->      
                    @include('includes.footer')      
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>  
    </body>    
</html>