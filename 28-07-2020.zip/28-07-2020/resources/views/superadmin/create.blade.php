<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
        <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js" defer></script>
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">    
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.newUser')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                <form method="POST" action="{{ route('users.store') }}">
                                    @csrf
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" autocomplete="name" autofocus>
                                            @error('name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>
                                        <div class="col-md-6">
                                            <input id="email" type="text" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email">
                                            @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>
                                        <div class="col-md-6">
                                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password">
                                            @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>
                                        <div class="col-md-6">
                                            <input id="password-confirm" type="password" class="form-control @error('password_confirmation') is-invalid @enderror" name="password_confirmation" autocomplete="new-password">
                                            @error('password_confirmation')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row select_role">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role role_id @error('role_id') is-invalid @enderror" name="role_id" id="roleVal">
                                                <option>Select Role</option>
                                                @foreach($roles as $role)
                                                <option value="{{$role->id}}">{{$role->guard_name}}</option>    
                                                @endforeach
                                            </select>
                                            @error('role_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @if($roleId == '7')
                                    <div class="form-group row account_users">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Account Users') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role js-example-basic-multiple @error('new_account_user_id') is-invalid @enderror" id="check_account" name="new_account_user_id[]" multiple="multiple">
                                                @foreach($getAccountUsers as $accountUsers)
                                                <option value="{{$accountUsers->id}}">{{ucfirst($accountUsers->name)}}</option>    
                                                @endforeach
                                            </select>
                                            @error('new_account_user_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @else
                                    <div class="form-group row account_users">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Account Users') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role @error('new_account_user_id') is-invalid @enderror" name="new_account_user_id" id="dropdown">
                                                @foreach($data as $datas)
                                                <option value="{{$datas->new_account_user_id}}">{{ucfirst($datas->name)}}</option>    
                                                @endforeach
                                            </select>
                                            @error('new_account_user_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @endif
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <a class="btn btn-primary" href="{{ route('users.index') }}"> Cancel</a>
                                            <button type="submit" class="btn btn-primary check_email" style="margin-left: 54px;">
                                                {{ __('Submit') }}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <!-- Footer -->      
                                @include('includes.footer')      
                                <!-- End of Footer -->
                            </div>
                            <!-- End of Content Wrapper -->
                        </div>
                    <!-- End of Page Wrapper -->
                </div>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
        <!-- Bootstrap core JavaScript-->
        <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
        <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <!-- Core plugin JavaScript-->
        <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
        <!-- Custom scripts for all pages-->
        <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
        <!-- Page level plugins -->
        <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
        <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
        <!-- Page level custom scripts -->
        <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
        <!-- add custom js -->
        <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
        <script src="{{ URL::asset('js/custom/selectBox.js') }}"></script>
    </body>
</html>