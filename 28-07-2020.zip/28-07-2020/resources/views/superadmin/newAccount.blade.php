<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    @if($roleName == 'superadmin')
                    <div class="container-fluid super-admin-section">            
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.accTitle')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                @else($roleName == 'admin')
                            </div>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="col-lg-12 margin-tb">
                            <div class="pull-left">
                                <h2>Admin Portal Accounts - New</h2>
                            </div>
                            <div class="pull-right" style="float: right;">
                                <a class="btn btn-primary" href="{{ route('accounts') }}"> Back</a>
                            </div>
                        </div>
                    </div>
                    @endif
                    <div class="alert alert-danger print-error-msg" style="display:none">
                        <ul></ul>
                    </div>
                    <form method="POST" action="{{ route('account_new') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" autocomplete="name" autofocus>
                                @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Server') }}</label>
                            <div class="col-md-6">
                                <input id="server" type="text" class="form-control @error('server') is-invalid @enderror" name="server" value="{{ old('server') }}" autocomplete="server">
                                @error('server')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="port" class="col-md-4 col-form-label text-md-right">{{ __('Port') }}</label>
                            <div class="col-md-6">
                                <input type="text" id="port" class="form-control @error('port') is-invalid @enderror" name="port" value="3306" autocomplete="port">
                                @error('port')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="database_name" class="col-md-4 col-form-label text-md-right">{{ __('Database') }}</label>
                            <div class="col-md-6">
                                <input type="text" id="database_name" class="form-control @error('database_name') is-invalid @enderror" name="database_name" autocomplete="database_name">
                                @error('database_name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right">{{ __('Username') }}</label>
                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}" autocomplete="username" autofocus>
                                @error('username')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password">
                                @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="portal_url" class="col-md-4 col-form-label text-md-right">{{ __('Disable Monitoring') }}</label>
                            <input type="hidden" name="disable_monitoring" value="0">
                            <input type="checkbox" name="disable_monitoring" class="" style="margin-left: 15px; margin-top: 13px;" value="1"></th>
                        </div>
                        <div class="form-group row">
                            <label for="portal_url" class="col-md-4 col-form-label text-md-right">{{ __('Portal URL') }}</label>
                            <div class="col-md-6">
                                <input id="portal_url" type="text" class="form-control @error('portal_url') is-invalid @enderror" name="portal_url" autocomplete="portal_url">
                                @error('portal_url')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="image" class="col-md-4 col-form-label text-md-right">{{ __('Logo') }}</label>
                            <div class="col-md-6">
                                <input id="" type="file" class="form-control @error('image') is-invalid @enderror" name="image" autocomplete="image">
                                @if ($errors->has('image'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('image') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <a class="btn btn-primary" href="{{ route('accounts') }}"> Cancel</a>
                                <button type="submit" class="btn btn-primary" style="margin-left: 54px;">
                                    {{ __('Submit') }}
                                </button>
                            </div>
                        </div>            
                    </form>
                    <div class="form-group row mb-0">              
                        <div class="col-md-6 offset-md-4" style="margin-top: -36px; margin-left: 720px">
                            <button type="submit" class="btn btn-primary test_connection">
                                {{ __('Test Connection') }}
                            </button>
                        </div>
                    </div>
                    <div id="msg" style="margin-left: 643px;margin-top: -30px;"></div>
                    <div id="validation-errors"></div>
                    <!-- Footer -->
                    @include('includes.footer')
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
    </body>
</html>