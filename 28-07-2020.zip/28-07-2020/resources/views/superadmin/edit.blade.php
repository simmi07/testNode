<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
        <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js" defer></script>
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section"> 
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.edit')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                <form action="/updateUser" method="post">
                                    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                                    <input type="hidden" name="id" value="{{$user[0]->id}}">
                                    <input type="hidden" name="password" value="{{$user[0]->password}}">
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $user[0]->name }}" autocomplete="name" autofocus>
                                            @error('name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>
                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $user[0]->email }}" autocomplete="email">
                                            @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row select_role">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role role_id @error('role_id') is-invalid @enderror" name="role_id">
                                                <option value="">Select</option>
                                                @foreach($roles as $role)
                                                <option value="{{$role['id']}}" @if($role['id']==$user[0]->role_id) selected='selected' @endif >{{$role['guard_name']}}</option>    
                                                @endforeach
                                            </select>
                                            @error('role_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @if($roleId == '7')
                                    <div class="form-group row account_users hideAccountUser">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Account Users') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role js-example-basic-multiple" id="check_account" name="new_account_user_id[]" multiple="multiple" style="width: 33.75em;">              
                                                @foreach($getAccountUsers as $accountUsers)                
                                                <option value="{{$accountUsers->id}}" @if(in_array($accountUsers->id, $explode)) selected='selected' @endif >{{ucfirst($accountUsers->name)}}</option>    
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @else
                                    <div class="form-group row account_users hideAccountUser">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Account Users') }}</label>
                                        <div class="col-md-6">
                                            <select class="form-control role" name="new_account_user_id">
                                                <option>Select Account User</option>
                                                <?php foreach ($data as $datas) { ?>
                                                    <option value="<?php echo $datas['new_account_user_id']; ?>">{{ucfirst($datas->username)}}</option>    
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    @endif
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <a class="btn btn-warning btn-icon-split get_password" data-toggle="modal" data-target="#myModal{{$user[0]->id}}" data-id="{{$user[0]->id}}" id="" style="color:white;">
                                                <span class="icon text-white-50">
                                                    <i class="fas fa-key"></i>
                                                </span>
                                                <span class="text">Change Password</span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-0" style="margin-top: 17px;">
                                        <div class="col-md-6 offset-md-4">
                                            <a class="btn btn-primary" href="{{ route('users.index') }}"> Cancel</a>
                                            <button type="submit" class="btn btn-primary check_email check_value" style="margin-left: 54px;">
                                                {{ __('Submit') }}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Modal Popup -->
                    @include('modal.superadmin.changePassword')
                    <!-- Footer -->
                    @include('includes.footer')
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
            <script src="{{ URL::asset('js/custom/selectBox.js') }}"></script>
    </body>
</html>