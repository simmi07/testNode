<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">              
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.config')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                @if (count($errors) > 0)
                            </div>
                        </div>
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <form method="POST" action="{{ route('saveConfiguration') }}">
                        @csrf
                        <input type="hidden" name="notification_id" value="{{ $notificationId }}" id="notificationId">
                        <input type="hidden" id="notificationType" name="notification_type" value="{{ $notificationType }}">
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Account') }}</label>
                            <div class="col-md-6">
                                <select class="form-control" id="account_name" name="accountName">
                                    <option>Select Account</option>
                                    @foreach($allAccount as $account)
                                    <option value="{{ $account->id }}" data-name="{{ $account->name }}" id="getAccountName">{{ $account->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <p><button class="btn btn-primary add_account">Add Account</button></p>
                        </div>
                        <div class="form-group row">
                            <label for="notificationEnabled" class="col-md-4 col-form-label text-md-right">{{ __('Notifications Enabled For') }}</label>
                            <div class="col-md-6">
                                <select class="form-control notifiList @error('account_id') is-invalid @enderror" multiple="multiple" name="account_id[]" style="height:150px;" id="notificationEnabled" rows="10">
                                    @foreach($getConfig as $value)
                                        <option value="{{$value->account_id}}" selected>{{$value->name}}</option>
                                    @endforeach
                                </select>
                                @error('account_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <p><button class="btn btn-danger remove_account" id="enableNoti" disabled>Remove</button></p>
                        </div>                        
                        <div class="form-group row">
                            <label for="recipentemail" class="col-md-4 col-form-label text-md-right">{{ __('Recipient Email Address') }}</label>
                            <div class="col-md-6 wrapper">
                                <input id="recipentemail" type="text" class="form-control recipentemail" name="recipEmail" autocomplete="name" autofocus>
                                <label id="error_email" style="color: red;"></label>
                            </div>
                            <p><button class="btn btn-primary add_recipeint addRecip">Add Recipient</button></p>
                        </div>
                        <div class="form-group row">
                            <label for="recipeint_list" class="col-md-4 col-form-label text-md-right">{{ __('Recipient List') }}</label>
                            <div class="col-md-6">
                                <select class="form-control recipList @error('recipeintemail') is-invalid @enderror" id="recipeint_list" style="height:150px;" rows="10" multiple="multiple" name="recipeintemail[]">
                                    @foreach($getReciep as $value)
                                        <option value="{{$value->recipeintemail}}" selected>{{$value->recipeintemail}}</option>
                                    @endforeach
                                </select>
                                @error('recipeintemail')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <p><button class="btn btn-danger remove_recipeint" id="enableRemove" disabled>Remove</button></p>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <a class="btn btn-primary" href="{{ route('notification') }}"> Cancel</a>
                                <button type="submit" class="btn btn-primary" style="margin-left: 25px;">
                                    {{ __('Submit') }}
                                </button>
                                <a class="btn btn-primary" id="testNotification" href="javascript:void(0)" style="margin-left: 25px;"> Test Notification</a>
                                <a class="btn btn-primary addParameter" data-toggle="modal" data-target="#addParameterPopup" data-id="{{ $notificationId }}" id="addParameter" style="color:white;margin-top: -64px;margin-left: 371px;">Add Parameter</a>
                            </div>
                        </div>
                    </form>
                    <!-- Modal Popup for delete account-->
                    @include('modal.superadmin.addParameter')
                    <!-- End of Main Content -->
                    <!-- Footer -->      
                    @include('includes.footer')      
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
            <script type="text/javascript">            
        </script>
    </body>
</html>