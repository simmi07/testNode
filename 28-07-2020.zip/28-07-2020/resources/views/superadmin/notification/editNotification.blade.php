<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
        <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
        <script src="http://cdn.ckeditor.com/4.4.7/standard-all/adapters/jquery.js"></script>
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">              
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.editNotifi')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                @if (count($errors) > 0)
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <form method="POST" action="{{ route('updateNotification') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $data[0]->id }}">
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $data[0]->name }}" autocomplete="name" autofocus>
                                @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>
                            <div class="col-md-6">
                                <textarea name="description" class="form-control @error('description') is-invalid @enderror">{{ $data[0]->description }}</textarea>
                                @error('description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Notification Type') }}</label>
                            <div class="col-md-6">
                                <select class="form-control role" name="notification_type">
                                    <option value="kissinger" {{ ( $data[0]->notification_type == 'kissinger' ) ? 'selected' : '' }}>Kissinger Only</option>  
                                    <option value="both" {{ ( $data[0]->notification_type == 'both' ) ? 'selected' : '' }}>All</option>
                                </select>
                                @error('notification_type')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="notification_condition" class="col-md-4 col-form-label text-md-right">{{ __('Notification Condition') }}</label>
                            <div class="col-md-6">
                                <input id="" type="text" class="form-control @error('notification_condition') is-invalid @enderror" name="notification_condition" autocomplete="name" value="{{ $data[0]->notification_condition }}" autofocus>
                                @error('notification_condition')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <?php
                        //foreach ($getQry as $value) {
                        ?>
                            <!-- <input type="text" name="param_id" value="">  -->
                        <?php //} ?>
                        
                        <div class="form-group row">
                            <label for="email_subject" class="col-md-4 col-form-label text-md-right">{{ __('Subject') }}</label>
                            <div class="col-md-6">
                                <input id="" type="text" class="form-control @error('email_subject') is-invalid @enderror" name="email_subject" autocomplete="name" value="{{ $data[0]->email_subject }}" autofocus>
                                @error('email_subject')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email_body" class="col-md-4 col-form-label text-md-right">{{ __('Body') }}</label>
                            <div class="col-md-6">
                                <textarea name="email_body" class="form-control @error('email_body') is-invalid @enderror">{{ $data[0]->email_body }}</textarea>
                                @error('email_body')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <a class="btn btn-primary" href="{{ route('users.index') }}"> Cancel</a>
                                <button type="submit" class="btn btn-primary" style="margin-left: 54px;">
                                    {{ __('Submit') }}
                                </button>
                            </div>
                        </div>
                    </form>
                    <!-- Footer -->      
                    @include('includes.footer')      
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
            <script src="{{ URL::asset('js/custom/ckEditor.js') }}"></script>
    </body>
</html>