<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    <!-- End of Topbar -->
                    <!-- Begin Page Content -->
                    <div class="container-fluid">
                        <!-- Page Heading -->
                        <h1 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.title')}}</h1>
                        <div class="col-sm-6" style="margin-left: 915px;">
                            <div class="pull-right">
                            </div>
                        </div>
                        @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                        @endif
                        @if ($message = Session::get('error'))
                        <div class="alert alert-danger">
                            <p>{{ $message }}</p>
                        </div>
                        @endif
                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary"><a class="btn btn-primary" href="{{ route('users.create') }}" style="float: right;">Add User...</a></h6>  
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Email</th>
                                                <th>Roles</th>                      
                                                <th>Account Related With</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($userList as $key => $user)
                                            <tr>                 
                                                <td>{{ $user['email'] }}</td>
                                                @if($user['role_id'] == 7)                   
                                                <td>Superadmin</td>
                                                @elseif($user['role_id'] == 5)
                                                <td>Admin</td>
                                                @else
                                                <td>User</td>
                                                @endif
                                                <?php
                                                if ($user['new_account_user_id'] != '') {
                                                    ?>           
                                                    <td><textarea class="acc_name" rows="4" cols="40">{{ ucfirst($user['accountName']) }}</textarea></td>
                                                <?php } else {
                                                    ?>
                                                    <td>Kissinger Solutions</td>;
                                                <?php }
                                                ?>
                                                <td>
                                                    <a class="btn btn-primary get_data" data-toggle="modal" data-target="#myModal{{$user['id']}}" data-id="{{$user['id']}}" id="get_data" style="color:white;">View</a>
                                                    <a class="btn btn-primary" href="{{ route('editUser', $user['id'])}}" style="background-color: #f79b11">Edit</a>
                                                    <a class="btn btn-primary btn-danger del" href="{{ route('deleteUser', $user['id'])}}">Delete</a>
                                                </td>
                                            </tr>                    
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- End of Main Content -->
                <!-- Modal Popup -->
                <!-- Modal Popup -->
                <div class="modal" id="MyPopup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    &times;</button>
                                <h4 class="modal-title">
                                </h4>
                            </div>
                            <div class="modal-body">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">
                                    Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    @include('includes.footer')
                </footer>
                <!-- End of Footer -->
            </div>
            <!-- End of Content Wrapper -->
        </div>
        <!-- End of Page Wrapper -->
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
        <!-- Bootstrap core JavaScript-->
        <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
        <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <!-- Core plugin JavaScript-->
        <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
        <!-- Custom scripts for all pages-->
        <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
        <!-- Page level plugins -->
        <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
        <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
        <!-- Page level custom scripts -->
        <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
        <!-- add custom js -->
        <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
    </body>
</html>
