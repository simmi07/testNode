<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.header')
    </head>
    <body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            @include('includes.sidebar')
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    @include('includes.nav')
                    @section('content')
                    <div class="container-fluid super-admin-section">
                        <h2 class="h3 mb-2 text-gray-800">{{Config::get('constants.options.editAcc')}}</h2>
                        <div class="card shadow mb-4">
                            <div class="card-header super-btm">
                                <?php $user = json_decode(json_encode($users), true);
                                ?>
                                <form action="/updateAccountUser" method="post" enctype="multipart/form-data">
                                    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                                    <input type="hidden" name="id" value="{{$user[0]['id']}}" id="accountIdRefresh">
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $user[0]['name'] }}" autocomplete="name" autofocus>
                                            @error('name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Server') }}</label>
                                        <div class="col-md-6">
                                            <input id="server" type="text" class="form-control @error('server') is-invalid @enderror" name="server" value="{{ $user[0]['server'] }}" autocomplete="server">
                                            @error('server')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Port') }}</label>
                                        <div class="col-md-6">
                                            <input id="port" type="text" class="form-control @error('port') is-invalid @enderror" name="port" value="{{ $user[0]['port'] }}" autocomplete="port">
                                            @error('port')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Database Name') }}</label>
                                        <div class="col-md-6">
                                            <input id="database_name" type="text" class="form-control @error('database_name') is-invalid @enderror" name="database_name" value="{{ $user[0]['database_name'] }}" autocomplete="database_name">
                                            @error('database_name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Username') }}</label>
                                        <div class="col-md-6">
                                            <input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ $user[0]['username'] }}" autocomplete="username">
                                            @error('username')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>
                                        <div class="col-md-6">
                                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" value="{{ $user[0]['password'] }}" autocomplete="password">
                                            @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="portal_url" class="col-md-4 col-form-label text-md-right">{{ __('Disable Monitoring') }}</label>
                                        <input type="hidden" name="disable_monitoring" value="0">
                                        <input type="checkbox" <?php if ($user[0]['disable_monitoring'] == 1){?> checked="checked" <?php } ?> name="disable_monitoring" class="" style="margin-left: 15px; margin-top: 13px;" value="1"></th>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label text-md-right">{{ __('Portal Url') }}</label>
                                        <div class="col-md-6">
                                            <input id="portal_url" type="text" class="form-control @error('portal_url') is-invalid @enderror" name="portal_url" value="{{ $user[0]['portal_url'] }}" autocomplete="portal_url">
                                            @error('portal_url')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="image" class="col-md-4 col-form-label text-md-right">{{ __('Logo') }}</label>
                                        <div class="col-md-6">
                                            <input id="" type="file" class="form-control @error('image') is-invalid @enderror" name="image" autocomplete="image" value="{{ $user[0]['image'] }}">
                                            @if ($errors->has('image'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('image') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                        <div class="col-md-6 offset-md-4">
                                            @if(!empty($user[0]['image']))
                                            <img src="{{asset('upload_image').'/'.$user[0]['image']}}" class="img-responsive">
                                            @else
                                            <img src="/image/no-image-available-icon.jpg" class="img-responsive">
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4 pleft-0">
                                            <a class="btn btn-primary mr42" href="{{ route('accounts') }}"> Cancel</a>
                                            <button type="submit" class="btn btn-primary m-r4 mr42">
                                                {{ __('Submit') }}
                                                <button type="submit" class="btn btn-primary refresh">
                                                    {{ __('Refresh') }}
                                                </button>
                                                <button type="submit" class="btn btn-primary test_edit_connection connection-right">
                                                    {{ __('Test Connection') }}
                                                </button>
                                            </button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                    <!-- Footer -->
                    <footer class="sticky-footer bg-white">
                        @include('includes.footer')
                    </footer>
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>
            <!-- Bootstrap core JavaScript-->
            <script src="{{ URL::asset('vendor/jquery/jquery.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
            <!-- Core plugin JavaScript-->
            <script src="{{ URL::asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>
            <!-- Custom scripts for all pages-->
            <script src="{{ URL::asset('js/sb-admin-2.min.js') }}"></script>
            <!-- Page level plugins -->
            <script src="{{ URL::asset('vendor/datatables/jquery.dataTables.min.js') }}"></script>
            <script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
            <!-- Page level custom scripts -->
            <script src="{{ URL::asset('js/demo/datatables-demo.js') }}"></script>
            <!-- add custom js -->
            <script src="{{ URL::asset('js/custom/custom.js') }}"></script>
    </body>
</html>