<?php
    use App\Helper\Helper;
    $navData = Helper::navData();
    $getCompanyName = $navData['getCompanyName'];
    $getAccountName = $navData['getAccountName'];
    $roleId = $navData['roleId'];    
    $userName = $navData['userName'];
    $getRoleId = $navData['getRoleId'];
?>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
        <li class="nav-item dropdown no-arrow d-sm-none">
            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
            </a>
            <!-- Dropdown - Messages -->
            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </li>
        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">@if(isset($getCompanyName)){{ ucfirst($getCompanyName) }} @endif</span>
                <input type="hidden" name="id" value="{{session('id')}}">
                <!-- <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60"> -->
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php if (isset($roleId) != 6) { ?>
                    <div>@if(isset($userName)) {{ $userName }} @endif</div>
                <?php } else { ?>
                    <div>@if(isset($userName)) {{ $getCompanyName }} @endif</div>
                <?php } ?>
                <div>{{ session('username') }}</div>
                <?php if ($roleId != 6) { ?>
                    <a class="btn btn-primary" href="{{ url('view/users') }}">Manage Accounts</a>
                <?php } ?> 
                <?php if ($roleId == 6) { ?>
                    <a class="btn btn-primary enableOnInput" href="{{ route('editUserById', $getRoleId[0]['id']) }}" style="background-color: #f79b11">Edit Accounts</a>
                <?php } ?>
                <a class="dropdown-item" href="{{ route('logoutAccount') }}"
                   onclick="event.preventDefault();
                             document.getElementById('logout-forms').submit();">
                    {{ __('Logout') }}
                </a>
                <form id="logout-forms" action="{{ route('logoutAccount') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </div>
            <!-- </div> -->
        </li>            
    </ul>
</nav>