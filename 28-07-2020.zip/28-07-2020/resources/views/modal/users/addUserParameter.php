<div class="modal" id="addUserParameterPopup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">
                </h4> 
                <div style="margin-right: 297px;"><h4><strong>Edit Parameter</strong></h4></div>         
            </div>
            <div class="modal-body">     
                <form method="POST" id="updateForm" action="/saveParameter">
                
                    <div id="somewhere"></div>
                    <input type="hidden" name="notifiid" id="notifiId" value="" />
                    
                    <div class="form-group row">
                        <div class="col-md-12 p-0">
                            <div id="inputFormRow">
                                <div class="input-group mb-3 row" id="container">
                                </div>
                            </div>
                            <div id="newRow"></div>
                            <!-- <button id="addRow" type="button" class="btn btn-info" style="margin-left:-5px;">Add Parameter</button> -->
                        </div>
                    </div>                                        
                    <div class="modal-footer">
                        <button type="submit" name="submit" class="btn btn-primary validateType" id="saveUserParameter" value="">Submit</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                            Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>