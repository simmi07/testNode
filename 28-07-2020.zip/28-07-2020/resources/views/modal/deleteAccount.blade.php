
<!-- Modal Popup -->
<div class="modal" id="MyDeleteAccountPopup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">
              &times;</button>
          <h4 class="modal-title">
          </h4>
      </div>
      <div class="modal-body">
        <div class="form-group row"><label class="col-md-4 col-form-label text-md-right">{{ __("Password") }}</label>
          <input type="hidden" name="accountId" id="accountId" value="">
          <input type="hidden" name="accountName" id="accountName" value="">
          <input type="hidden" name="oldPassword" id="oldPassword" value="">
          <div class="col-md-8"><input type="password" class="form-control" name="confirmPassword" id="confirmPassword" value="">
          </div>
        </div>
          <div class="deleteAccountUser" style="margin-left: 166px;">
            <input type="button" class="btn btn-primary" name="deleteAccountUser" id="deleteAccountUser" value="Delete Account">
          </div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">
              Close</button>
      </div>
    </div>
  </div>
</div>

