<div class="modal" id="changePasswordPopup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <button type="button" class="close" data-dismiss="modal">
                    &times;</button> -->
                <h4 class="modal-title">
                </h4> 
                <div style="margin-right: 263px;"><h4><strong>Change Password</strong></h4></div>         
            </div>
            <div class="modal-body">
                <div class="alert alert-danger print-error-msg" style="display:none">
                    <ul></ul>
                </div>      
                <form method="" id="updateForm">
                    @csrf
                    <input type="hidden" name="old_pass" value="" id="old_pass">
                    <input type="hidden" name="id" value="" id="userId">
                    <div class="form-group row">
                        <!-- <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label> -->
                        <div class="col-md-8">
                            <input type="hidden" class="form-control" name="name" value="" id="userName">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('New Password') }}</label>
                        <div class="col-md-8">
                            <input class="form-control" type="password" name="new_password" id="new_pass">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>
                        <div class="col-md-8">
                            <input class="form-control" type="password" name="confirm_password" id="confirm_pass">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <!-- <input type="submit" name="submit" class="btn btn-block btn-warning" value="Save changes" /> -->
                        <button type="submit" name="submit" class="btn btn-success updatePassword" id="submitForm" value="Save changes">Change Password</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                            Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>