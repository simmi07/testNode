/////////This for active and inactive account for particular account user//////////
$(document).on('click', '.clickActive', function () {
    let accountName = $(this).closest('tr').children('td.name').text();
    let status = ($(this).hasClass("btn-success")) ? 0 : 1;
    let msg = (status == 0) ? 'Disabled' : 'Enabled';
    if (confirm("Would you like to " + msg + ' ' + accountName + " ?"))
    {
        let id = jQuery(this).attr('user_id');
        url = "status/{id}/{status}";
        $.ajax({
            type: "POST",
            url: url,
            data: {"id": id, "status": status, _token: $('meta[name="csrf-token"]').attr('content')},
            success: function (result) {
                location.reload();
            }
        });
    }
});
/////////End This for active and inactive account for particular account user//////////

////////// View Particular User Account//////////////////////
$(function () {
    $(".getDataAccount").click(function () {
        let id = $(this).attr('data-id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "getAccountUserById/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                htmlData = '<div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Name</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['name']) + ' readonly></div></div><div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Server</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['server']) + ' readonly></div></div><div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Port</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['port']) + ' readonly></div></div><div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Databse Name</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['database_name']) + ' readonly></div></div><div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Username</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['username']) + ' readonly></div></div><div class="form-group row"><label class="col-md-4 col-form-label text-md-right">Portal Url</label><div class="col-md-8"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['portal_url']) + ' readonly></div></div>';
                $('.modal-body').html(htmlData);
                $("#MyPopup").modal("show");
            }
        });
        return false;
    });
});

//for change status alert
$(document).ready(function () {
    $(".change_status").click(function () {
        if (!confirm("Do you want to enable/disable the selected account(s)?")) {
            return false;
        }
    });
});

$('.checked_all').on('change', function () {
    $('.checkbox').prop('checked', $(this).prop("checked"));
});
//deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
$('.checkbox').change(function () {
    ////".checkbox" change 
    if ($('.checkbox:checked').length == $('.checkbox').length) {
        $('.checked_all').prop('checked', true);
    } else {
        $('.checked_all').prop('checked', false);
    }
});

$(function () {
    $(".checkbox_enabled").click(function () {
        $('.enabled_changeStatus').prop('disabled', $('input.checkbox:checked').length == 0);
    });
});

$('.mytable input:checkbox').change(function () {
    $("#btnClick").prop("disabled", $('.mytable input:checkbox:checked').length === 0);
});


$(document).on('click', '.multiple_checked', function (event) {
    event.preventDefault();
    let status = [];
    let id = [];
    $(':checkbox:checked').each(function (i) {
        status = ($(this).hasClass("btn-success")) ? 0 : 1;
        id = $(this).attr('data-id');
        url = "status/{id}/{status}";
        $.ajax({
            type: "POST",
            url: url,
            data: {"id": id, "status": status, _token: $('meta[name="csrf-token"]').attr('content')},
            success: function (result) {
                location.reload();
            }
        });
    });
});

$(document).on('click', '.viewAccountRefersh', function () {
    location.reload(true);
});
/////////////this script for add new users for superadmin //////////////
$(document).on('change', '.select_role', function () {
    let select_role = $('.role').val();
    if (select_role == 7) {
        $(".account_users").hide();
    } else {
        $(".account_users").show();
    }
});

$(document).ready(function () {
    let select_role = $('.role').val();
    if (select_role == 7) {
        $(".account_users").hide();
    } else {
        $(".account_users").show();
    }
});

$(document).on('click', '.check_email', function (e) {
    let focusSet = false;
    let select_role = $('.role_id').val();
    let userinput = $('#email').val();
    let pattern = /(.*)@(kissingersolutions)\.com/i;
    if (select_role == 7 && !pattern.test(userinput))
    {
        if ($("#email").parent().next(".validation").length == 0) // only add if not added
        {
            $("#email").parent().after("<div class='validation'>Please enter valid email address related to kissingersolutions.com</div>");
        }
        e.preventDefault(); // prevent form from POST to server
        $('#email').focus();
        focusSet = true;
    } else {
        $("#email").parent().next(".validation").remove(); // remove it
    }
});

$(document).ready(function () {
    let srole = $('.role').val();
    if (srole == 7) {
        $(".hideAccountUser").hide();
    }
});

$(document).on('click', '.check_value', function () {
    let select_role = $('.role_id').val();
    let accountUser = $('#check_account').val();
    if (select_role != 7 && accountUser == "")
    {
        alert("Please select account User");
        return false;
    }
});

// for delete alert for user
$(document).ready(function () {
    $(".del").click(function () {
        if (!confirm("Do you want to delete")) {
            return false;
        }
    });
});

/////////////End script for add new users for superadmin//////////////

/////////////this script for test connection for account for superadmin//////////////
$(document).ready(function () {
    $(document).on('click', '.test_connection', function () {
        let server = $('#server').val();
        let port = $('#port').val();
        let database_name = $('#database_name').val();
        let username = $('#username').val();
        let password = $('#password').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "getTestConnection",
            data: {"server": server, "port": port, "database_name": database_name, "username": username, "password": password},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                if (data.success == true) {
                    swal("Connection Success");
                } else {
                    printErrorMsg(data.error);
                }
            }, error: function (jqXHR) {
                // error in the console
                let errors = jqXHR.responseJSON;
                console.log(errors.message);
                let exceptionMessage = errors.message;
                swal({
                    title: "Connection Failed.",
                    text: "" + exceptionMessage + "",
                });
            }
        });
        return false;
    });
    function printErrorMsg(msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display', 'block');
        $.each(msg, function (key, value) {
            $(".print-error-msg").find("ul").append('<li>' + value + '</li>');
        });
    }
});

$(document).ready(function () {
    $(document).on('click', '.test_edit_connection', function () {
        let server = $('#server').val();
        let port = $('#port').val();
        let database_name = $('#database_name').val();
        let username = $('#username').val();
        let password = $('#password').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/getEditTestConnection",
            data: {"server": server, "port": port, "database_name": database_name, "username": username, "password": password},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                if (data.success == true) {
                    swal("Connection Success");
                } else {
                    printErrorMsg(data.error);
                }
            }, error: function (jqXHR) {
                let errors = jqXHR.responseJSON;
                let exceptionMessage = errors.message;
                swal({
                    title: "Connection Failed.",
                    text: "" + exceptionMessage + "",
                });
            }
        });
        return false;
    });
    function printErrorMsg(msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display', 'block');
        $.each(msg, function (key, value) {
            $(".print-error-msg").find("ul").append('<li>' + value + '</li>');
        });
    }
});
/////////////End this script for test connection for account for superadmin//////////////

/////////////this script for view users for admin on portal //////////
$(function () {
    $(".get_user_data").click(function () {
        let id = $(this).attr('data-id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "/getUserDataById/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                htmlData = '<div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Name</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['name']) + ' readonly></div></div><div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Email</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['email']) + ' readonly></div></div>';
                $('.modal-body').html(htmlData);
                $("#MyPopup").modal("show");
            }, error: function (jqXhr) {
                // Log in the console
                let errors = jqXhr.responseJSON;
                console.log(errors);
            }
        });
        return false;
    });
});
////////////////////////////////////// END//////////////////////////////////////////////

// this script is used for change password
$(function () {
    $(".get_password").click(function () {
        let id = $(this).attr('data-id');
        //alert(id);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "changePassword/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                htmlData = '';
                $('.changePassword-body').html(data);
                $("#changePasswordPopup").modal("show");
            }
        });
        return false;
    });
});


//this script for get account users for searching audit log
$('#refrsh').click(function () {
    location.reload();
});

$(document).on('change', '.get_accountsId', function () {
    $.fn.dataTable.ext.errMode = 'none';
    let acountsId = $(this).val();
    $("#preloader").show();
    $('#pages-table').DataTable({
        "bProcessing": true,
        "bServerSide": true,
        "destroy": true,
        "sServerMethod": "GET",
        "fnDrawCallback": function (oSettings) {
            $("#pages-table_processing").hide();
        },
        "fnPreDrawCallback": function (oSettings) {
            $("#pages-table_processing").show();
        },
        "fnServerParams": function (aoData) {
            aoData.push({"name": "_token", "value": "{{csrf_token()}}"});
        },
        "oLanguage": {"sProcessing": "<img src='/image/loader.gif'>", 'sLoadingRecords': '&nbsp;', },
        "sAjaxSource": "getKaiauditlog/" + acountsId, //.replace('id', acountsId),
        "aoColumnDefs": [
            {
                "mDataProp": "logtype",
                "aTargets": [0],
            },
            {
                "mDataProp": "logcategory",
                "aTargets": [1],
                "bSortable": false,
            },
            {
                "mDataProp": "logmessage",
                "aTargets": [2],
                "bSortable": false,
            },
            {
                "mDataProp": "created",
                "aTargets": [3],
                "bSortable": false,
            },
        ]
    });
});

//this script for get account users for searching audit log
$(document).ready(function () {
    let acountsId = $("#accountId").val();
    //alert(acountsId);
    $('#page-tables').DataTable({
        "bProcessing": true,
        "bServerSide": true,
        "sServerMethod": "GET",
        "fnDrawCallback": function (oSettings) {
            $("#pages-table_processing").hide();
        },
        "fnPreDrawCallback": function (oSettings) {
            $("#pages-table_processing").show();
        },
        "fnServerParams": function (aoData) {
            aoData.push({"name": "_token", "value": "{{csrf_token()}}"});
        },
        "oLanguage": {"sProcessing": "<div class='loader'>Loading...</div>", 'sLoadingRecords': '&nbsp;', },
        "sAjaxSource": "/auditlog/" + acountsId, //.replace('id', acountsId),
        "aoColumnDefs": [
            {
                "mDataProp": "logtype",
                "aTargets": [0],
            },
            {
                "mDataProp": "logcategory",
                "aTargets": [1],
                "bSortable": false,
            },
            {
                "mDataProp": "logmessage",
                "aTargets": [2],
                "bSortable": false,
            },
            {
                "mDataProp": "created",
                "aTargets": [3],
                "bSortable": false,
            },
        ]
    });
});


//this script use for page refesh
$('#auditRefesh').click(function () {
    location.reload();
});

//this script is user for mysql connection
$(document).on('click', '.check_status', function () {
    let acountsId = $("#accountId").val();
    alert(acountsId);
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "GET",
        url: "/checkMysqlConnection/{id}",
        data: {"id": acountsId},
        dataType: 'json',
        success: function (data) {
            console.log(data);
            if (data.success == true) {
                $('#onLine').html("online");
            }
        }, error: function (jqXHR) {
            let errors = jqXHR.responseJSON;
            $("#onLine").html("ofline");
            $(".modal-box").css('background-color', '#ff000094');
        }
    });
});

//this script is user for differnet database connection
//this script is user for differnet database connection for status page
$(document).ready(function () {
    types = [];
    $("input[id='kaiConnectionId']").each(function () {
        let acountsId = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "/checkStatus/{id}",
            data: {"id": acountsId},
            dataType: 'json',
            success: function (res) {
                let status = (res.success ? 'Online' : 'Offline');
                let color = (res.success ? 'green' : 'red');
                let icon = (res.success ? 'fas fa-check-circle circle' : 'fas fa-exclamation-circle');
                let getName = '';
                $.each(res.acountName, function (key, value) {
                    getName +=
                            '<div class="col-xl-4 col-lg-6 col-md-12 form-group">' +
                            '<div class="border-space modal-box-2 vl" style="border-left: 6px solid ' + color + ' ;">' +
                            '<label for="inputPassword" class="col-sm-6 col-form-label p-t5 status" id="accountName">' + value + '</label>' +
                            '<div class="col-sm-12 pL0">' +
                            '<div class="col-sm-12 text-left btn-spacing status-1"><div id="online">' + status + '</div></div>' +
                            '<i class="' + icon + ' circle" style="color:' + color + '"></i>' +
                            '</div>' +
                            '</div>' +
                            '</div>';
                });
                $('.status_row').append(getName);
            }, error: function (jqXHR, res) {
                let errors = jqXHR.responseJSON;
            }
        });
    });
});


//save value of input on refesh page

$('#roleVal').on('change', function () {
    // Save value in localstorage
    localStorage.setItem("mov_type", $(this).val());
});
$(document).ready(function () {
    if ($('#roleVal').length) {
        $('#roleVal').val(localStorage.getItem("mov_type"));
    }
});

$(document).ready(function () {
    localStorage.removeItem("mov_type");
});


let selectedItem = sessionStorage.getItem("SelectedItem");
$('#dropdown').val(selectedItem);

$('#dropdown').change(function () {
    let dropVal = $(this).val();
    sessionStorage.setItem("SelectedItem", dropVal);
});

$(document).ready(function () {
    sessionStorage.removeItem("SelectedItem");
});

//asked the password before delete an account on view account page for superadmin
$(document).on('click', '.deleteAccount', function () {
    let deleteId = $(this).attr('data-href');
    if (confirm("Warning: Deleting the account will remove the account and all records associated with the account, including: users, connections and notifications.")) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "/getAccountPassword/{id}",
            data: {"id": deleteId},
            dataType: 'json',
            success: function (data) {
                console.log(data.password);
                $('#accountId').val(data.result[0]['id']);
                $('#accountName').val(data.result[0]['name']);
                $('#oldPassword').val(data.password);
                $("#MyDeleteAccountPopup").modal("show");
            }
        });
        return false;
    }
    return false;
});


//asked password before delete an account and all associated data  
$(document).ready(function () {
    $(document).on('click', '#deleteAccountUser', function () {
        let accountId = $("#accountId").val();
        let accountName = $("#accountName").val();
        let oldPassword = $('#oldPassword').val();
        let confirmPassword = $('#confirmPassword').val();
        if (confirmPassword != "")
        {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/deleteAccountUser",
                data: {"id": accountId, "password": oldPassword, "confirmPassword": confirmPassword},
                dataType: 'json',
                success: function (data) {
                    if (data.success == true) {
                        swal({
                            title: "Deleted!",
                            text: "Account " + accountName + " and all associated data deleted successfully.",
                            type: "success",
                            timer: 8000
                        });
                        window.setTimeout(function () {
                            // Move to a new location or you can do something else
                            window.location.href = data.url;
                        }, 7000);
                    } else {
                        swal('Password is not valid');
                    }
                }
            });
            return false;
        } else {
            swal("Password is required");
        }
    });
});


/////////// Change Password of particular user for superadmin///////////////////
$(function () {
    $(".get_password").click(function () {
        let id = $(this).attr('data-id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "/changePassword/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                //console.log(data);
                //console.log(data.res[0].password);        
                $('#userId').val(data.res[0].id);
                $('#old_pass').val(data.res[0].password);
                $('#userName').val(data.res[0].name);
                $("#changePasswordPopup").modal("show");
            }
        });
        return false;
    });
});
//This script for view users for superadmin
$(function () {
    $(".get_data").click(function () {
        let id = $(this).attr('data-id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "getDataById/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                htmlData = '<div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Name</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['name']) + ' readonly></div></div><div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Email</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['email']) + ' readonly></div></div>';
                $('.modal-body').html(htmlData);
                $("#MyPopup").modal("show");
            }
        });
        return false;
    });
});
////////////////////////////////////// ENDSCRIPT ///////////////////////////////////

$(document).ready(function () {
    $(document).on('click', '.updatePassword', function () {
        let userId = $('#userId').val();
        let oldPwd = $('#old_pass').val();
        let newPwd = $('#new_pass').val();
        let confirmPwd = $('#confirm_pass').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/updatePassword",
            data: {"id": userId, "oldPwd": oldPwd, "newPwd": newPwd, "confirmPwd": confirmPwd},
            dataType: 'json',
            success: function (data) {
                console.log(data.success);
                if (data.success == true) {
                    swal({
                        text: "Password update successfully.",
                        type: "success",
                        timer: 5000
                    });
                    window.setTimeout(function () {
                        // Move to a new location or you can do something else
                        window.location.href = data.url;
                    }, 5000);
                } else {
                    printErrorMsg(data.error);
                }
            }
        });
        return false;
    });
    function printErrorMsg(msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display', 'block');
        $.each(msg, function (key, value) {
            $(".print-error-msg").find("ul").append('<li>' + value + '</li>');
        });
    }
});

/////////////////////////////////////END//////////////////////////////////////////////

$(document).ready(function(){
    $('.processBtn').hide();
    $('.failedBtn').hide();
});


$(document).on('click', '#date-range0', function () {
    $(".processBtn").removeAttr('style'); 
});

$(document).on('click', '#date-range4', function () {
    $('.failedBtn').show();
});

//////////////////////////For Fail//////////////////////////////////////////////
$(document).on('click', '.showFailStatus', function () {
    $("#preloader").show();
    $('.date-picker-wrapper').hide();
            $('.failedBtn').hide();
    let accountId = $("#accountId").val();
    let dateFailed = $("#date-range4").val();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/showFailedStatus",
        data: {"id": accountId, "dateFailed": dateFailed},
        dataType: 'json',
        success: function (data) {
            $('.date-picker-wrapper').hide();
            $('.failedBtn').hide();
            $("#preloader").hide();
            let items = "";
            let orders = "";
            let customers = "";
            if(data.failedItem === null && data.failedOrder === null && data.failedCustomer === null)
            {
                items = null;
                orders = null;
                customers = null;
                swal('Data not found  for this date-'+data.startDate);
            } else if(data.failedItem !== null && data.failedOrder === null && data.failedCustomer === null)
            {
                items = data.failedItem[1];               
                orders = null;
                customers = null;
            }else if(data.failedItem !== null && data.failedOrder !== null && data.failedCustomer === null)
            {
                customers = null;
                items = data.failedItem[1];
                orders = data.failedOrder[1];
            }else if(data.failedItem !== null && data.failedOrder !== null && data.failedCustomer !== null)
            {
                items = data.failedItem[1];
                orders = data.failedOrder[1];
                customers = data.failedCustomer[1];
            }else if(data.failedItem === null && data.failedOrder !== null && data.failedCustomer === null)
            {
                items = null;                
                customers = null;
                orders = data.failedOrder[1];
            }else if(data.failedItem === null && data.failedOrder !== null && data.failedCustomer !== null)
            {
                items = null;
                orders = data.failedOrder[1];
                customers = data.failedCustomer[1];
            }else if(data.failedItem === null && data.failedOrder === null && data.failedCustomer !== null)
            {
                items = null;
                orders = null;
                customers = data.failedCustomer[1];
            }else if(data.failedItem !== null && data.failedOrder === null && data.failedCustomer !== null)
            {
                orders = null;
                items = data.failedItem[1];
                customers = data.failedCustomer[1];
            }else {
                orders = data.failedOrder[1];
                console.log(orders);
                 console.log(items);
                customers = data.failedCustomer[1];
            }
            console.log('order - ' + orders);
            console.log('items -' + items);
            console.log('customers -' +customers);
                let orderProgressBar = '<div class="progress-bar bg-danger orderProgressBar" role="progressbar" style="width: '+orders+'%" aria-valuenow="'+orders+'" aria-valuemin="0" aria-valuemax="100"></div>';
          
                let itemProgressBar = '<div class="progress-bar bg-warning itemProgressBar" role="progressbar" style="width: '+items+'%" aria-valuenow="'+items+'" aria-valuemin="0" aria-valuemax="100"></div>'
                let customersProgressBar = '<div class="progress-bar customersProgressBar" role="progressbar" style="width: '+customers+'%" aria-valuenow="'+customers+'" aria-valuemin="0" aria-valuemax="100"></div>'
                $('.failOfOrders').html(orders);
                $('.orderProgressBar1').html(orderProgressBar);
                $('.failOfItems').html(items);
                $('.itemProgressBar1').html(itemProgressBar);
                $('.failOfCustomers').html(customers);
                $('.customersProgressBar1').html(customersProgressBar);
           
        }
    });
    return false;
});

////////////////// Delete data and save data on refresh button in kaiconnection table/////////////////////
$(document).on('click', '.refresh', function () {
    let accountId = $('#accountIdRefresh').val();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/refreshConnection",
        data: {"id": accountId},
        dataType: 'json',
        success: function (response) {
            if (response.success == true)
            {
                let numOfRow = response.numOfRow;
                swal({
                    title: "Connection Refersh successfully.",
                    text: "Number of account refresh  " + numOfRow + "",
                });
            } else {
                swal('Connection failed');
            }
        }
    });
    return false;
});

/////////////////////////////// END///////////////////////////////

///////////////Validation for check Multiple account////////////////
$(document).ready(function () {
    window.account_val = $('#check_account').val();

});
$(document).on('change', '.checkAccountName', function (e) {
    let element = $(this);
    let accountId = e.currentTarget.value;
    if (window.account_val.indexOf(accountId) > -1) {
        return;
    }
    let check_account = $('#check_account').val();
    let email = $('#email').val();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/checkAccount",
        data: {"id": accountId, 'email': email},
        dataType: 'json',
        success: function (response) {
            if (response.count > 0)
            {
                let index = check_account.indexOf(accountId);
                check_account.splice(index, 1);
                element.val(check_account).trigger('change');
                alert(" This account is already associated with current User");
            }
        }
    });
});

//////////////////////////////////////////END/////////////////////////////

////////////////This script for view notification for superadmin///////////////////////////
$(function () {
    $(".getNotification").click(function () {
        let id = $(this).attr('data-id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "GET",
            url: "getNotificationById/{id}",
            data: {"id": id},
            dataType: 'json',
            success: function (data) {
                console.log(data);
                htmlData = '<div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Name</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['name']) + ' readonly></div></div><div class="form-group row"><label class="col-md-2 col-form-label text-md-right">Description</label><div class="col-md-10"><input type="text" class="form-control" value=' + JSON.stringify(data.res[0]['description']) + ' readonly></div></div>';
                $('.modal-body').html(htmlData);
                $("#MyPopup").modal("show");
            }
        });
        return false;
    });
});
////////////////////////////////////// ENDSCRIPT ///////////////////////////////////


/////////////////This for active and inactive notification Status ///////////////////////
$(document).on('click', '.notification', function () {
    let notificationName = $(this).closest('tr').children('td.name').text();
    let status = ($(this).hasClass("btn-success")) ? 0 : 1;
    let msg = (status == 0) ? 'disable' : 'enable';
    if (confirm("Would you like to " + msg + ' ' + notificationName + " ?"))
    {
        let id = jQuery(this).attr('notification_id');
        url = "notificationStatus/{id}/{status}";
        $.ajax({
            type: "POST",
            url: url,
            data: {"id": id, "status": status, _token: $('meta[name="csrf-token"]').attr('content')},
            success: function (result) {
                //location.reload();
                if (result.success == true) {
                    window.location = result.url;
                } else {
                    window.location = result.url;
                }
            }
        });
    }
});
////////////////////////////////////// ENDSCRIPT ///////////////////////////////////

/////////////////Enabled or disabled configure based on status  ///////////////////////
$(document).ready(function () {
    $('.notificationStatus .allNotification').each(function () {
        let status = $(this).attr('data-id');
        if (status == 1)
        {
            $(this).next().removeClass("disabled");
        } else {
            $(this).next().addClass("disabled");
        }
    });
});
////////////////////////////////////// ENDSCRIPT ///////////////////////////////////

$(document).ready(function () {
    $('.notifiStatus .adminConfig').each(function () {
        let status = $(this).attr('data-id');
        if (status == 1)
        {
            $(this).next().removeClass("disabled");
        } else {
            $(this).next().addClass("disabled");
        }
    });
});

////////////// Add or remove text field on click on configuration file//////////////
$(document).on('click', '.add_account', function () {
    let account_name = $("#account_name option:selected").text();
    let accountId = $("#account_name").val();
    if (account_name == "" || account_name == "Select Account")
    {
        alert("Please Select Account");
    } else {
        $("#notificationEnabled").append("<option value='" + accountId + "'>" + account_name + "</option>");
        $('#notificationEnabled option').prop('selected', true);
    }
    return false;
});

$(document).on('click', '.remove_account', function () {
    let account_name = $("#notificationEnabled").val();
    $("#notificationEnabled option[value='" + account_name + "']").remove();
    return false;
});

////////// For Add Recipeint/////////////////////
$(document).on('keyup', '.recipentemail', function () {
    let email = $("#recipentemail").val();
    let filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(email)) {
        $("#error_email").text(email + " is not a valid email");
        email.focus;
    } else {
        $("#error_email").text("");
    }
    if (email == "")
    {
        $("#error_email").html("");
    }
});

$(document).on('click', '.addRecip', function () {
    let email = $("#recipentemail").val();
    let filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(email)) {
        //alert('Please provide a valid email address');
        $("#error_email").text(email + " is not a valid email");
        email.focus;
        //return false;
    } else {
        $("#error_email").text("");
    }
    if (email == "")
    {
        $("#error_email").html("");
    }
});

$(document).on('click', '.recipList', function () {
    let recipEmail = $(this).val();
    console.log(recipEmail);
    if (recipEmail.length > 0)
    {
        $('#enableRemove').prop('disabled', false);
    }
});

$(document).on('click', '.notifiList', function () {
    let notifiList = $(this).val();
    if (notifiList.length > 0)
    {
        $('#enableNoti').prop('disabled', false);
    }
});

$(document).on('click', '.add_recipeint', function () {
    let recipentemail = $("#recipentemail").val();
    if (recipentemail == "") {
        alert("Recipient Email Address is required");
    } else {
        $("#recipeint_list").append("<option value='" + recipentemail + "'>" + recipentemail + "</option>");
        $("#recipentemail").val("").html("");
        $('#recipeint_list option').prop('selected', true);
    }
    return false;
});

$(document).on('click', '.remove_recipeint', function () {
    let recipeint_list = $("#recipeint_list").val();
    $("#recipeint_list option[value='" + recipeint_list + "']").remove();
    return false;
});
////////////////////////////END SCRIPT///////////////////////////////////////////

////////////////// for delete alert for notification///////////////////
$(document).ready(function () {
    $(".delNotifi").click(function () {
        if (!confirm("Do you want to delete")) {
            return false;
        }
    });
});
//////////////////////////////////////

/////////////////This for active and inactive notification Status From User ///////////////////////
$(document).on('click', '.userNotification', function(){
  var notificationName = $(this).closest('tr').children('td.nameNotifi').text();        
  var status = ($(this).hasClass("btn-success")) ? 0 : 1;
  var msg = (status==0)? 'disable' : 'enable';
  if(confirm("Would you like to "+msg +' ' +notificationName+ " ?"))
  {
    var id = jQuery(this).attr('notificationId');     
    url = "/userNotification/{id}/{status}";
      $.ajax({
          type:"POST",
          url: url, 
          data: {"id":id,"status":status, _token: $('meta[name="csrf-token"]').attr('content')}, 
          success: function(result) {
            if (result.success == true) {
              window.location = result.url;
            }else{
              window.location = result.url;          
            }        
        } 
    });
  }  
});
////////////////////////////////////// ENDSCRIPT ///////////////////////////////////

$(document).ready(function(){
  $(document).on('click', '#testNotification', function(){
    let account = [];
    let recipeint_list = [];
    let notificationId = $('#notificationId').val();
    $('#notificationEnabled option:selected').each(function() {
       account.push($(this).text());
    });    
    $('#recipeint_list option:selected').each(function() {
      recipeint_list.push($(this).val());       
    });
    $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      $.ajax({
        type:"POST",
        url:"/test_notification",
        data:{"id":notificationId, "recipeint_email_list":recipeint_list, "account": account },
        dataType: 'json',
        success:function(data){
            if (data.success == true) {
                    swal(data.message);
                } else {
                    swal("Notification not send");
                }
            }                     
        }); 
    return false;
  });
});

///////////////This is for Add Parameter input field
$(document).on('click', '.addParameter', function(){
    let notificationId = $('#addParameter').data('id');
    //console.log(notificationId);
     $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/notificationId",
        data: {"notification_id": notificationId},
        dataType: 'json',
        success: function (response) {
            $('#notifiId').val(response.notifi_id.notification_id);
            $('#addRow').prop('disabled', true);
            console.log(response);
            $.each(response.parameter, function(i, e){
                let paramLevel = response.parameter[i].parameter;
                //let paramLevel = parmlev.split('"');
                console.log(paramLevel);
                let paramVal = response.parameter[i].parameter_value;
                let description = response.parameter[i].description;
                let paramId = response.parameter[i].id;
                let accountId = response.parameter[i].account_id;
                console.log(paramId);
                let paramType = response.parameter[i].parameter_type;
                console.log('paramType'+paramType);
                if(paramVal === null && accountId === null)
                {
                    let html = ' ';
                    html += '<input type="hidden" name="id" id="" class="paramId" value="'+paramId+'">';
                    html += '<div class="col-md-2 mb-2 d-flex align-items-center pl-22"><label class="m-0" for="recipentemail">'+paramLevel+'</label></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><textarea name="description[]" class="form-control desc" style="height:auto;" placeholder="Description"></textarea></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><select id="parameter_type" name="parameter_type[]" class="form-control parameter_type"><option value="integer">Integer</option><option value="string">String</option><option value="date">Date</option></select></div>';
                    html += '<div class="col-md-3 mb-2 pr-0"><input type="text" name="parameter_value[]" class="form-control parameter_value param_values" placeholder="Parameter Value" autocomplete="off"></div>';
                    html += '<div class="col-md-12 error_parameterType" style="color: red;margin-left: 525px;"></div>';
                    $("#container").html(html);
                }else if(accountId === null){
                    let html = ' ';
                    var intType = (paramType == "integer") ? "selected" : "";
                    var strType = (paramType == "string") ? "selected" : "";
                    var dateType = (paramType == "date") ? "selected" : "";
                    html += '<input type="hidden" name="id" id="" class="paramId" value="'+paramId+'">';
                    html += '<div class="col-md-2 mb-2 d-flex align-items-center pl-22"><label class="m-0" for="recipentemail">'+paramLevel+'</label></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><textarea name="description[]" class="form-control desc" style="height:auto;" placeholder="Description" value="">'+description+'</textarea></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><select id="parameter_type" name="parameter_type[]" class="form-control parameter_type"><option value="integer" '+intType+'>Integer</option><option value="string" '+strType+'>String</option><option value="date" '+dateType+'>Date</option></select></div>';
                    html += '<div class="col-md-3 mb-2 pr-0"><input type="text" name="parameter_value[]" class="form-control parameter_value param_values" placeholder="Parameter Value" autocomplete="off" value="'+paramVal+'"></div>';
                    html += '<div class="col-md-12 error_parameterType" style="color: red;margin-left: 525px;"></div>';
                    $("#container").html(html);
                }
                else {
                    console.log("not found"); 
                }
                                   
            });                       
            $('#addParameterPopup').modal('show');
        }
    });    
});

$(document).on('keypress', '.param_values', function(e){
    let paramVal = $(this).val();
    let intVal = $(this).parent().prev().find('select').val();
    if(intVal == 'integer')
    {    
        if($.isNumeric(paramVal) === false) {
            //chop off the last char entered
            this.value = this.value.slice(0,-1);
            $(this).parent().next('.error_parameterType').html("Digits Only").show();
        }
        else {
            $(this).parent().next('.error_parameterType').html("");
        }        
    } else if(intVal == 'string') {
        let inputValue = event.charCode;
        if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
            e.preventDefault();
            $(this).parent().next('.error_parameterType').html("Alphabets Only").show();
        }else {
            $(this).parent().next('.error_parameterType').html("");
        } 
    } else {
        if(isDate(paramVal))
            $(this).parent().next('.error_parameterType').html("");
        else
            $(this).parent().next('.error_parameterType').html("Date format like as YYYY--MM--DD").show();
   
    
        function isDate(txtDate)
        {
            var currVal = txtDate;
            if(currVal == '')
                return false;
            
            var rxDatePattern = /([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/; //Declare Regex
            var dtArray = currVal.match(rxDatePattern); // is format OK?
            
            if (dtArray == null) 
                return false;
            
            //Checks for mm/dd/yyyy format.
            dtMonth = dtArray[1];
            dtDay= dtArray[3];
            dtYear = dtArray[4];        
            
            if (dtMonth < 1 || dtMonth > 12) 
                return false;
            else if (dtDay < 1 || dtDay> 31) 
                return false;
            else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
                return false;
            else if (dtMonth == 2) 
            {
                var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
                if (dtDay> 29 || (dtDay ==29 && !isleap)) 
                        return false;
            }
            return true;
        }   
    }
});

$(document).on('click', '#saveParameter', function(){
    let notificationId = $('#notificationId').val();
    let paramId = [];//$("#paramId").val();
    let parameterType = [];
    let description = [];
    let parameterValue = [];
    $(".paramId").each(function (index, item) {
        paramId.push($(item).val());
        console.log("paramId")
    });
    $(".desc").each(function (index, item) {
        description.push($(item).val());
    });
    $(".parameter_type").each(function (index, item) {
        parameterType.push($(item).val());
    });

    $(".parameter_value").each(function (index, item) {
        parameterValue.push($(item).val());
        //console.log('parameterValue '+parameterValue);
    });
    if(description != "" || parameterValue != "")
    {   
     console.log('not empty');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/saveParameter",
            data: {"id":paramId, "notification_id": notificationId, "parameter_type":parameterType, "parameter_value":parameterValue, "description":description},
            dataType: 'json',
            success: function (response) {
                if(response.success == true)
                {
                    swal('Parameter save successfully');
                    setTimeout(function(){// wait for 5 secs(2)
                        location.reload(); // then reload the page.(3)
                    }, 5000);
                }           
            }
        }); 
    }else {
        alert('Please Provide description with parameter value');
    }
    return false; 
});

var i = 2;
$(document).on('click', '#addRow', function(){
        var html = '';
        html += '<div id="inputFormRow">';
        html += '<div class="input-group mb-3">';
        html += '<label for="recipentemail" class="col-md-4" style="margin-left: -20px;">Parameter'+i+'</label><input type="text" name="parameter_type[]" class="form-control m-input parameter_type" placeholder="Parameter Type" autocomplete="off" style="width: 138px;margin-left: -25px;"><input type="text" name="parameter_value[]" class="form-control m-input parameter_value" placeholder="Parameter Value" autocomplete="off" style="width: 130px;">';
        html += '<div class="input-group-append" style="margin-right: -80px;">';
        html += '<button id="removeRow" type="button" class="btn btn-danger">Remove</button>';
        html += '</div>';
        html += '</div>';
        $('#newRow').append(html);
        i++;
});
// remove row
$(document).on('click', '#removeRow', function () {
    $(this).closest('#inputFormRow').remove();
    i--;
});

///////////////This is for Add Parameter input field
$(document).on('click', '.addUserParameter', function(){
    let notificationId = $('#addUserParameter').data('id');
    //console.log(notificationId);
     $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/userNotificationId",
        data: {"notification_id": notificationId},
        dataType: 'json',
        success: function (response) {
            console.log(response.result);
            $.each(response.result, function(i, e){
                let paramLevel = response.result[i].parameter;
                console.log('------------'+paramLevel);
                let paramVal = response.result[i].parameter_value;
                let description = response.result[i].description;
                let paramId = response.result[i].id;
                let accId = response.result[i].account_id;
                let authId = response.result[i].auth_id;
                let parameter_status = response.result[i].parameter_status;
                let notification_id = response.result[i].notification_id;
                //console.log(accId);
                let paramType = response.result[i].parameter_type;
                if(notification_id === null){
                    console.log('----1221---');
                    let html = ' ';
                    html += '<input type="hidden" name="id" id="" class="paramId" value="'+paramId+'">';
                    html += '<input type="hidden" name="parameter[]" id="" class="parameterLevel" value="'+paramLevel+'">';
                    html += '<div class="col-md-4 mb-2 pl-0"><textarea name="description[]" class="form-control desc" style="height:38px;margin-left: 41px;" placeholder="Description" readonly>'+description+'</textarea></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><input type="hidden" id="parameter_type" name="parameter_type[]" class="form-control parameter_type" value="'+paramType+'" readonly></div>';
                    html += '<div class="col-md-3 mb-2 pr-0"><input type="text" name="parameter_value[]" class="form-control parameter_value" placeholder="Parameter Value" value="'+paramVal+'"></div>';
                    html += '<label id="error_parameterTypes" style="color: red;"></label>';
                    $("#container").html(html);
                }
                else{
                    console.log('----1233---------');
                    let html = ' ';
                    html += '<input type="hidden" name="id" id="" class="paramId" value="'+paramId+'">';
                    html += '<input type="hidden" name="parameter[]" id="" class="parameterLevel" value="'+paramLevel+'">';
                    html += '<div class="col-md-3 mb-2 pl-0"><textarea name="description[]" class="form-control desc" placeholder="Description" style="height:38px;margin-left: 41px;" readonly>'+description+'</textarea></div>';
                    html += '<div class="col-md-3 mb-2 pl-0"><input type="hidden" id="parameter_type" name="parameter_type[]" class="form-control parameter_type" value="'+paramType+'" readonly></div>';
                    html += '<div class="col-md-3 mb-2 pr-0"><input type="text" name="parameter_value[]" class="form-control parameter_value" placeholder="Parameter Value" value="'+paramVal+'"></div>';
                    html += '<label id="error_parameterTypes" style="color: red;"></label>';
                    $("#container").html(html);
                }                   
            });                       
            $('#addUserParameterPopup').modal('show');
        }
    });    
});

$(document).on('click', '#saveUserParameter', function(){
    let notificationId = $('#notificationId').val();
    let paramId = [];
    let parameterType = [];
    let description = [];
    let parameterValue = [];
    let parameterLevel = [];
    $(".paramId").each(function (index, item) {
        paramId.push($(item).val());
    });
    $(".parameterLevel").each(function (index, item) {
        parameterLevel.push($(item).val());
        console.log("parameterLevel")
    });
    $(".desc").each(function (index, item) {
        description.push($(item).val());
    });
    $(".parameter_type").each(function (index, item) {
        parameterType.push($(item).val());
    });

    $(".parameter_value").each(function (index, item) {
        parameterValue.push($(item).val());
        //console.log('parameterValue '+parameterValue);
    });
    if(parameterValue != "")
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/saveUserParameter",
            data: {"id":paramId, "parameter":parameterLevel, "notification_id": notificationId, "parameter_type":parameterType, "parameter_value":parameterValue, "description":description},
            dataType: 'json',
            success: function (response) {
                if(response.success == true)
                {
                    swal('Parameter save successfully');
                    setTimeout(function(){// wait for 5 secs(2)
                        location.reload(); // then reload the page.(3)
                    }, 5000);
                }           
            }
        });
    }else {
        alert('Please Provide description with parameter value');
    } 
    return false; 
});

