let orders = new Array();
        let items = new Array();
        let customers = new Array();
        $(document).on('click', '.showProcessedStatus', function () {
            $("#processedLoader").show();
            let accountId = $("#accountId").val();
            let dateProcess = $("#date-range0").val();
            console.log('date'+dateProcess);
            let url = "{{url('/showStatusByDate')}}";
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: url,
                data: {"id": accountId, "dateProcess": dateProcess},
                dataType: 'json',
                success: function (data) {
                    if (data.numOfCustomers !== null || data.numOfOrders !== null || data.numOfProducts !== null)
                    {
                        orders = data.numOfOrders[0];
                        customers = data.numOfCustomers[0];
                        items = data.numOfProducts[0];
                        $("#processedLoader").hide();
                        $('.date-picker-wrapper').hide();
                        $('.processBtn').hide();
                        var ctx = document.getElementById("myPieChart");
                        var myPieChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: ["Orders", "Items", "Customers"],
                                datasets: [{
                                        data: [orders, items, customers],
                                        backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
                                        hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
                                        hoverBorderColor: "rgba(234, 236, 244, 1)",
                                    }],
                            },
                            options: {
                                maintainAspectRatio: false,
                                tooltips: {
                                    backgroundColor: "rgb(255,255,255)",
                                    bodyFontColor: "#858796",
                                    borderColor: '#dddfeb',
                                    borderWidth: 1,
                                    xPadding: 15,
                                    yPadding: 15,
                                    displayColors: false,
                                    caretPadding: 10,
                                },
                                legend: {
                                    display: false
                                },
                                cutoutPercentage: 80,
                            },
                        });
                    } else {
                        $('.date-picker-wrapper').hide();
                        $('.processBtn').hide();
                        $("#processedLoader").hide();
                        swal('Data not found  for this date-' + data.startDate);
                    }
                }
            });
            return false;
        });