let editor = CKEDITOR.replace('email_body', {
    height: 100
});