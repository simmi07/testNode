<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class KaiconnectionWithAccounts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kaiconnection_with_accounts', function (Blueprint $table) {
            $table->id();            
            $table->integer('account_id');
            $table->string('name');
            $table->string('type')->nullable();
            $table->string('connectionstring')->nullable();
            $table->string('username')->nullable();
            $table->string('password')->nullable();
            $table->string('phpoverlay')->nullable();
            $table->string('heading')->nullable();
            $table->string('dashboard_name')->nullable();
            $table->integer('active')->nullable();
            $table->tinyInteger('status')->nullable();
            $table->string('notify_status')->nullable();
            $table->dateTime('created', 0);
            $table->dateTime('modified', 0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kaiconnection_with_accounts');
    }
}
