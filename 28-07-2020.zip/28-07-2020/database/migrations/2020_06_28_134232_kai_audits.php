<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class KaiAudits extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kai_audits', function (Blueprint $table) {
            $table->id();            
            $table->integer('account_id')->nullable();
            $table->integer('message_id')->nullable();
            $table->string('log_type')->nullable();
            $table->string('log_category')->nullable();
            $table->string('log_message')->nullable();
            $table->tinyInteger('processed')->nullable();
            $table->tinyInteger('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kai_audits');
    }
}
