<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class NewAccounts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('new_accounts', function (Blueprint $table) {
            $table->id();            
            $table->integer('user_id');
            $table->string('name');
            $table->string('username');
            $table->string('password');
            $table->string('server');
            $table->integer('port');
            $table->string('database_name');
            $table->string('portal_url');
            $table->tinyInteger('disable_monitoring');
            $table->tinyInteger('image')->nullable();
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('new_accounts');
    }
}
