<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class KaiConnectionStatuses extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kai_connection_statuses', function (Blueprint $table) {
            $table->id();
            $table->integer('account_id');
            $table->integer('connection_id');
            $table->string('connection_name')->nullable();
            $table->string('failure_message')->nullable();
            $table->integer('health_counter');
            $table->integer('archived');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kai_connection_statuses');
    }
}
