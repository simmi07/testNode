-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2020 at 11:57 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kissinger`
--

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE `configurations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `auth_id` int(11) NOT NULL,
  `notification_id` int(11) NOT NULL,
  `notification_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `recipeintemail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configure_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `auth_id`, `notification_id`, `notification_type`, `account_id`, `recipeintemail`, `configure_url`, `created_at`, `updated_at`) VALUES
(40, 88, 2, 'both', 9, 'khushbu@chetu.com', 'http://127.0.0.1:8000/users/saveAdminConfiguration', '2020-07-11 06:47:20', '2020-07-11 06:47:20'),
(57, 1, 1, 'both', 10, 'simmis@chetu.com', 'http://127.0.0.1:8000/saveConfiguration', '2020-07-17 03:12:53', '2020-07-17 03:12:53'),
(59, 1, 1, 'both', 10, 'simmichetu@gmail.com', 'http://127.0.0.1:8000/saveConfiguration', '2020-07-20 11:23:57', '2020-07-20 11:23:57'),
(60, 1, 2, 'both', 9, 'simmichetu@gmail.com', 'http://127.0.0.1:8000/saveConfiguration', '2020-07-20 11:32:42', '2020-07-20 11:32:42');

-- --------------------------------------------------------

--
-- Table structure for table `configure_parameters`
--

CREATE TABLE `configure_parameters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` int(11) NOT NULL,
  `auth_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `parameter` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `configure_parameters`
--

INSERT INTO `configure_parameters` (`id`, `notification_id`, `auth_id`, `account_id`, `parameter`, `description`, `parameter_type`, `parameter_value`, `parameter_status`, `created_at`, `updated_at`) VALUES
(7, 2, 1, NULL, '$order', 'Add the category id here', 'string', 'Order', 'old', NULL, '2020-07-08 11:04:50'),
(8, 2, 88, 10, '$order', 'enter category order id', 'integer', '9', 'old', '2020-07-07 06:28:17', '2020-07-07 09:07:01'),
(16, 1, 1, NULL, '$accountId', 'accountId', 'integer', '10', NULL, NULL, '2020-08-04 01:57:20'),
(17, 1, 1, NULL, '$logtype', NULL, 'integer', NULL, NULL, NULL, '2020-08-04 03:52:59');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kaiconnection_with_accounts`
--

CREATE TABLE `kaiconnection_with_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connectionstring` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phpoverlay` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `notify_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kaiconnection_with_accounts`
--

INSERT INTO `kaiconnection_with_accounts` (`id`, `account_id`, `name`, `type`, `connectionstring`, `username`, `password`, `phpoverlay`, `heading`, `dashboard_name`, `active`, `status`, `notify_status`, `created`, `modified`, `created_at`, `updated_at`) VALUES
(41, 9, 'Web-Store', 'MySQL', 'host->db130a.pair.com;database->jasonmad_devw;port->;', 'jasonmad_16', 'zvN5yrH2', 'MySQL', 'ConnectDB', 'Web-Stor (SAGE 100)', 1, 1, NULL, '2018-06-07 10:04:07', '2018-07-25 16:52:03', '2020-06-08 05:49:48', '2020-06-08 05:49:48'),
(42, 9, 'PrestaShop', 'Webservice', 'url->https://devps16.kissingersolutions;', NULL, 'C28HKLGXD1497CQ9QTXPA8EUY5D7WH2B', 'PrestaShop', 'PrestaShopDB', 'PrestaShop', 1, 1, NULL, '2018-06-27 10:33:01', '2018-07-25 16:57:55', '2020-06-08 05:49:48', '2020-06-08 05:49:48'),
(43, 9, 'Magento', 'Webservice', 'url->https://devma19.kissingersolutions.com/api/v2_soap?wsdl=1;', 'webstor', 'C28HKLGXD1497CQ9QTXPA8EUY5D7WH2B', 'Magento', 'MagentoDB', 'Magento', 1, 1, NULL, '2018-06-27 10:39:19', '2018-07-25 16:57:55', '2020-06-08 05:49:48', '2020-06-08 05:49:48'),
(44, 9, 'BigCommerce', 'Webservice', 'url->https://store-3lk0je.mybigcommerce.com/api/v2/;client_id->uxkqbu8bwhq6tfiaajyu1n0pv6xoeo;auth_token->2nz9h4mnbdqk3mzcybzqjmn76j5zm3p;store_hash->3lk0je;', '', '', 'BigCommerce', NULL, 'Kissinger BigCommerce', 1, 1, NULL, '2018-07-25 17:17:07', '2019-07-02 11:34:07', '2020-06-08 05:49:48', '2020-06-08 05:49:48'),
(45, 9, 'Shopify', 'Webservice', 'url->kissinger-one.myshopify.com;', 'b687bf8d5f9c85584c0b82b598b762cd', '56a2a175705093bfb476272ed0cd93e1', 'ShopifyConn', NULL, 'Kissinger Shopify', 1, 1, NULL, '2018-07-25 17:17:07', '2018-07-25 17:17:07', '2020-06-08 05:49:48', '2020-06-08 05:49:48'),
(51, 10, 'Web-Store', 'MySQL', 'host->db130a.pair.com;database->jasonmad_devws;port->3306;', 'jasonmad_16', 'zvN5yrH2', 'MySQL', 'ConnectDB', 'Web-Stor (SAGE 100)', 1, 1, 'online', '2018-06-07 10:04:07', '2018-07-25 16:52:03', NULL, NULL),
(52, 10, 'PrestaShop', 'Webservice', 'url->https://devps16.kissingersolutions;', NULL, 'C28HKLGXD1497CQ9QTXPA8EUY5D7WH2B', 'PrestaShop', 'PrestaShopDB', 'PrestaShop', 1, 1, 'online', '2018-06-27 10:33:01', '2018-07-25 16:57:55', NULL, NULL),
(53, 10, 'Magento', 'Webservice', 'url->https://devma19.kissingersolutions.com/api/v2_soap?wsdl=1;', 'webstor', 'C28HKLGXD1497CQ9QTXPA8EUY5D7WH2B', 'Magento', 'MagentoDB', 'Magento', 1, 1, 'online', '2018-06-27 10:39:19', '2018-07-25 16:57:55', NULL, NULL),
(54, 10, 'BigCommerce', 'Webservice', 'url->https://store-3lk0je.mybigcommerce.com/api/v2/;client_id->uxkqbu8bwhq6tfiaajyu1n0pv6xoeo;auth_token->2nz9h4mnbdqk3mzcybzqjmn76j5zm3p;store_hash->3lk0j;', '', '', 'BigCommerce', NULL, 'Kissinger BigCommerce', 1, 1, 'online', '2018-07-25 17:17:07', '2019-07-02 11:34:07', NULL, NULL),
(55, 10, 'Shopify', 'Webservice', 'url->kissinger-one.myshopify;', 'b687bf8d5f9c85584c0b82b598b762cd', '56a2a175705093bfb476272ed0cd93e1', 'ShopifyConn', NULL, 'Kissinger Shopify', 1, 1, 'online', '2018-07-25 17:17:07', '2018-07-25 17:17:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kai_audits`
--

CREATE TABLE `kai_audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `message_id` int(11) DEFAULT NULL,
  `log_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processed` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kai_audits`
--

INSERT INTO `kai_audits` (`id`, `account_id`, `message_id`, `log_type`, `log_category`, `log_message`, `processed`, `status`, `created_at`, `updated_at`) VALUES
(1, 9, NULL, 'Error', 'System', 'PrestaShop offline for Rehrig House Productions', 0, 0, '2020-07-23 05:16:39', '2020-07-23 05:16:39'),
(2, 9, NULL, 'Error', 'System', 'Web-Stor (SAGE 100) offline for Rehrig House Productions', 0, 0, '2020-07-23 05:16:40', '2020-07-23 05:16:40'),
(3, 10, NULL, 'Error', 'System', 'Kissinger BigCommerce offline for SysCorp International', 0, 0, '2020-07-23 05:16:44', '2020-07-23 05:16:44'),
(4, 10, NULL, 'Error', 'System', 'PrestaShop offline for SysCorp International', 0, 0, '2020-07-23 05:22:05', '2020-07-23 05:22:05'),
(5, 10, NULL, 'Error', 'System', 'xyz offline for SysCorp International', 0, 0, '2020-07-23 05:56:44', '2020-07-23 05:56:44'),
(6, 10, NULL, 'Error', 'System', 'Web-Stor (SAGE 100) offline for SysCorp International', 0, 1, '2020-07-26 04:26:49', '2020-07-26 04:26:49'),
(7, 10, NULL, 'Error', 'System', 'Kissinger Shopify offline for SysCorp International', 0, 0, '2020-07-26 04:26:49', '2020-07-26 04:26:49'),
(8, 9, NULL, 'Error', 'System', 'Kissinger Shopify offline for Rehrig House Productions', 0, 1, '2020-07-26 04:27:23', '2020-07-26 04:27:23');

-- --------------------------------------------------------

--
-- Table structure for table `kai_connection_statuses`
--

CREATE TABLE `kai_connection_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `connection_id` int(11) NOT NULL,
  `connection_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failure_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `health_counter` int(11) NOT NULL,
  `archived` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kai_connection_statuses`
--

INSERT INTO `kai_connection_statuses` (`id`, `account_id`, `connection_id`, `connection_name`, `failure_message`, `health_counter`, `archived`, `created_at`, `updated_at`) VALUES
(1, 9, 41, 'Web-Stor (SAGE 100)', 'Web-Stor (SAGE 100) offline Rehrig House Productions', 4, 0, '2020-07-26 05:02:00', '2020-07-26 05:02:00'),
(2, 9, 42, 'PrestaShop', 'PrestaShop offline Rehrig House Productions', 1, 1, '2020-07-26 05:02:00', '2020-07-26 05:02:00'),
(3, 9, 45, 'Kissinger Shopify', 'Kissinger Shopify offline Rehrig House Productions', 1, 1, '2020-07-26 05:02:06', '2020-07-26 05:02:06'),
(4, 10, 51, 'Web-Stor (SAGE 100)', 'Web-Stor (SAGE 100) offline SysCorp International', 2, 1, '2020-07-26 05:02:06', '2020-07-26 05:02:06'),
(5, 10, 52, 'PrestaShop', 'PrestaShop offline SysCorp International', 1, 1, '2020-07-26 05:02:06', '2020-07-26 05:02:06'),
(6, 10, 54, 'Kissinger BigCommerce', 'Kissinger BigCommerce offline SysCorp International', 1, 1, '2020-07-26 05:02:13', '2020-07-26 05:02:13'),
(7, 10, 55, 'Kissinger Shopify', 'Kissinger Shopify offline SysCorp International', 4, 0, '2020-07-26 05:02:13', '2020-07-26 05:02:13'),
(8, 9, 42, 'PrestaShop', 'PrestaShop offline Rehrig House Productions', 1, 0, '2020-07-26 05:13:01', '2020-07-26 05:13:01'),
(9, 10, 52, 'PrestaShop', 'PrestaShop offline SysCorp International', 1, 0, '2020-07-26 05:13:10', '2020-07-26 05:13:10'),
(10, 10, 54, 'Kissinger BigCommerce', 'Kissinger BigCommerce offline SysCorp International', 1, 0, '2020-07-26 05:13:17', '2020-07-26 05:13:17');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(6, '2014_10_12_000000_create_users_table', 1),
(7, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2020_03_05_110813_create_permission_tables', 1),
(10, '2020_03_16_153700_new_account', 2),
(11, '2020_03_16_154525_new_account', 3),
(12, '2020_03_16_155506_new_account', 4),
(14, '2020_03_17_080641_new_account', 5),
(15, '2020_03_19_101952_create_users_table', 6),
(16, '2020_03_19_102511_new_account', 7),
(17, '2020_03_19_103439_create_users_table', 8),
(18, '2020_03_19_105016_new_account', 9),
(19, '2020_03_19_115233_create_users_table', 10),
(20, '2020_03_19_120018_create_users_table', 11),
(21, '2020_03_19_122419_create_users_table', 12),
(22, '2020_03_19_122434_new_account', 12),
(23, '2020_03_31_153356_new_account', 13),
(24, '2020_04_06_100915_create_users_table', 14),
(25, '2020_04_06_153258_new_account', 15),
(26, '2020_04_08_174408_new_accounts', 16),
(27, '2020_04_21_094047_kaiconnection_account_id', 17),
(28, '2020_05_22_124327_createnotifications', 18),
(29, '2020_06_01_073932_configurations', 19),
(30, '2020_06_03_150135_configurations', 20),
(31, '2020_06_03_150346_kaiconnection_with_accounts', 20),
(32, '2020_06_03_150710_createnotifications', 20),
(33, '2020_06_03_150827_new_accounts', 20),
(34, '2020_06_09_170553_create_notifications_table', 21),
(35, '2020_06_09_170746_configurations', 21),
(36, '2020_06_09_170804_new_notifications', 21),
(37, '2020_06_11_104439_kaiconnection_with_accounts', 22),
(38, '2020_06_16_104751_kai_audit', 23),
(39, '2020_06_16_131459_kai_audits', 24),
(40, '2020_06_19_072838_configure_parameters', 25),
(41, '2020_06_23_103457_kaiconnectionstatus', 26),
(42, '2020_06_23_131056_configure_parameters', 27),
(43, '2020_06_25_114421_configure_parameters', 28),
(44, '2020_06_27_144854_kai_connection_statuses', 29),
(45, '2020_06_27_145506_kai_connection_statuses', 30),
(46, '2020_06_28_134232_kai_audits', 31),
(47, '2020_07_01_125121_configure_parameters', 32),
(48, '2020_07_02_121153_configure_parameters', 33),
(49, '2020_07_03_104837_configure_parameters', 34),
(50, '2020_07_03_132500_new_accounts', 35),
(51, '2020_07_05_181014_configure_parameters', 36),
(52, '2020_07_06_071415_configure_parameters', 37),
(53, '2020_07_11_104213_configurations', 38);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `new_accounts`
--

CREATE TABLE `new_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `database_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `portal_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disable_monitoring` tinyint(4) NOT NULL,
  `image` tinyint(4) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_accounts`
--

INSERT INTO `new_accounts` (`id`, `user_id`, `name`, `username`, `password`, `server`, `port`, `database_name`, `portal_url`, `disable_monitoring`, `image`, `status`, `created_at`, `updated_at`) VALUES
(9, 0, 'Rehrig House Productions', 'jasonmad_16', 'zvN5yrH2', 'db130a.pair.com', 3306, 'jasonmad_devws', 'rehrig', 0, NULL, 1, '2020-06-08 00:19:47', '2020-06-08 00:19:47'),
(10, 0, 'SysCorp International', 'jasonmad_16', 'zvN5yrH2', 'db130a.pair.com', 3306, 'jasonmad_devws', 'syscorp', 0, NULL, 1, '2020-06-09 09:38:39', '2020-07-09 05:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `new_notifications`
--

CREATE TABLE `new_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_condition` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `enable_number` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_notifications`
--

INSERT INTO `new_notifications` (`id`, `name`, `description`, `notification_type`, `notification_condition`, `email_subject`, `email_body`, `status`, `enable_number`, `created_at`, `updated_at`) VALUES
(1, 'Magento offline', 'Magento offline', 'both', 'select *from db.kai_audits where account_id = \"$accountId\" and log_type = \"$logtype\"', 'Magento offline', '<p>Hi,&nbsp;</p>\r\n\r\n<p>Abhimanyu</p>\r\n\r\n<p>[Notification_results]</p>', 1, '1', '2020-06-30 11:02:08', '2020-08-04 03:24:41'),
(2, 'Prestashop offline', 'Prestashop offline', 'both', 'select count(*) from ws.kaihistory where category = \"$order\"', 'Prestashop offline', '<p>this error prestashop offline</p>\r\n\r\n<p>[Notification_results]</p>\r\n\r\n<p>thanks</p>', 1, '1', '2020-07-01 05:28:34', '2020-07-11 06:23:39');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('00026534-6a8b-431a-9e0a-c6703a722e13', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:08:17', '2020-07-03 06:08:17'),
('0003456e-2fa7-4a0a-9492-f2eea5b94274', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:52:30', '2020-06-26 06:52:30'),
('0027e61f-45ef-44c6-a754-24f7888e0985', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:19:32', '2020-07-08 12:19:32'),
('0098cea3-1170-4e3c-9ec8-1b27b54e0141', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:37:17', '2020-06-28 03:37:17'),
('00f4d0fb-d159-4f64-b6e4-fdd8304425d9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:51', '2020-06-26 10:04:51'),
('00f7e1eb-f391-49f7-b9fb-1e9b5742103d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:17:28', '2020-06-11 07:17:28'),
('011dc1dd-b3c6-43c3-89ac-76db57074d84', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:48:17', '2020-06-30 09:48:17'),
('01916f33-03e2-4546-8a1e-7a67086106cd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:11:41', '2020-07-03 06:11:41'),
('01b7cf34-96b0-4473-9d8c-bc2b0e200656', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 14:21:26', '2020-06-09 14:21:26'),
('02242fee-1222-4b46-bf7d-d911198cb9d9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:18:19', '2020-06-29 01:18:19'),
('02ad0128-174f-497b-b5d2-15150c3a33e4', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-30 05:16:38', '2020-06-30 05:16:38'),
('030c90d5-1ee9-4e49-92fb-8dd636cd364b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:30:18', '2020-07-20 11:30:18'),
('032ff775-b114-459f-8bc4-88998178863a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:17:24', '2020-06-11 07:17:24'),
('03317094-8f50-49f8-8049-25f85981dae7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:31:18', '2020-07-05 08:31:18'),
('035918b1-e9da-4e16-981b-d9bcc26a468c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:26:49', '2020-06-17 05:26:49'),
('03596238-dba0-45c6-99dc-f804e1301a09', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 06:11:55', '2020-06-30 06:11:55'),
('03d81249-e881-4bd4-a2d2-20419d6cbba2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:42', '2020-06-26 10:04:42'),
('0401c326-ad1c-4ab9-aa07-88bbf570d626', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:43:02', '2020-07-09 08:43:02'),
('0472bd8d-6b56-4ed9-8c8f-79231a2acb41', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:47:35', '2020-06-29 00:47:35'),
('04bbb168-41b2-499a-a3eb-2d3438d55183', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:58:21', '2020-07-07 04:58:21'),
('04c01432-81e1-41a8-a1a0-6329ec2c3123', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:41', '2020-06-26 08:31:41'),
('0514a7f3-74a0-43d4-89e6-ef313cf37a65', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:14:34', '2020-06-26 12:14:34'),
('056265c1-e831-4cc6-8aae-4fb8d2aec249', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-12 08:08:04', '2020-06-12 08:08:04'),
('0573677f-db61-458e-acf5-90a0e5a2e66a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 06:31:51', '2020-07-06 06:31:51'),
('057d14eb-85b0-41c6-84ad-91d1cd04de49', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:52:02', '2020-06-29 01:52:02'),
('06121775-f0c2-4927-87ba-66620e8a6e66', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:19', '2020-06-27 04:49:19'),
('065e3308-12ca-4b36-be28-0db40759cb07', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:23:03', '2020-06-26 08:23:03'),
('06bb7482-8f9f-4861-8e41-ef25e2460f1d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:26:23', '2020-06-28 05:26:23'),
('06d306b5-6c7a-4f69-b0ca-d239a3a49ea7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:05', '2020-06-26 08:27:05'),
('07149d8b-3b81-420a-abaa-4c5e047d5cca', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:12:10', '2020-06-29 00:12:10'),
('076bd3d9-b6a2-47b1-ac96-2079697bc6e9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:39', '2020-06-28 05:44:39'),
('0792f82e-cb11-425d-8997-c468b80d6f3f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:20:17', '2020-06-26 08:20:17'),
('07b0fddd-1b95-4cba-90c8-4a1d012e5f40', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:55:04', '2020-07-08 11:55:04'),
('07e88e7c-75ed-4071-8602-48fc2d8d8cc7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:14:48', '2020-06-26 09:14:48'),
('07fa4e9a-0d25-437e-b6e6-4c655ee801eb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:08:23', '2020-07-08 11:08:23'),
('082e37cc-1acc-4793-a6d4-9a20b91f6f1e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:54:25', '2020-06-26 07:54:25'),
('08ca1a42-7635-4441-82dc-b8fc0e154c63', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:49', '2020-06-26 10:03:49'),
('092179e2-3df7-434f-83ff-d05ff3c28064', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:53:42', '2020-06-28 06:53:42'),
('09dd8b0d-9607-4644-bdbb-4c93e2887780', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:17:06', '2020-07-07 04:17:06'),
('0a4e6b69-7ec7-4136-b139-09595b99a92f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:32:46', '2020-06-10 03:32:46'),
('0a5f954f-6215-40d3-baf0-3c1d342cfc01', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:08:42', '2020-06-27 06:08:42'),
('0b05acd8-9871-40fc-b014-c682aed4b89f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:46:24', '2020-06-27 05:46:24'),
('0b3dbfd6-d876-42c6-ae3d-98a3957d9eb3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:22:24', '2020-07-02 05:22:24'),
('0b8775d9-746f-4403-a3cd-11c97703b20b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 00:06:18', '2020-06-29 00:06:18'),
('0b8b5f5e-2af2-403d-9370-8bc81225e7f0', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:29:44', '2020-06-29 01:29:44'),
('0b9f623c-27b1-4f32-a27f-3092c259a1e5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:54', '2020-06-28 05:46:54'),
('0c39370c-41a0-47ed-91a6-2daf279e837f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 09:11:30', '2020-07-07 09:11:30'),
('0c7aa32e-eb36-43e1-9bc9-840181b7d5e4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:50:33', '2020-06-11 09:50:33'),
('0d06eb00-6296-4582-84ec-dceeef0fb3e4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:32:08', '2020-06-10 02:32:08'),
('0d48075e-ad37-43c5-9f94-e834b62c793d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:38', '2020-06-26 08:29:38'),
('0d5cb595-85af-4593-9107-2b907d1490b4', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 02:37:15', '2020-07-22 02:37:15'),
('0d90b2df-ab3e-4f50-8deb-fc182fd9a3d5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:41:56', '2020-07-09 04:41:56'),
('0dc3be25-18e2-4332-b18a-d36c5e7e672d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:44:34', '2020-07-20 11:44:34'),
('0ddf7bf1-64a7-4cc4-b816-8d34f9999661', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:19:53', '2020-06-26 08:19:53'),
('0e03a569-0b3a-4095-87cc-fa9788e81e22', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:30:21', '2020-07-20 11:30:21'),
('0e404413-b17a-4b29-810f-a04a2be647f8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:37:49', '2020-06-26 07:37:49'),
('0e7731be-25c0-44fb-893a-718e35e33061', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:36:24', '2020-06-26 10:36:24'),
('0f2ca198-5857-4383-9749-634ac46ad5eb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:47:04', '2020-06-28 05:47:04'),
('0f503561-95bf-48e3-a80e-5ac9dc312bd2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:37:08', '2020-07-08 07:37:08'),
('0ff9fa35-8f80-4476-a0da-8893cecb2523', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 05:11:32', '2020-06-29 05:11:32'),
('1004342d-9af0-4998-b7e0-1bea5a1c59b4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:07', '2020-06-26 10:02:07'),
('1064ac90-c731-4b6b-85d1-ab7c9eb56dd6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:24:00', '2020-06-26 08:24:00'),
('11500e52-56c8-4698-bccb-e9c540066b6d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:52:06', '2020-06-29 01:52:06'),
('115fe62b-60ef-432f-8e69-adfe53f7709a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:38', '2020-06-29 00:15:38'),
('1207109f-cad8-46d4-a6cc-7be6d183dee7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:35:52', '2020-06-26 12:35:52'),
('123efde4-0ad9-4ae4-af87-9bf76a08602b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:09:44', '2020-06-11 07:09:44'),
('12a852dc-487a-437b-bae5-03073f6f65b6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:01:11', '2020-06-26 12:01:11'),
('13175251-08f9-42fd-a35f-425ed3e9ee03', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:24', '2020-06-26 10:02:24'),
('13249ad9-6836-48ca-bf6a-8a243f6e40e0', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:09:08', '2020-06-29 00:09:08'),
('132d7a3f-bf2c-42b5-bd04-bec67afb0e0a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:18:09', '2020-07-08 08:18:09'),
('13361a37-0589-46e1-9142-6ec068e19702', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:20:09', '2020-06-29 01:20:09'),
('143e85a2-82c9-4d66-b167-81542451b150', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:00:24', '2020-06-30 10:00:24'),
('1441859c-1991-4525-a1d6-cd546c88e834', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:10:27', '2020-06-10 03:10:27'),
('145f7192-9b42-4d09-afe4-9ff5cad2ea75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:23:30', '2020-06-26 12:23:30'),
('14756b3a-48b6-4b09-b5d5-9d1d146e5828', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:02:58', '2020-07-06 05:02:58'),
('149ff3b5-09e2-42a0-b8c1-516acb5c0486', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:01:14', '2020-06-30 10:01:14'),
('14edbf4d-c944-444b-9b48-2925f15a51ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:38', '2020-06-26 08:31:38'),
('14fb12a6-2838-4cf5-9372-254a690f05d1', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:22:35', '2020-06-29 00:22:35'),
('1542576a-cd1b-4bbe-b092-4877f99618c2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:09:35', '2020-06-26 12:09:35'),
('155a2946-a8d4-4bb9-9574-d840828fdb11', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:37:02', '2020-06-26 10:37:02'),
('15f18800-bce6-47a4-8822-bd769d83aca5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:24', '2020-06-26 08:09:24'),
('16255ef9-6db5-4d23-a052-404513762ae6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:12', '2020-06-26 08:09:12'),
('1639c029-e101-4fed-963e-b0eaeadb8bad', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:48:12', '2020-06-30 09:48:12'),
('1641ff9c-e4b1-4903-9e96-49e0b12e99a0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:10:02', '2020-06-11 07:10:02'),
('1671e9e9-423e-4ec9-bf12-45d0972aa6a0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 07:09:50', '2020-06-30 07:09:50'),
('16e0dd07-5188-4014-9253-ce8dbaa1098f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:02:49', '2020-07-08 11:02:49'),
('171f47ee-9877-4af0-b489-a4313f065ffa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:56:07', '2020-06-30 09:56:07'),
('175dadb3-345f-47c9-b06c-4d41630af69e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:09:20', '2020-07-02 04:09:20'),
('176b3e28-98d2-4967-b348-c561d121a8d1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 06:53:47', '2020-07-07 06:53:47'),
('17b310bc-6eec-433f-bd73-6a3dd663587f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:52', '2020-06-26 10:06:52'),
('17e1352d-fd96-4994-ab78-21a097e17bc7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:44:14', '2020-06-27 05:44:14'),
('18b3f38f-9528-4a5b-9e7a-3840faccba17', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:11:50', '2020-06-29 00:11:50'),
('18d61e0c-6493-41b7-b6bf-de9966e02356', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:49:56', '2020-06-26 09:49:56'),
('18f4e759-a204-469a-85fa-15c5a968dc19', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:59:07', '2020-06-10 02:59:07'),
('1946e7ee-bac5-4c0b-b239-8352aa4f964d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:21', '2020-06-10 14:26:21'),
('194dc464-cd23-46b6-961e-8c125e8f1144', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:32:15', '2020-06-30 08:32:15'),
('1950e30c-cc2d-4478-91fb-19c60903a587', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:17:29', '2020-06-30 09:17:29'),
('1996263e-b122-4c5c-b51d-2bce54d9fc11', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 07:52:11', '2020-06-30 07:52:11'),
('19a07d62-7303-4337-81be-8d8a0543a8a7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:01:03', '2020-06-26 12:01:03'),
('1a38f428-cb79-4c3b-be22-650420340009', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:19', '2020-06-26 09:02:19'),
('1a4de628-3ea4-4b8a-a1e7-7ae3408246e9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:37:41', '2020-06-26 07:37:41'),
('1a97cf97-f8a5-4129-9052-1cd178e7fe46', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:36:58', '2020-06-27 05:36:58'),
('1b12ea34-5455-435d-844d-78c9705d223a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 07:10:40', '2020-06-10 07:10:40'),
('1b5ec61f-999d-41f8-9c5c-d812c98bb358', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:23:24', '2020-06-26 11:23:24'),
('1b711fa2-bfc2-4722-82da-dafa03966451', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:31', '2020-06-26 10:29:31'),
('1ba9d2c7-cb86-419a-86ec-0852b492af0d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:39:40', '2020-06-28 12:39:40'),
('1bc563a3-b789-4828-b1ca-83d9b2d9c007', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:36:40', '2020-06-29 01:36:40'),
('1bf30369-f4c3-4ee8-a843-654fb0c3e730', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:24', '2020-06-28 05:25:24'),
('1c07f910-5137-422d-a7f2-19f635507a2b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 8, '[]', NULL, '2020-06-19 06:23:34', '2020-06-19 06:23:34'),
('1c2198f1-b509-418e-bbe3-9c12c11ba03f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 12:49:42', '2020-06-17 12:49:42'),
('1c2bbbbe-5e4b-439a-86cc-dba36d1c77f0', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-01 13:02:50', '2020-07-01 13:02:50'),
('1cdf02a9-0d22-4792-ac0f-4529776f3d8f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 07:49:09', '2020-07-06 07:49:09'),
('1d1a9819-1c28-4bdb-a6b0-96a2d6c2e532', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:58:00', '2020-07-08 07:58:00'),
('1d4a6afa-e109-483b-bf98-2436c75138ae', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:13:13', '2020-07-02 03:13:13'),
('1d97315a-7e02-40a0-8b42-91bacd02e90f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:08', '2020-06-26 10:07:08'),
('1e13fa26-a661-4bdd-9b1d-8dbdc8b1b8de', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:14:40', '2020-06-26 06:14:40'),
('1e46e6bb-d603-4c3c-950f-2330bc65e134', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:11:47', '2020-06-26 12:11:47'),
('1e8067b7-70e1-4187-b234-888d9b67941e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:08:02', '2020-06-26 08:08:02'),
('1eb97435-a543-47f7-977d-23852849acf2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-29 05:12:34', '2020-06-29 05:12:34'),
('1f1d0195-5b65-471f-be2e-aa7dee47b287', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:32:10', '2020-06-30 08:32:10'),
('1f4b0a01-37d8-44f1-bd52-fa2f2c7f02f6', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-09 14:15:37', '2020-06-09 14:15:37'),
('1f5d121f-5a6d-4c66-b7d7-25feabb7eee3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:39', '2020-06-26 10:29:39'),
('1f6196ee-dc23-44ef-a516-9c122648d589', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:09:32', '2020-06-26 12:09:32'),
('1ff175a2-87d8-48c2-a9c3-07515b276c12', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-01 12:21:37', '2020-07-01 12:21:37'),
('1ff82c01-b263-40e9-b507-ddcf579edd75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:25:41', '2020-06-10 14:25:41'),
('20938318-ed02-4a05-8350-6c481dbd0e50', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:15:44', '2020-07-02 03:15:44'),
('20aed09f-bdef-4bf7-9aa0-44de5a8c91a3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:57:11', '2020-06-26 07:57:11'),
('20ef6566-7a4e-466b-af70-902c65030e5b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:02:56', '2020-07-08 11:02:56'),
('2111811d-a821-446c-8ca5-e14cae4b387e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:10', '2020-06-26 08:27:10'),
('2129255a-a945-4e51-b01e-116efa7a2f1a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:06:13', '2020-07-07 07:06:13'),
('2144a0f0-98ad-4b29-a6ac-c113da640f22', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:44:14', '2020-06-10 02:44:14'),
('214ac558-1d44-40d6-8bf8-bad97b4e1a36', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:11:47', '2020-06-12 08:11:47'),
('21899b1f-360a-4595-b641-e6078201a6b9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:50:38', '2020-06-11 09:50:38'),
('21d00816-1ef4-4cd6-9357-28c15eb87649', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:06:06', '2020-07-07 07:06:06'),
('21eeca8f-ed2b-452e-a13e-e691bc59dd5b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:20:40', '2020-06-10 03:20:40'),
('22318d4f-de56-4723-84da-d5a39dee5fb9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:28:45', '2020-07-08 07:28:45'),
('224c769c-2ec5-4561-9bba-02d51b324a16', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:25:15', '2020-07-20 11:25:15'),
('234412d8-cf39-4137-810f-37da1681934c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 07:33:00', '2020-06-30 07:33:00'),
('23d93464-ffac-4b34-b09f-309fa1bc92f3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:24:07', '2020-06-26 12:24:07'),
('23dd9f9c-16f9-4788-937e-cf6eed6017ce', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:58:16', '2020-06-11 10:58:16'),
('23eeb8a0-3bee-49d0-ad5e-a503aa5a193f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:29:00', '2020-07-08 07:29:00'),
('24049e3d-5a3d-476c-a1e0-529d6c37d4c3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:09:58', '2020-06-11 07:09:58'),
('2441e218-6239-4251-8ff3-ed9396fe9c4d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:30:48', '2020-06-10 06:30:48'),
('246c5af5-f719-444c-9957-bbce656b2a4f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:29', '2020-06-26 10:04:29'),
('24e2c293-bbfa-4671-ab6f-ec4288c117d8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:00:34', '2020-06-26 08:00:34'),
('2551c4a1-f41e-4302-bdfa-220a0c451173', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 03:40:00', '2020-06-28 03:40:00'),
('2575b7f9-289e-4559-8bd6-a456c4cce0c3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:46:20', '2020-06-27 05:46:20'),
('25cf75cf-91d6-4081-a7a6-c01f14e54b5d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:31', '2020-06-26 10:03:31'),
('26291861-03fe-4eab-8bcb-67240434eb44', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-04 10:31:48', '2020-07-04 10:31:48'),
('262f204e-c473-45e1-a874-0f448bfc0734', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 11:59:10', '2020-06-26 11:59:10'),
('26678086-403f-4137-acd9-9bbb0ac49704', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:06', '2020-06-26 10:04:06'),
('267e0d1b-17ec-415d-9ee1-4bb4d1a00866', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:57:52', '2020-07-08 07:57:52'),
('26b6d1ad-f532-43bf-8746-e1c80a8a17e6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:03:54', '2020-07-07 07:03:54'),
('26c08108-ebe4-41ad-b01d-34cd21b98f3a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:51:07', '2020-06-26 07:51:07'),
('26fccfbb-56bc-4b18-b5ec-0da492bef8a7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:45:58', '2020-06-17 05:45:58'),
('277110cc-1967-4c72-acff-070de882cce2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:38:10', '2020-07-09 08:38:10'),
('27c7a46b-98dc-46e3-8ae5-312e0b395f2e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:39:51', '2020-06-11 10:39:51'),
('27f9114c-6045-4209-84a9-f171a472e8e0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:30', '2020-06-26 10:05:30'),
('28ab09d0-6069-49c5-bc2d-38bf54f499b5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:13:09', '2020-06-11 10:13:09'),
('293a4812-da85-4c45-958b-ed898685702c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:26', '2020-06-29 01:27:26'),
('29a6bf35-5ee3-43da-9de9-dd2e0cb27a7d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:15:39', '2020-07-09 05:15:39'),
('2a06b5f2-96c6-428e-9b87-bcb743943273', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:50:00', '2020-07-02 03:50:00'),
('2a9a75c8-9a8f-4b31-82b6-253681bd788f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:15', '2020-06-26 10:06:15'),
('2aa0953e-78f2-40e8-ab6d-da2e75ed568c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:26', '2020-06-28 05:44:26'),
('2ae05cd1-61e9-4d9e-abb9-889dfe9d61d4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:09', '2020-07-07 07:04:09'),
('2b4c6187-695b-4460-89b6-19eaffda52b7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:19:37', '2020-07-08 12:19:37'),
('2bcd427a-a97d-4afa-942e-a640a7978ff2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:36', '2020-06-27 04:49:36'),
('2c1d6bf1-1bf2-4d17-82b1-e14940c2bcc3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:40:27', '2020-07-08 09:40:27'),
('2c5636a1-b0ac-4d5e-80ec-fd2b5a5df715', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:22:42', '2020-07-02 04:22:42'),
('2d05301b-1cb0-4861-9f67-073c2922a666', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:41:39', '2020-06-28 12:41:39'),
('2d4d60d9-7356-45ba-a936-969229ad1263', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:37:09', '2020-06-28 08:37:09'),
('2d549afe-b381-42e0-8f99-104ba1f9b3dd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:59:19', '2020-07-08 11:59:19'),
('2da40a0a-b5c6-4302-9ba1-ad848001a56e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:01:08', '2020-06-26 12:01:08'),
('2dc385bf-58e1-432e-9e4d-e46c54ecf3cb', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:11:54', '2020-06-29 00:11:54'),
('2e7e4018-c5b3-4d25-a3ac-ff1eb528238c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:22:48', '2020-07-02 04:22:48'),
('2fb0b7a8-7ddb-4b3c-a98d-6fc513d4be37', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 06:31:36', '2020-07-06 06:31:36'),
('2fb1a94a-67f5-45fa-bc44-6b6991a1d64c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:40', '2020-06-26 10:06:40'),
('2ff671ae-499e-4ad3-bcc7-94f123051ece', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:09:04', '2020-06-29 00:09:04'),
('301e2bdd-f867-4262-b338-650484a09305', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 14:39:42', '2020-06-09 14:39:42'),
('31185a25-a526-452b-ad48-84ae0c525440', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:15', '2020-06-26 10:04:15'),
('317373f2-25de-485b-8444-d679ef8e180c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:30', '2020-06-28 05:44:30'),
('318ec1d2-8066-4859-8b7e-bc0ee8f1ed14', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:15:39', '2020-06-12 08:15:39'),
('3198b49d-daa8-42a4-82f6-5dfcefc51999', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 07:16:37', '2020-06-26 07:16:37'),
('31a81600-7b25-41fb-a4c6-87ae4b7441ef', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:15:27', '2020-07-08 08:15:27'),
('3220df01-6e77-4fee-b54d-17665b76d4fc', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:37:11', '2020-06-28 03:37:11'),
('32d8c11d-aea4-4a01-bdfb-eb8051525e03', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:13:20', '2020-06-29 01:13:20'),
('3301a195-7212-4505-a1c1-97667b028692', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:12:24', '2020-06-26 07:12:24'),
('33186ab4-90d5-42ee-a84d-7b8b22ad923b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:09:19', '2020-06-29 01:09:19'),
('33927cff-6e8a-48cc-9f67-480d4a287ea2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:42', '2020-06-26 10:05:42'),
('33b0dde6-becf-482c-b4a1-6f42de62ac29', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 03:46:10', '2020-07-09 03:46:10'),
('33c1d433-ee0f-4222-b0d5-d51f9bbbb0ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:57:28', '2020-06-26 09:57:28'),
('34ccf4c0-bb56-428d-8d0d-f0196bfa0e78', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:18:14', '2020-06-29 01:18:14'),
('34cd8248-7a66-4232-a680-3bd7c7cfe99a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:52:10', '2020-06-26 07:52:10'),
('356fc71c-6f6a-4125-b2f4-7a71e6f9f8f8', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 04:44:40', '2020-06-29 04:44:40'),
('359cc6bf-f3ea-4b9a-95c8-c65420fbb71a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 03:46:05', '2020-07-09 03:46:05'),
('35c9e0ab-73f8-4d75-b29a-7d7c175cac63', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:02:37', '2020-07-08 11:02:37'),
('360a4026-3ce1-43a5-9032-8e06094cf0c1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:57:17', '2020-07-08 11:57:17'),
('3632c5cc-355b-4def-b91a-87c9944fc3f1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:09', '2020-06-27 04:49:09'),
('366b958c-e38a-4d8e-b7dd-c9d286638307', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:22', '2020-06-26 10:06:22'),
('36dbd2c4-d664-48c4-844e-da6d99d72da3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 06:31:39', '2020-07-06 06:31:39'),
('371278d0-782a-4703-b82b-becbe2d9d698', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:51:31', '2020-06-26 09:51:31'),
('37562cfe-73fa-413f-a482-736c94f18d93', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:22:27', '2020-06-29 01:22:27'),
('37a11349-48e2-4959-aa35-8062cba71e5b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:20:24', '2020-06-29 01:20:24'),
('37a77c33-ee90-4d60-bd66-a1152b942c0d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:29', '2020-06-29 00:15:29'),
('37c9313a-b060-4aab-9787-9221c7a0e030', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:59', '2020-06-28 05:46:59'),
('3844481a-98c5-4c5a-b29f-dfd33f7c027d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:16', '2020-06-26 10:02:16'),
('384c8cae-c931-4b65-9622-3f96a6cb7548', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:52:52', '2020-06-10 02:52:52'),
('386351a9-c4c6-42d7-addb-c97e0628d083', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:06', '2020-06-26 10:06:06'),
('389759fd-880e-42c2-9ece-f6b4cea029ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:47:09', '2020-06-28 05:47:09'),
('39bbccdd-20aa-47db-a3c1-325c47dd44c5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:16:06', '2020-06-26 09:16:06'),
('39d2dc14-e70d-4049-a9e2-800b834ffef3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:23', '2020-06-28 05:27:23'),
('3a0dc72f-b948-4ec2-946c-494843dcc003', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:26:28', '2020-06-28 05:26:28'),
('3a160e70-fe57-4af8-8411-a37aa7e19481', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:41:51', '2020-06-29 01:41:51'),
('3ab39975-6a2c-4069-b405-f1beb2cfce0a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:04:13', '2020-06-17 05:04:13'),
('3aeaaef1-261a-408d-a4ff-e69fa320e8d5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:46:23', '2020-07-09 08:46:23'),
('3afabb2a-bae5-4008-b6ac-a93e4ec3393c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:38:00', '2020-07-02 04:38:00'),
('3b7315ae-4c53-4506-913f-805bfd447e74', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:19:35', '2020-06-26 12:19:35'),
('3bba1e25-bd58-41ac-bbf0-65057ad176f5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:13:58', '2020-06-09 15:13:58'),
('3bd05062-6ea5-4d7b-8067-24367b07de82', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:11:43', '2020-06-26 12:11:43'),
('3cbb2707-6205-4b14-a9b6-68a6531e11d6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:32', '2020-06-26 08:29:32'),
('3d28d4e6-5aaa-4904-9da3-09298e14137b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:10:33', '2020-06-10 03:10:33'),
('3d2e4b34-273e-4640-b257-c4238f4863be', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:17:12', '2020-07-07 04:17:12'),
('3d2f421f-a590-4600-b038-71d855534e45', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:34', '2020-06-26 08:31:34'),
('3d5c8095-2a60-4a16-8675-44908e04c3b9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:20:13', '2020-06-29 01:20:13'),
('3d9cd452-6f3d-4892-b584-035d29c922c0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:34', '2020-06-26 08:34:34'),
('3dbbc348-8648-4dcb-8223-214748c2e60f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:57', '2020-06-28 03:41:57'),
('3dcfd266-9411-4156-9455-d8bf07d0fa9f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:19:28', '2020-06-26 12:19:28'),
('3e86014b-b7d2-4aab-a125-39c6b1ed771a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:22:36', '2020-06-11 10:22:36'),
('3e9087b0-5266-45eb-a255-3bc4c26c58a5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:40:18', '2020-07-08 09:40:18'),
('3eaf846b-8cfc-49f4-a85b-a7bc09ca2941', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:42:23', '2020-06-28 05:42:23'),
('3ebbeb2c-590c-42b7-b9b0-1a8204ff8ec3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:20', '2020-06-26 10:04:20'),
('3ed6e000-a3ef-453f-8888-c5b2bd15ff44', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:25:04', '2020-07-20 11:25:04'),
('3f6d0a4f-ab7e-477e-8468-134708df51be', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:42:11', '2020-07-09 05:42:11'),
('3fba467b-a095-4afa-8deb-54fe35a1efb2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:54:49', '2020-07-08 11:54:49'),
('3fbb8f1c-4cdc-4d87-80ce-92486cf2f31b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:37:12', '2020-06-26 08:37:12'),
('3fca87a6-5df2-4de4-a3dc-ab67d6f7daf4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:50:59', '2020-07-09 08:50:59'),
('3fd14adf-b5b8-44b2-a1bf-d1c7d8957bc5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:09:40', '2020-07-08 11:09:40'),
('3fe5e47c-c88a-48c7-9a10-0c90d46f215b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:39:55', '2020-07-02 04:39:55'),
('3fedb252-7ea2-421b-b751-3c8057b566d0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:31', '2020-06-10 14:26:31'),
('3ff66664-f716-42ff-8b35-d241320dabf4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:43:07', '2020-07-09 08:43:07'),
('40e85b44-f57b-4d69-a3c6-44597c6aad87', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:05:21', '2020-06-12 08:05:21'),
('4112c456-ba66-4e01-be38-b799ca29731f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:32:36', '2020-06-10 03:32:36'),
('41ed2e74-d86e-440c-bc83-b019c464e61e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:28:26', '2020-06-30 09:28:26'),
('41ef550a-c6d9-4882-89e7-60354a47a533', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:29:48', '2020-06-29 01:29:48'),
('422da6ff-ba5d-4b2b-8914-1f4831ae9b99', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:51:03', '2020-07-09 08:51:03'),
('424a6f3d-7e9a-494b-9c98-57a63f8fecf5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:03:47', '2020-06-26 12:03:47'),
('42508b64-9463-402a-bded-ea550562077b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:42:07', '2020-07-09 04:42:07'),
('4251d54a-7f7d-479d-8273-844ae5ea9a54', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:37:07', '2020-06-26 08:37:07'),
('4257cf6b-a1bc-4124-8eff-c896ba353110', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 07:16:27', '2020-06-26 07:16:27'),
('42a9194d-0e6d-4daf-b257-e38ecd21d7fc', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-01 13:05:08', '2020-07-01 13:05:08'),
('42d99ec0-4628-4d0d-9fed-b4a281c78542', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:24:11', '2020-06-26 12:24:11'),
('432d42d3-630b-45fb-81cd-7591e6499091', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:00:37', '2020-06-26 08:00:37'),
('43542ade-5a45-4f6a-a339-4bfbbd3d8a5b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:50', '2020-06-26 10:05:50'),
('43a54ff7-4dac-41eb-a4b4-ed04dd340eb2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:28:53', '2020-06-17 05:28:53'),
('43ccdaef-c835-455b-9c4c-020d8e0add91', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 03:45:50', '2020-07-09 03:45:50'),
('43e25ce8-1713-49df-adb6-c6b74c888b7e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:38:17', '2020-06-28 08:38:17'),
('4402387a-2a09-4beb-8748-9b1adb6c439a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:47', '2020-06-26 10:05:47'),
('4402dc4b-86f9-4d07-bcb7-067d6dff44c9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:44:25', '2020-06-27 05:44:25'),
('4440f464-2ed3-4264-bf0c-4eccb89854b5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:44:20', '2020-06-27 05:44:20'),
('453abf1d-30cf-4d7f-b99c-906c1946e124', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:26:46', '2020-06-26 12:26:46'),
('45767982-c173-456d-92df-6b0ae4fd5e53', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:19', '2020-06-28 05:25:19'),
('45ef4a68-4a96-491c-9451-4cd68f4901ff', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:05:17', '2020-06-26 08:05:17'),
('46d06e06-a09e-4d2e-9f5e-7e74b02c4d47', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:41:54', '2020-06-17 05:41:54'),
('46f61e21-916d-4628-ab1d-9d712c43b0ca', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:51', '2020-06-29 01:27:51'),
('476003a3-b88e-41a3-8b0e-fe477fbd5f58', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:06', '2020-06-26 10:05:06'),
('47792b21-225a-4c39-84a4-c295a0d3e187', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-01 13:02:55', '2020-07-01 13:02:55'),
('479770df-b798-4b90-82d2-c7e038c9d6e4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:26:03', '2020-07-09 08:26:03'),
('47dae0f0-bc8f-484f-bcfe-6ee3837aea26', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:02', '2020-06-26 10:03:02'),
('47e343ca-8a8f-4273-ba3c-81555234d809', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:59:14', '2020-06-26 06:59:14'),
('47f7d266-1494-4558-b9bc-5feeafc03e38', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:45:08', '2020-06-27 05:45:08'),
('4815343a-cff7-4da6-84a5-8c9054f3734e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:58:30', '2020-06-11 10:58:30'),
('48bfbfc4-ae9d-43c2-9afe-259990e2ec09', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:49', '2020-06-28 05:44:49'),
('48cd500e-8c72-4727-aeba-ba217c1ed8e5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:51:37', '2020-06-26 09:51:37'),
('48e90304-d851-4e49-8098-f7de14ef8d0c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:40:18', '2020-06-26 07:40:18'),
('48f8b2cb-a0f9-4154-972f-cd173ed478a6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 09:11:10', '2020-07-07 09:11:10'),
('4916dece-52c6-4e39-bb28-1df5e562ab69', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:41', '2020-06-26 10:01:41'),
('491a8900-5df3-478c-8f0b-ecfafd6b3608', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:45:12', '2020-06-11 09:45:12'),
('4946c434-d9d8-4e29-8eef-3f483ed38665', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:01:14', '2020-07-09 04:01:14'),
('49a0d4be-f266-48c9-ae6e-c146a9c2b8fd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:54:26', '2020-07-08 07:54:26'),
('49eda4b4-13a5-4b69-83ee-19119f469872', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:54:55', '2020-07-08 11:54:55'),
('4a942e7b-8ec8-4893-9ae1-ca3ba3480661', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:17:33', '2020-06-11 07:17:33'),
('4aa9ec31-9c75-47d5-a3aa-7b59ebb0cd4e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:17:17', '2020-07-02 05:17:17'),
('4abdecb7-3de0-4151-87f9-b9675cf23c75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:44:42', '2020-06-26 06:44:42'),
('4b4ac89c-be92-4f9a-b2f5-ed4e9274d83c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 12:49:37', '2020-06-28 12:49:37'),
('4b53fe08-505a-4b75-99ef-4913a1ecaf89', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:12:04', '2020-06-29 00:12:04'),
('4b8a2f35-c9ce-4d0b-a1ef-05ba8123f3ea', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:50:39', '2020-07-22 00:50:39'),
('4c1bfa94-3eb5-4f4c-8110-3b0f94cae0b7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:01:18', '2020-07-09 04:01:18'),
('4c433a7e-7b5c-4593-9069-8ba5e4e3231a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:35:38', '2020-07-06 05:35:38'),
('4c5dc296-5d06-4161-9833-4ee8bf068ef3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:23:10', '2020-07-08 12:23:10'),
('4c75385e-7026-431a-b6e2-5baea7b73ada', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:52:18', '2020-06-26 07:52:18'),
('4cbce1eb-514a-4b48-93e3-580b09eced97', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:06:02', '2020-07-07 07:06:02'),
('4d0c8a39-8e9d-4d1a-bcb7-357062d66787', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:53:37', '2020-06-28 06:53:37'),
('4dc020dc-e342-4137-989b-a3e18d497028', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:18:12', '2020-07-09 05:18:12'),
('4dedf6cb-9a93-462c-842d-102bf0462c1d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:37:22', '2020-06-11 10:37:22'),
('4e0dd242-a2d4-4aec-85bf-f52ca5853ea3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:41:46', '2020-07-09 05:41:46'),
('4e1143e9-7081-4c9d-9e10-82e1caf611e2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:13:39', '2020-06-26 12:13:39'),
('4e38c8ed-a404-4510-a129-65269abea744', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:36:43', '2020-06-29 06:36:43'),
('4e3d007b-8869-43a4-bcd4-243d91a14be4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:35:57', '2020-06-26 12:35:57');
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('4e8e24bf-5161-4c6d-ad54-2e43f71ce1db', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 03:46:01', '2020-07-09 03:46:01'),
('4e962c1e-5da5-4944-86da-5df7a12815e7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:33:52', '2020-06-28 05:33:52'),
('4eba008c-40cc-469a-8119-768fd96c4ee6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:30:46', '2020-06-30 08:30:46'),
('4f04b7fe-e8b9-49d7-8061-0f1b051c7615', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:49', '2020-06-26 10:06:49'),
('4f540be2-a7d8-4461-887f-06adda7c6ebd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:35:29', '2020-07-06 05:35:29'),
('4f6ee6a5-003f-40df-ae5b-e52bfcd1bc45', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:15:54', '2020-06-29 01:15:54'),
('4fbdede1-bb89-4ae7-904d-5f6dc60d6347', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:33:05', '2020-07-20 11:33:05'),
('5061ccf9-c5f4-42a0-b725-0d28645216a4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:36', '2020-06-26 10:01:36'),
('50bd357a-d4c1-4cbd-a08f-13fc6e82dab5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:32', '2020-06-28 05:27:32'),
('50ec23eb-1adc-45ae-a4fd-e1fc5a213037', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:45', '2020-06-29 01:27:45'),
('51286826-9e17-43a7-b714-5230b05e2a90', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:56:53', '2020-06-26 09:56:53'),
('51318e57-cdee-47c0-ac8c-1cd9a6fa0799', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:33:49', '2020-06-26 07:33:49'),
('518e5b68-e587-4a3e-98b1-78524ca2eae9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:50:05', '2020-07-02 03:50:05'),
('53098608-469a-4a19-b653-970a326fa27a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:02:35', '2020-06-12 08:02:35'),
('531986a4-1ea8-4daa-b5c9-73f9106fb057', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:50:43', '2020-07-22 00:50:43'),
('5323ced8-7a2e-4e8b-aa4f-b14aa50e9934', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:45', '2020-06-28 05:44:45'),
('532d1c29-4f4a-4b00-a104-e3d6ae1221f9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:23:26', '2020-07-08 12:23:26'),
('536878bf-9132-4d94-96b6-07662644e2f8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:04:21', '2020-06-12 08:04:21'),
('53ab37a7-a60d-4da8-8c7f-02b21818e63a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:04', '2020-06-09 15:06:04'),
('53cc4a46-ef81-4b9e-955c-01b630b8d3da', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:33', '2020-06-26 10:05:33'),
('540b0850-b9f0-488a-86af-c0f53b2194d8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:51:23', '2020-07-08 09:51:23'),
('54386bd3-3be7-4def-bff4-b5b816298698', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:05:30', '2020-07-05 08:05:30'),
('54a8cf61-9310-427d-b36a-caad04590f70', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:45:27', '2020-06-26 09:45:27'),
('54b22219-c51f-4e05-bb27-94e6e99e820c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:00', '2020-06-26 10:07:00'),
('54c19fd2-f1ca-406c-9fb5-e18fb4373aa5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:17:22', '2020-07-02 05:17:22'),
('54c31446-6d57-432b-a276-b59af87854c7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:37:07', '2020-06-28 03:37:07'),
('550fdc41-ac64-4aad-86a2-284b2a89c20c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:04:16', '2020-06-12 08:04:16'),
('552f027c-f7ed-4aba-8c34-4473caa1611b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:27:44', '2020-06-10 14:27:44'),
('559854fb-03f4-4072-ba55-fb344e1137a6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:39:18', '2020-06-29 06:39:18'),
('562444cb-984d-4a5d-aa48-d43592255440', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:20', '2020-06-26 08:34:20'),
('5654d66a-bc23-4b92-a77f-49c2286be882', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:15:45', '2020-06-12 08:15:45'),
('56a2c22d-8fa4-40d1-b532-c1b074849ad0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:29', '2020-06-26 08:31:29'),
('5822b696-ca3e-479e-b94f-688fd8e69d5f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:36:53', '2020-06-27 05:36:53'),
('5837cd89-b775-4393-a9f7-b2ca5eef73a5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:47', '2020-06-28 05:27:47'),
('58800762-c1cd-4cd6-bb51-21a4e48a7829', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:29:49', '2020-06-10 06:29:49'),
('5891245f-a15b-4819-941c-4937f8bf0b69', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:57', '2020-06-26 10:03:57'),
('58a1195e-6a87-48e5-900d-d91da11bad31', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:50:42', '2020-06-11 09:50:42'),
('58b8d30e-bf47-4990-90c8-75fe2e43f890', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:51:26', '2020-07-08 09:51:26'),
('58d822b2-86a0-432b-b3cd-6bc7bca80c78', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 10:03:51', '2020-06-12 10:03:51'),
('58d8e912-b638-4848-8112-d61e4736b8c4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:50', '2020-06-28 05:46:50'),
('590adf25-c0da-4a45-9350-67c4a6226a2d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:24:01', '2020-07-02 04:24:01'),
('59142eb4-4b98-4aa5-9bde-11f594520bce', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:34', '2020-06-26 10:04:34'),
('592560a5-7efc-4ffa-8d4e-08457051b177', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 02:37:19', '2020-07-22 02:37:19'),
('59a479b7-21ad-494d-b8fe-3fc9c0368b99', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:53', '2020-06-26 10:03:53'),
('59db4d39-1cee-4c37-adc5-d6bd51fea69f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:40:01', '2020-07-02 04:40:01'),
('5a13a81b-06bc-4967-ab3c-0ecf40095c2b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:21', '2020-06-26 08:33:21'),
('5a23c693-5856-42d0-b772-0916f9df2da3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:37:19', '2020-06-26 08:37:19'),
('5a28c172-db53-477d-8c15-16bb84ad0435', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:24:45', '2020-06-26 10:24:45'),
('5a50ffc5-86b2-4361-a299-ed8b0aa202b5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:33:43', '2020-06-28 05:33:43'),
('5a88e589-8da3-4a84-b9fc-5defb91ab836', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:25:51', '2020-06-10 14:25:51'),
('5aaf351c-baec-49c7-8ad1-e8e34e299f8e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:12:15', '2020-06-29 00:12:15'),
('5ad09abf-f52e-4044-a815-9752b3ff3261', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:21:46', '2020-06-26 11:21:46'),
('5ad0d921-a773-4ef7-86f2-a3517b9056ee', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:44:10', '2020-06-10 02:44:10'),
('5b1ab1e1-b220-415c-8ec2-badd3565be07', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:41:59', '2020-06-17 05:41:59'),
('5b262774-313f-4211-824e-9efa1d154df8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:55:58', '2020-06-26 07:55:58'),
('5bdafe9a-cb8f-464b-af47-095d9f836094', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:28:54', '2020-07-08 07:28:54'),
('5c4a3552-5f71-4760-9647-bcd39c41e5af', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:57:55', '2020-07-08 07:57:55'),
('5c72a81b-3e16-455b-b332-a0514e1768a3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:06:25', '2020-07-07 07:06:25'),
('5c7f1369-51fa-4505-86c3-61e0e592d6a9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:33:45', '2020-06-26 07:33:45'),
('5c8d267b-f0ac-4b26-a1d0-72ddea00cf9f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:39', '2020-07-07 07:04:39'),
('5ca529e8-7416-459e-989c-4f726fe3333a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:57:36', '2020-06-26 09:57:36'),
('5ca5c2f4-31d2-441a-a250-de46d366c030', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:26:56', '2020-07-09 04:26:56'),
('5d02e954-dd23-4ab9-b2ec-e99dcafe01da', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:23:28', '2020-06-26 11:23:28'),
('5d41bdee-21ee-4c39-b1fc-97b0868237a2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:14', '2020-06-26 08:33:14'),
('5d4e7213-f586-4d6a-ac75-061238b1350a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:32:02', '2020-07-08 07:32:02'),
('5d5608e4-59c5-4467-ad5f-e61db9112387', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:09:37', '2020-06-27 06:09:37'),
('5d7806b3-c79c-46c6-8934-ae725d22b032', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:31:45', '2020-07-08 07:31:45'),
('5d7d4e28-2341-4ccd-b929-77045c6bb730', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:12', '2020-06-26 10:07:12'),
('5da75f2d-214b-41c0-bb5a-8cb3c11b6f28', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:17:23', '2020-06-26 08:17:23'),
('5ddff98b-3539-40a5-9c52-811b7e4b262d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:15:32', '2020-07-08 08:15:32'),
('5e081db9-ad99-42fb-b0ca-b05679baf811', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:27:20', '2020-07-09 08:27:20'),
('5e5e0a2a-57e7-4ff5-9abb-938921165f32', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:09:43', '2020-06-27 06:09:43'),
('5e63d883-1c95-44e3-9ecb-956cf95a045a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:14:52', '2020-06-26 07:14:52'),
('5eaa54cf-10ad-44f6-9b8a-5f3f38c20184', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:07:14', '2020-06-30 10:07:14'),
('5ebbd93e-2471-4904-b6e3-d5def6cc8fb3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:11:50', '2020-06-12 08:11:50'),
('5efc20aa-f5dd-4ee6-8cab-3f33ef4d0e51', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:59:23', '2020-06-26 06:59:23'),
('5f07a9a3-f276-4a43-84c2-2b133cb1bb47', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:07:18', '2020-06-30 10:07:18'),
('5f37c02a-8a98-4fbf-8661-7c2bb0f1ba5a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:14:39', '2020-06-26 12:14:39'),
('5f83a608-ed06-4fcc-b41f-5b38b19c7635', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:24:03', '2020-06-26 12:24:03'),
('5faa500b-03ab-4bf1-bac5-356d8050987c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 12:38:17', '2020-06-28 12:38:17'),
('5fbe72e9-fa63-4557-a3b1-6d24e17e3518', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:59', '2020-06-26 10:01:59'),
('5fd1dd36-e2dd-4874-96b0-0a403358f3b7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:50:51', '2020-06-11 09:50:51'),
('5fd9eaa9-8bfe-4b12-bea4-07716463b636', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:23', '2020-06-26 10:29:23'),
('5fdd0380-496b-4dd4-84a8-ff456e586b6a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:11:35', '2020-07-03 06:11:35'),
('5ff152b9-00ec-4fe2-b965-ff38562ae67c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:14:56', '2020-06-26 07:14:56'),
('6011f1b5-8fc2-41ce-968a-f00cd9265aa4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:42:57', '2020-06-17 05:42:57'),
('60353f00-4db6-48eb-b148-9466098d7ae7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:14:35', '2020-06-26 06:14:35'),
('604be24a-2019-470d-b2c1-c46ddcbd030a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:35:24', '2020-07-06 05:35:24'),
('6065e941-4415-4536-bfc2-8d0334dcf98d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-09 21:04:32', '2020-07-09 21:04:32'),
('61d2e668-2a79-4684-962c-4fe750ddc207', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-01 11:32:31', '2020-07-01 11:32:31'),
('624e22d9-5a67-4ff0-ac28-5698e7d992f6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:22:17', '2020-07-02 05:22:17'),
('62ae44fd-42a1-419d-a54e-dd001367ffe6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:24', '2020-06-26 09:02:24'),
('6352dbd4-f5c3-4102-97de-7096d40c00ca', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:16:50', '2020-06-26 09:16:50'),
('63b4bf84-414e-4946-9d9b-8ec8de280677', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:49:48', '2020-06-26 09:49:48'),
('63e59c9b-37a0-431c-8815-fa1fc06f4ee5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 12:49:43', '2020-06-28 12:49:43'),
('63f2f5b6-41e4-4613-ad92-9e1b46c2ce12', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:59:16', '2020-07-08 11:59:16'),
('6424e33c-8d11-4aa6-8cef-a8b29211c108', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:22:32', '2020-06-11 10:22:32'),
('64799488-fb44-4eb4-a942-8c52c33d6d3d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:21', '2020-06-29 01:27:21'),
('64beae75-9ffb-43a7-9edf-26baf3231149', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:10', '2020-06-26 10:04:10'),
('64dedde1-e9a6-4d0d-b39a-c1324575899a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-09 13:03:09', '2020-07-09 13:03:09'),
('6544df8a-8a3f-43ac-a1ca-2f3b9d6b069b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 01:10:21', '2020-07-03 01:10:21'),
('654cc474-d447-452e-b997-f25ae90d96fd', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:29:54', '2020-06-26 10:29:54'),
('658ebd3f-9eb1-4586-a489-ce183d6c86f8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:09:35', '2020-07-08 11:09:35'),
('65bc8a74-357c-4939-a751-7126cd9e1c4d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:43:42', '2020-07-20 11:43:42'),
('65d7f27f-ad01-47ce-9575-cd79ee4527fa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:10', '2020-06-26 10:03:10'),
('664902db-287e-484d-aa8a-01db3d4711a3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:08:35', '2020-07-03 06:08:35'),
('665e4416-f78f-4d90-90e7-26878ebd3ebb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:31:11', '2020-07-05 08:31:11'),
('666f56b7-41da-4c81-bb34-e9c60305b6ab', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:57', '2020-06-26 10:02:57'),
('66d13f6a-b3c8-4c23-917b-847ee43da5b7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:52:23', '2020-06-27 04:52:23'),
('673210b3-519d-41c5-8e9b-54fb18afd325', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:47:13', '2020-06-28 05:47:13'),
('678098b9-d6e9-456b-866e-c7d3dc6d644a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-04 10:27:50', '2020-07-04 10:27:50'),
('67950888-c1e0-488d-8f14-de9a027dfab8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:51:57', '2020-07-09 08:51:57'),
('681ba3c2-dc08-42d1-ab7c-61a2a63653e7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-27 05:35:31', '2020-06-27 05:35:31'),
('686ec0c1-c54a-4ebd-a187-7c6e9ad16e4a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:58:21', '2020-06-11 10:58:21'),
('687defba-186e-4b68-a138-576210a39561', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:06:19', '2020-07-07 07:06:19'),
('691d9854-4502-416d-9310-4d4b542b9c11', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:31:56', '2020-07-08 07:31:56'),
('69df376d-a055-4a31-9d1a-6b85a0a43587', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:26:53', '2020-06-26 12:26:53'),
('6a242815-fd81-4bed-aa91-acd97a96d144', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 04:57:47', '2020-07-03 04:57:47'),
('6a7ba37a-e47e-40ee-a630-845bb9daa8af', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:09', '2020-06-28 05:25:09'),
('6bb66fc5-406f-437b-b4ec-c250249ec4f2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:03', '2020-07-07 07:04:03'),
('6c423481-5ebe-44c1-9abf-b07fcece5edb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:02:52', '2020-07-08 11:02:52'),
('6ca7214a-c9f4-4d5a-b329-cfb8dcab2581', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:29:57', '2020-06-29 01:29:57'),
('6ce991cb-8687-4516-b57e-851d50cb56a6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:35', '2020-06-28 05:44:35'),
('6d2dc840-38bb-40b6-b420-c7bac89184f1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:16', '2020-06-26 10:05:16'),
('6d38003c-6e40-43e7-b074-035c69785ac4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:37:02', '2020-07-08 07:37:02'),
('6d5346ea-19b3-44d7-aab2-b02652f3b005', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:29:04', '2020-07-08 07:29:04'),
('6e117eb6-ddcc-4ac2-8668-b93bc1e2e972', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-04 10:33:26', '2020-07-04 10:33:26'),
('6e4ac5f6-c82a-4119-b2e5-461b08e42639', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:37:41', '2020-07-02 04:37:41'),
('6e606208-5b9e-40bb-94af-b128418c98db', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:08:59', '2020-06-29 00:08:59'),
('6ea97e83-f60e-4864-b841-65694bd8408c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:04:08', '2020-06-17 05:04:08'),
('6ecfd998-f7e8-4125-8bc2-204268188dc1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:03:23', '2020-06-26 08:03:23'),
('6ef19937-7139-4133-b768-3d6cc3e39888', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:55:00', '2020-07-08 11:55:00'),
('6eff42a7-3bf8-4aa7-9c34-492ddda1ee58', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:08:09', '2020-07-08 11:08:09'),
('6f29c683-6219-4539-a3c8-b514cf8d9093', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:49:39', '2020-06-26 07:49:39'),
('6f3db6f0-b837-4f74-9267-e8fa1b21e41e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:01', '2020-06-26 08:27:01'),
('6fa91d2b-8a06-46ff-898e-41f3f4bb490b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:57:20', '2020-06-26 07:57:20'),
('700f3479-4bfb-46e2-aa4b-d85eca9cf1cd', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:50:44', '2020-06-26 09:50:44'),
('70e4bcc1-4f16-4d0b-a013-b7e1f67b140b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:49:53', '2020-06-26 09:49:53'),
('70f9e232-e588-443a-930d-2e070bcc82e9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:15:35', '2020-07-09 05:15:35'),
('7113be99-71df-4bd4-ac00-d0f9fbe3f89c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:45:54', '2020-06-17 05:45:54'),
('7148093c-938e-45e0-807f-e9ba195aa807', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:26:19', '2020-06-28 05:26:19'),
('71657aac-018b-407c-b057-8dda7f1cbd05', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:17:19', '2020-06-11 07:17:19'),
('71a42de1-a773-4e6d-b09d-358468ac524f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:13:33', '2020-06-12 08:13:33'),
('71e27058-3571-4429-ab89-8503a7758509', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:48', '2020-06-29 00:15:48'),
('71e29923-ae2d-4a79-8182-4d4686eb8bfc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 10:03:46', '2020-06-12 10:03:46'),
('71ff6d09-47c2-4bfe-bc9c-1df6caaf0669', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:27', '2020-06-26 10:29:27'),
('7200e1d7-a838-4405-8831-77f9a06eb083', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:20', '2020-06-26 08:09:20'),
('7234c63d-527d-48fe-87d5-f8a37a98a3e0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:43:05', '2020-06-28 08:43:05'),
('72511654-1ff9-4950-87d5-3c2d51bf7ccc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:38', '2020-06-26 08:34:38'),
('727ebd69-7d89-45de-9f5c-3ba40f6f33c4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 04:57:53', '2020-07-03 04:57:53'),
('728070c5-a707-4e20-9ca9-c7da690401b4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:16', '2020-06-10 14:26:16'),
('72b10d73-095d-414f-b4f8-e42b4daa8f7d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:23', '2020-06-26 10:07:23'),
('72b5f12a-2afc-4c6f-b976-26db10f22bfd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:42:02', '2020-07-09 05:42:02'),
('72c83bb6-41d6-4165-9388-ffe39888b6aa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:54:17', '2020-06-27 04:54:17'),
('73264103-0f25-434d-a8f1-067cc3dff165', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:09:44', '2020-07-08 11:09:44'),
('73647822-c5bd-4c7c-8214-8c0447c4cef3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:30:11', '2020-06-26 08:30:11'),
('73d72623-d924-4d87-b956-c897d2240134', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-07 03:58:16', '2020-07-07 03:58:16'),
('73e5ddd1-d139-455c-b040-00f17ff851eb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:19', '2020-06-26 10:06:19'),
('73e80108-81d3-42b9-a35c-f183976c661b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:51:14', '2020-07-08 09:51:14'),
('74439898-03d6-44c6-807f-58f0be64cfd7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:13:37', '2020-06-12 08:13:37'),
('74580db7-c7ea-44c3-bb1c-ae595a4f79e9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:49:30', '2020-06-26 07:49:30'),
('74bbbe3f-2e0d-48de-9d78-20b335d89994', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 05:00:25', '2020-07-07 05:00:25'),
('74f3fade-5076-448b-bc3c-aee84adae6a5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:45:14', '2020-06-27 05:45:14'),
('75262963-ed41-4379-94c0-1827b280e54b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:13:43', '2020-06-26 12:13:43'),
('754f4e88-28b9-4ca0-af06-5d8731c224d4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 8, '[]', NULL, '2020-06-19 06:23:44', '2020-06-19 06:23:44'),
('7556964a-8ef5-43c0-85f1-b45ccb5cc3d2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:17:07', '2020-06-26 08:17:07'),
('7623eca6-4f47-4668-9c6c-c7362ff9133e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 10:02:19', '2020-06-12 10:02:19'),
('76395674-7a5c-4123-bb71-7df24ed3427b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:23:18', '2020-07-08 12:23:18'),
('76644385-9df4-46d9-92ab-4f2937cd8d9a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:06:01', '2020-06-26 12:06:01'),
('76e93f53-6227-4b61-8c2a-eb8dbe67ab76', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:37:24', '2020-07-08 07:37:24'),
('77163110-c2e0-4cae-a611-bdbbea43920f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:42:01', '2020-07-09 04:42:01'),
('77d58576-6a8f-41a4-8fd9-b18f4cf2e8e0', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:22:37', '2020-06-29 01:22:37'),
('77e04a6e-ae7e-4000-a20f-712abc3d5f21', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:13', '2020-06-26 10:05:13'),
('77fac541-57cb-4f43-a368-6a9d3c3eab43', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:11:52', '2020-06-26 12:11:52'),
('787eabce-3b9b-4806-83c4-68512b5d62a0', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:44:31', '2020-07-20 11:44:31'),
('789e8b1e-e190-4912-8848-85191ef91be4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:18:09', '2020-06-29 01:18:09'),
('790074f8-3292-48a6-928b-7d6db5395b35', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:38', '2020-06-26 10:02:38'),
('79586189-2be0-486e-89dd-35a571a1d65a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:03', '2020-06-26 10:05:03'),
('796dd010-972b-4215-b530-019992785848', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 06:12:45', '2020-06-26 06:12:45'),
('799cee53-b07d-4376-8e29-59d30e5ddc89', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:32:41', '2020-06-10 03:32:41'),
('79be94d7-38fd-44f0-9688-76549fcb64ad', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:08:05', '2020-07-08 11:08:05'),
('79ca3585-9e4c-4834-a48b-ea01715b6983', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:13:19', '2020-07-02 03:13:19'),
('7a4f0da9-3d18-4847-b500-36df4c7a1376', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:44', '2020-06-29 00:15:44'),
('7a781c04-0a71-48df-a0dc-26935425bea4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:19:31', '2020-06-26 12:19:31'),
('7a91723f-af23-4fc2-8a25-9dbba03c7a82', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:56', '2020-06-26 10:06:56'),
('7aa756cb-5376-4fc7-b803-2429609b488d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:22:28', '2020-06-11 10:22:28'),
('7abdffe8-7dc3-456c-b514-f3ebfe66f7ce', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:12:16', '2020-06-26 07:12:16'),
('7accf011-6f79-4f21-a6ef-2f510c31ff7e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:39:54', '2020-06-11 10:39:54'),
('7b0bcd99-a526-4cfd-8bf1-ecba6e1264b6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:54:13', '2020-06-27 04:54:13'),
('7b1d6075-9c74-4c5f-b147-a846cec2b6ce', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 12:38:22', '2020-06-28 12:38:22'),
('7b9199cb-bf55-4814-8add-eae984e5684b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:05:20', '2020-06-26 08:05:20'),
('7b9db58c-6f18-4fcd-aab7-51cf729f123a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-18 03:31:01', '2020-06-18 03:31:01'),
('7bb2cd03-61f6-45b2-8d0a-e6a275d4e485', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 03:39:55', '2020-06-28 03:39:55'),
('7bbdc604-8b47-4c9b-9d25-2577c137df5f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 06:42:41', '2020-06-29 06:42:41'),
('7bf5ec3a-e126-47fb-bc2c-05f8b1dd0b63', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:00', '2020-06-26 10:04:00'),
('7c866445-3d73-43be-b03b-2f9668dfbbb9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:32:13', '2020-06-10 02:32:13'),
('7cc8844b-e9f3-437e-bcbc-4bead9cf2043', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:20:03', '2020-06-26 08:20:03'),
('7cc8d8c4-361d-4064-ac20-98c055aff162', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:08:48', '2020-06-27 06:08:48'),
('7cc9f28c-84cc-4e75-a2ca-eb7bb1b82738', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:52:29', '2020-06-27 04:52:29'),
('7ce5d79f-c489-4120-a6f3-a677fdc5cd45', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:58:32', '2020-07-07 04:58:32'),
('7ce6911c-9ce2-49df-ae3f-ac93162a1995', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 01:10:27', '2020-07-03 01:10:27'),
('7cf1b4d7-0b6f-45a1-bc1c-02fafbd87f7f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:13:01', '2020-06-11 10:13:01'),
('7d23ee78-2264-4214-8b13-8ad29cdca17b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:11:47', '2020-07-03 06:11:47'),
('7d61ba9c-6d6a-4cb1-8c92-72e0e97e592b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:55:33', '2020-06-26 06:55:33'),
('7d960eb8-60c2-44f1-beec-b0411175a1d1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:01:20', '2020-06-30 10:01:20'),
('7da17372-57c6-4958-8243-ae8f4c308e2d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:53:05', '2020-06-30 09:53:05'),
('7dd746e8-689c-413c-8edf-28e3507694e8', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:29:58', '2020-06-26 10:29:58'),
('7e0e06ad-9acd-44e6-a5ff-2afeb6aa363f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:54', '2020-06-26 10:04:54'),
('7e200153-a10c-4ccf-a114-c0afdc05d6ea', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:43:02', '2020-06-17 05:43:02'),
('7e23eb14-53eb-4e49-aca0-d2ed11b82d0e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:17:13', '2020-07-02 05:17:13'),
('7e463e8f-698d-4b9e-9fe3-c1ef27bd8086', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:22', '2020-06-26 10:01:22'),
('7ee6e75f-ee9d-42e2-b826-0b2a79e7bdf6', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:45:03', '2020-07-22 00:45:03'),
('7ef4cdb8-69a3-482d-b830-d6ef4c4a27f6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:25:45', '2020-06-10 14:25:45'),
('7f0a19e4-c10f-438e-ba09-d30dbefcbe41', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:34:43', '2020-06-29 01:34:43'),
('7f157ba2-7c01-4d78-a597-eb271e43cac5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:51:28', '2020-06-26 09:51:28'),
('7fa42af6-9ead-4774-8307-d2f462adbc49', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:47', '2020-06-26 10:04:47'),
('7fe0f46a-a034-4ab2-977b-bca37c197cc0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:13:36', '2020-06-26 12:13:36'),
('7fe1a4c5-9133-4543-b28f-4faa8ab01d00', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 01:10:33', '2020-07-03 01:10:33'),
('80335732-8600-4c14-9519-3658eec04a14', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:45:07', '2020-07-22 00:45:07'),
('8086077f-4916-49bd-9066-380f4f338a03', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:03:04', '2020-07-06 05:03:04'),
('80be77fe-5869-4755-934d-366f70623178', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 11:59:04', '2020-06-26 11:59:04'),
('80f78c2c-a0cc-4548-89e6-87bb056ff729', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:56:07', '2020-06-26 07:56:07'),
('8127f8e7-62da-4090-957f-7abbcb6ce7ae', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:13', '2020-06-26 10:03:13'),
('812f44ad-3fdc-43f4-a941-957ec2a54281', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:00:37', '2020-06-09 15:00:37'),
('81ebf52c-fbb6-477a-87ed-4c15bf08b1f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 06:53:36', '2020-07-07 06:53:36'),
('822d3e4b-a7b7-4f48-89af-eff7f4ff46ad', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:45:19', '2020-06-11 09:45:19'),
('822eaaa7-e0d2-41f7-a706-fac7b659a62e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:57:04', '2020-06-26 12:57:04'),
('82b0fc32-8716-42cc-8db6-d56a9406dab0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:46:03', '2020-06-17 05:46:03'),
('82be9595-a8fa-46b6-85e9-552d589d357f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 00:06:23', '2020-06-29 00:06:23'),
('82cafc16-9d30-49f8-86e2-098208900282', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:37:14', '2020-07-08 07:37:14'),
('831831dd-e73e-409a-9d98-d7492aefecf9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 06:53:29', '2020-07-07 06:53:29'),
('8322710a-d736-41b7-a088-ff512eef8e35', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:43:11', '2020-06-28 08:43:11'),
('83a56d6d-dbd5-4718-82d7-f6539542a1b7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:11:39', '2020-06-29 01:11:39'),
('83f7185c-04a4-4125-9f64-5fee2e693fee', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:03:15', '2020-07-06 05:03:15'),
('84228ec0-c41a-493a-b8ed-e1f92b6cae6e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 06:53:42', '2020-07-07 06:53:42'),
('842648c4-a726-41b9-a979-a75fc8461e65', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:09:26', '2020-06-10 06:09:26'),
('84f6b6cb-f912-42b3-967d-b85a81e8561c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:52:20', '2020-07-08 07:52:20'),
('8529f075-c961-4df3-862c-f47e7175dac2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:23:36', '2020-06-26 12:23:36'),
('85b591fa-077a-4fb5-961d-95bae0ace3a3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:06:54', '2020-07-02 04:06:54'),
('85cd26a1-83c9-4177-9c6e-a3f79e7c26b1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:19:50', '2020-07-02 04:19:50'),
('85f98865-e48d-4a0c-8073-4420358870d2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:58:27', '2020-07-07 04:58:27'),
('85ff73e1-cd3a-4021-b747-5b811f056191', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 11:23:49', '2020-06-28 11:23:49'),
('8643ee05-d61f-46d1-95d6-262e65334b48', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:06:34', '2020-07-09 05:06:34'),
('8658e891-c4c5-4ef3-bbc9-ee9ee7f19778', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 11:04:08', '2020-06-30 11:04:08'),
('86c0c968-12b9-4d8c-a4cd-2f351f458633', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:30:15', '2020-06-26 08:30:15'),
('86d8f4f2-2286-4423-b4be-805c6685c2a1', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:24:49', '2020-06-26 10:24:49'),
('86dc7f71-5428-4a7c-bd4f-63fe583cf3e8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:34', '2020-06-26 09:02:34'),
('8710b973-ae12-4a14-baf4-789d4e33dabb', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:11:15', '2020-06-12 08:11:15'),
('8714d5a7-d7a0-4ec8-9664-86cd64407e91', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 12:50:48', '2020-06-28 12:50:48'),
('8721442e-a08f-4a01-8ef8-a57b8826cd2c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:50:47', '2020-06-26 09:50:47'),
('873c695a-538f-4a82-94b0-6d8e94dd87cf', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:17:32', '2020-06-26 08:17:32'),
('87419d89-068f-4f23-8161-ac7084b9fe77', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:47:02', '2020-06-26 06:47:02'),
('8760c479-69cb-4b5d-b99b-46fe36d6e6ee', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:27:40', '2020-07-08 12:27:40'),
('87809986-f267-4690-aecf-5d5684901328', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:13', '2020-06-26 08:29:13'),
('87e98ef0-aa52-49ae-98c2-22a09710d1f9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:02:53', '2020-07-06 05:02:53'),
('8861f80d-21c7-4b3a-b93a-c2130c2e9939', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:37', '2020-06-28 05:27:37'),
('8881798b-3d87-4b0a-aaa7-e0a00157f94f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:53', '2020-06-26 10:05:53'),
('88e5e175-3132-4757-9c24-67b416d971c2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 05:00:08', '2020-07-07 05:00:08'),
('899a7f62-9d51-440a-955d-463b83190ae2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:31', '2020-06-26 10:01:31'),
('899ce24f-c996-47c8-96e8-caf69bf08720', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:23:57', '2020-06-26 08:23:57'),
('89acae99-ae44-4e52-87b2-26f228af9a62', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:24', '2020-06-26 08:27:24'),
('8a0e6d71-4f5a-4bbb-880e-64db77986940', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:08:38', '2020-06-27 06:08:38'),
('8a470ab9-f95f-418d-9327-9622c27399d3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:18:17', '2020-07-09 05:18:17'),
('8b725fad-6390-4c80-bbe1-4f1fcdb5b524', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:06:32', '2020-06-26 08:06:32'),
('8be0f972-2179-4bdd-8360-6f809a094776', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:01', '2020-06-26 08:33:01'),
('8caf5b60-85e7-4d30-b5df-09da68337535', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:51:10', '2020-07-08 09:51:10'),
('8d19cd1f-e3d6-467c-b9c5-59cb0e6465f5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:29:53', '2020-06-29 01:29:53'),
('8d456f6d-7e24-423a-9d41-ac8039186f0f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:37:45', '2020-06-26 07:37:45'),
('8dc2125a-7f9b-4c41-be2f-de94911eb0fe', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:20:12', '2020-06-26 08:20:12'),
('8e1b703e-cc9e-4bf0-9bd8-4a6f1bc4dc04', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:14:47', '2020-06-26 07:14:47'),
('8e400f3c-bcbb-4b66-ae3f-25f8c4c89370', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:50', '2020-06-26 10:02:50'),
('8e4bc417-f16c-4572-8518-10a82208baf0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:37', '2020-06-26 09:02:37'),
('8e6fa160-ec86-4ea8-aa30-6c5a808e2e9d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:05:56', '2020-06-26 12:05:56'),
('8e8060d4-5221-48ff-897d-a5e0edcd6e43', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:46:57', '2020-06-26 06:46:57'),
('8ea05c78-5f9e-4402-8867-9af19582020b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:35', '2020-06-26 10:29:35'),
('8ece7111-6845-498d-b7c5-d7872e32942d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:45', '2020-06-26 10:02:45'),
('8f6aa1aa-eba2-483f-b2f4-c598c9b2e1d9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:27:54', '2020-06-10 14:27:54'),
('8f784bf3-5fcf-4bff-95be-c6bc972cf5ba', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:59:39', '2020-07-08 11:59:39'),
('8fa9da72-6b1b-4c9e-aa77-c3311ad121e9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:18:02', '2020-07-09 05:18:02'),
('8ff2cb77-65ae-470a-a724-485d666438ab', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:56:47', '2020-06-11 10:56:47'),
('90055aec-7e74-4463-92fb-0de81993b9d3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:54:39', '2020-07-08 07:54:39'),
('90f0c978-e536-4e46-971b-27397a8d220b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-18 03:31:07', '2020-06-18 03:31:07'),
('90f4bdaf-effd-4cff-8006-9222d2b39da3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:31', '2020-06-29 01:27:31'),
('90fd4bc7-9e6f-493c-8c7d-aad724e5dfad', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:36:45', '2020-06-29 01:36:45'),
('912b3e20-281a-40da-9b29-5bda93f278fe', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:20:18', '2020-06-29 01:20:18'),
('9158c10c-de57-48e1-9b6e-294ce01022be', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-29 05:12:25', '2020-06-29 05:12:25'),
('9167408b-f9f2-4983-8fc7-066ee4589d06', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:36:35', '2020-06-29 01:36:35'),
('9193a73e-47ee-4389-8dd2-dcc52658feea', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:46:13', '2020-06-27 05:46:13'),
('91e92792-c87a-4f78-85ff-0c3651278c99', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:04', '2020-06-26 10:07:04'),
('91f05875-3a81-47c4-ae66-d83753ea50da', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 04:19:49', '2020-06-29 04:19:49'),
('91f6fa41-1db6-4146-9fba-07a4f1fe151f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:46:09', '2020-06-28 12:46:09'),
('9209da8e-24f8-4ecb-a35c-9047113532d8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:09:27', '2020-07-08 11:09:27'),
('92396b40-bb39-47fd-9d69-33eb869c9eab', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 05:23:37', '2020-07-03 05:23:37'),
('923fe28a-5561-4d87-983e-ed930f385997', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:52:57', '2020-06-28 06:52:57'),
('92559cf2-7aba-481a-9c91-a2ea8e94ee75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:36:48', '2020-06-27 05:36:48'),
('926ae8bc-dbf0-477a-bef6-ea4377b0dfd9', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:09:14', '2020-06-29 01:09:14'),
('92af3306-3d4a-4780-ac62-66a9c0307a5e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:17:35', '2020-06-30 09:17:35'),
('933b5307-1f96-4806-8d63-11080e028ad7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:22', '2020-06-26 10:03:22');
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('9375bbb3-8027-4e18-91e8-271a00892ab0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:55:09', '2020-07-08 11:55:09'),
('941089ff-f43c-4e7c-9bee-f5a68faf47d4', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:25:05', '2020-06-12 08:25:05'),
('945ad386-d770-45b3-97b2-216f5cc26fbe', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:09:25', '2020-07-02 04:09:25'),
('94850935-b5e8-45a4-b74f-f3be67d2f250', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:11', '2020-06-26 10:06:11'),
('9526049c-239e-45ca-a646-1d1f1fd70ab7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:52:33', '2020-07-08 07:52:33'),
('956bba8c-1c70-48b2-9820-a7487d97968a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-07 03:58:21', '2020-07-07 03:58:21'),
('95ae8c74-d3d0-4395-8198-9ed9686666f3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:37', '2020-06-26 10:04:37'),
('95cd690d-8d08-406c-85d0-3d3076455930', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:13:24', '2020-06-29 01:13:24'),
('95d01335-c554-4165-a1da-12f01de50a9a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 10:02:27', '2020-06-12 10:02:27'),
('963dd704-cd82-487a-95f7-daa81e842b75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:29', '2020-06-26 09:02:29'),
('96546cec-47bd-425c-9d5b-9b19342e3fcd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 07:49:03', '2020-07-06 07:49:03'),
('970ba9f1-8f08-42cb-b0f2-4a766a2b40b5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:50:52', '2020-06-26 09:50:52'),
('972abd53-6010-445d-987e-bffc40ea0165', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:37:14', '2020-06-28 08:37:14'),
('976cc8d5-7bac-4af8-8586-abd74942810a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:39:22', '2020-06-29 06:39:22'),
('999f1f6e-d237-4876-89b4-2d72ef0d042f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:58:10', '2020-07-08 07:58:10'),
('9a1176f7-8fd4-40c8-adfe-d97e7a9369fb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:00:13', '2020-06-30 08:00:13'),
('9a311d30-598c-4190-a7bd-636f48e367aa', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 07:45:48', '2020-06-26 07:45:48'),
('9a356ba4-9858-40b6-85b2-d3430753d34d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:58', '2020-06-26 10:05:58'),
('9a55e73e-cd86-467a-8b2a-f1244e051571', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:42:17', '2020-06-28 05:42:17'),
('9a729447-c81c-4a37-8262-5068f6074d0d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-01 11:57:21', '2020-07-01 11:57:21'),
('9a8ab02f-3a83-4bd4-9146-48e6c33d660b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-01 12:21:05', '2020-07-01 12:21:05'),
('9a8f5699-53e0-42ec-828d-6b315847047d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:39:13', '2020-06-29 06:39:13'),
('9a9d7dde-4128-4713-a464-3178cd05be6d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:37:02', '2020-06-26 08:37:02'),
('9ac54942-192d-4e11-ae05-24f1fa437ed2', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:24:41', '2020-06-26 10:24:41'),
('9acbf7c7-5ead-4d59-8b22-b077a572716c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-29 05:12:29', '2020-06-29 05:12:29'),
('9ad182a6-79a9-4009-8e01-102f63b1edb3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 12:50:43', '2020-06-28 12:50:43'),
('9b03c72e-0785-473e-bbbd-37a4add1d168', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:25', '2020-06-26 10:06:25'),
('9b2b567e-6b5b-4606-b5bf-9b03e7d46c5c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 05:23:30', '2020-07-03 05:23:30'),
('9b521f16-348b-4abf-914f-75757f16f78c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:56:00', '2020-06-30 09:56:00'),
('9b558d5c-9b55-4609-87ff-e6b88251403b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:09:13', '2020-06-29 00:09:13'),
('9ba564b9-66aa-49cb-b70f-74e0d5af90d7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:42:12', '2020-07-09 04:42:12'),
('9bdf8286-36fc-4220-9811-1f23994ee3c1', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:36:16', '2020-06-26 10:36:16'),
('9be4ec3c-7257-40c4-bca6-dab2c333877d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:42:06', '2020-07-09 05:42:06'),
('9bec7034-ccb6-47e9-8d63-482de923c94c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:25:08', '2020-07-20 11:25:08'),
('9c5d9e8b-4085-40e7-baa3-5b34458c7be9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 03:45:45', '2020-07-09 03:45:45'),
('9c649e97-b4a9-41c3-a472-f8684fe466ff', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:15', '2020-06-26 08:27:15'),
('9cb69cd6-0cab-4a34-95be-05025b19a83b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:58:25', '2020-06-11 10:58:25'),
('9d155e67-6c88-4b4c-a38d-211eff6d99bd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:09', '2020-06-26 08:33:09'),
('9d6cd58c-1e78-431b-b2e8-d32debb397dc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:40', '2020-06-28 05:46:40'),
('9da6cc7d-2412-4186-beb8-b32f20204552', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:11', '2020-06-26 10:02:11'),
('9e3dbd4b-b393-43ab-9771-b7e28e6db9f1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:27:00', '2020-07-09 04:27:00'),
('9e4c41f3-7d9c-4ff4-af00-bff72a0a42a7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:54:50', '2020-07-08 07:54:50'),
('9eb9c5c2-5e99-4a5c-a695-e6f38be86e3f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:54:08', '2020-06-27 04:54:08'),
('9ed6bad7-f9db-4735-8364-cbd5929df6e6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:18', '2020-06-26 10:01:18'),
('9f17e713-d87b-4756-9178-ca8ccac09ebc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:15:14', '2020-07-08 08:15:14'),
('9f7f4f0b-1f0b-44ba-9bec-c66e0b92ddbe', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:27:14', '2020-06-11 10:27:14'),
('9fe356e5-663d-43f7-9c91-b1640d148467', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:25', '2020-06-10 14:26:25'),
('a07f4d87-8a91-4474-a51b-ef6fa0d9240e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:10', '2020-06-09 15:06:10'),
('a0a4d339-bc8e-4952-a61f-c7e8be8b9149', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:42:52', '2020-06-17 05:42:52'),
('a1322420-bef1-47ec-b43f-140df2768195', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:15:30', '2020-07-09 05:15:30'),
('a14ade8f-8a8a-4711-b1b0-cb3d82e71120', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 8, '[]', NULL, '2020-06-19 06:23:39', '2020-06-19 06:23:39'),
('a17d0750-38e0-4e3e-b04f-2b75605a2352', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 09:11:27', '2020-07-07 09:11:27'),
('a1a30e1f-a2bc-4872-94d1-6f487cb9d6a9', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 06:42:46', '2020-06-29 06:42:46'),
('a1a3b247-25db-48c6-b688-eb1dc52878d7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:17:00', '2020-07-07 04:17:00'),
('a1bfa70f-288a-412c-903b-c2b8bf2bfa71', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-01 12:30:55', '2020-07-01 12:30:55'),
('a20501dd-c40d-4c10-9b70-8dae01c313c5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:10:45', '2020-06-30 10:10:45'),
('a26ad78c-7a28-4fe4-b920-952173e7e52c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 12:49:47', '2020-06-17 12:49:47'),
('a28e1102-ade2-4c52-8261-872d51f6a687', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:43', '2020-06-26 08:34:43'),
('a3144328-88ea-4d9e-803b-93b29b04106a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:52:33', '2020-06-27 04:52:33'),
('a3275ae0-0932-402b-a62f-0bd6a6852b01', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:17:38', '2020-06-11 07:17:38'),
('a33c2c43-a603-4ff7-8b23-63326d54a896', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:45:07', '2020-06-11 09:45:07'),
('a34d2d92-1ff9-4cd8-b897-7b8c50ec6173', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:17:17', '2020-07-07 04:17:17'),
('a360ee68-f4af-4113-8ee0-15fae30b255c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:13', '2020-06-26 10:01:13'),
('a375b4a9-f019-4065-93c1-bb7e4c61d05e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:22:32', '2020-06-29 01:22:32'),
('a3b99511-8daa-43c5-be68-b07f9aed3701', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:36:21', '2020-07-02 04:36:21'),
('a48e8830-05e1-4720-9fb0-4535f3edb4ac', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:57:06', '2020-07-08 11:57:06'),
('a4aa6647-0786-465b-b1ed-792f7ebe7330', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:58:05', '2020-07-08 07:58:05'),
('a4aacb30-6d9a-4b44-8752-b2e54e7f0754', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:06:35', '2020-06-26 08:06:35'),
('a4c9f55a-af0b-48a5-b8e5-f2c752ea4c65', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:23:21', '2020-07-08 12:23:21'),
('a5a97577-0b34-40a6-bd8c-82f28741c381', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:57:20', '2020-07-08 11:57:20'),
('a6ae6712-e49f-4150-847e-7e355f5210d0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:12:31', '2020-06-26 07:12:31'),
('a6e6331c-de3f-41f4-a44e-0d5fb76f0f93', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:29', '2020-06-26 10:02:29'),
('a77242a1-dc09-4d21-80bf-1e15f9dc6c55', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:28:17', '2020-06-30 09:28:17'),
('a7ef54fe-e39d-47a4-a594-dab793791d48', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:31:23', '2020-07-05 08:31:23'),
('a7f3b484-d5d7-46e4-a5a7-048d139d0b29', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:18:08', '2020-07-09 05:18:08'),
('a829ca6b-e4e7-49bc-a018-3fab12a82799', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:52:00', '2020-07-09 08:52:00'),
('a8a84ce1-62a9-4f72-95bd-393b2b28b3f1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:57:25', '2020-07-08 11:57:25'),
('a8b57c97-9968-42bc-a3a1-bed91c6f8ec9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:52:57', '2020-06-10 02:52:57'),
('a937d68f-5471-43ff-b760-753a18fed1f5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 07:49:28', '2020-07-06 07:49:28'),
('a9a77334-10a7-49fc-96ba-93dfd498a676', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:25', '2020-06-26 10:04:25'),
('a9b9be86-ffcc-4a34-9684-313562179c75', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 07:49:22', '2020-07-06 07:49:22'),
('a9f775e6-d593-4727-b892-b69c34e372a7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:30:43', '2020-06-10 06:30:43'),
('aa02265d-db4e-4d5f-94c1-99e76c1110c6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:19:22', '2020-07-08 12:19:22'),
('aa2a2f8d-597b-423a-9137-76fefdbd2f14', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:24:03', '2020-06-26 08:24:03'),
('ab1c5a3b-d04a-4984-956d-9c8b20d564d6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:07:17', '2020-06-26 10:07:17'),
('ab3f8b3f-4652-4b29-81ec-45493d68a020', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:46:05', '2020-06-28 12:46:05'),
('ab711ea8-80b6-45cc-92e3-21f45cb93a4c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:27:48', '2020-06-10 14:27:48'),
('ac3a5460-b463-4064-8ce1-47fedf4c455e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 12:35:12', '2020-06-11 12:35:12'),
('ac941c09-8a67-4fdc-9bd5-da1344019e61', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-10 01:33:28', '2020-07-10 01:33:28'),
('aca499d3-8919-462a-8211-b40b581ddf9c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:59:35', '2020-07-08 11:59:35'),
('acded648-6b27-4bb5-a551-1d35ddd87b33', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:16:51', '2020-06-26 08:16:51'),
('ad67574b-4e54-4100-8ab2-b6a3e4a1524e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:15:07', '2020-06-12 08:15:07'),
('adeafd5d-dc1e-4e22-a6c2-0bb1c86044ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 09:05:14', '2020-06-10 09:05:14'),
('ae6edb12-6f05-4f57-adb9-2920dd18ad3c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:58', '2020-07-07 07:04:58'),
('aee55487-1afd-4463-bceb-7b2e4257229f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:35', '2020-06-26 10:03:35'),
('af6743a1-43b6-46fa-834f-e2254ae15d48', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:16', '2020-06-29 01:27:16'),
('afb1a075-50f8-4aca-a50b-e8db8ead3063', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:36:27', '2020-07-02 04:36:27'),
('afe90a33-1fa0-4c30-81fc-ae3b26a97c12', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:32', '2020-06-26 10:02:32'),
('aff825d3-2c1c-4c3d-89b8-55556c23c21f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:50:46', '2020-06-11 09:50:46'),
('affcf77a-0773-4de8-b1b4-80d43ca5d5ad', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:38:06', '2020-06-29 06:38:06'),
('b020ab47-5528-4e4a-b422-db841e98e05e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-23 12:24:49', '2020-06-23 12:24:49'),
('b081400c-a3bf-4fc4-afa8-14a355515813', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:00:28', '2020-06-09 15:00:28'),
('b0d8feff-e545-423d-87e6-0596b00bfdf3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 12:50:45', '2020-06-17 12:50:45'),
('b11bfe28-2577-4366-a2bd-58806a25654f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:28:49', '2020-07-08 07:28:49'),
('b12bc434-e234-4da3-890b-1fbefe58f6a9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:46', '2020-06-27 04:49:46'),
('b1c1eddb-2717-4398-b6bf-8e2221360ee7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:52:15', '2020-07-08 07:52:15'),
('b2029e50-0ab1-4fcd-9d38-defa98a09ac3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:38:13', '2020-07-09 08:38:13'),
('b2880fb4-2776-4842-9e5b-a1e03f8fd5de', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:07:00', '2020-07-02 04:07:00'),
('b336552f-117d-439d-bbee-9d9cacec0fe1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:37:04', '2020-06-28 08:37:04'),
('b344a4f6-cef9-423f-ba07-85765e5c0a9a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:37:10', '2020-06-26 10:37:10'),
('b3958cfb-19b4-4deb-8207-85a2fbce2f04', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 03:20:45', '2020-06-10 03:20:45'),
('b3b7d394-107c-4a7e-92e1-3fc09a092d43', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:06', '2020-06-10 14:26:06'),
('b3d2164b-ffa9-455c-bdcf-f23d6543a023', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:07:46', '2020-06-26 12:07:46'),
('b403ef4b-2bf6-45ae-bb47-f6dad32f5234', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:17:57', '2020-07-09 05:17:57'),
('b411fe66-f853-4f3e-97b6-66be13033df1', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-07 03:58:27', '2020-07-07 03:58:27'),
('b4c393f4-7f3c-4664-8918-7a3be2e265c0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:58:09', '2020-07-07 04:58:09'),
('b4c4bc6c-b715-4149-8e56-9c11c6fd2c3f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-04 10:27:56', '2020-07-04 10:27:56'),
('b4c4ee7a-54cd-43a4-bffc-f95b57b612b7', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:41:46', '2020-06-29 01:41:46'),
('b4f1c610-8349-4af6-bd2b-983e528a7f1c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:22', '2020-06-28 05:44:22'),
('b500e082-c4d8-44f0-8724-9cca6402be12', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:57:15', '2020-06-26 07:57:15'),
('b5e2beda-e42f-4c78-bc6e-5d4e2f214b3f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:53:03', '2020-06-28 06:53:03'),
('b65f1837-24b7-41c8-b6d1-d9f0f70bf163', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:19:25', '2020-07-08 12:19:25'),
('b6ddcf14-6505-4515-ae51-f485378af774', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:08:55', '2020-06-29 00:08:55'),
('b7422f62-3e05-4fd3-b527-d522686dbc90', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:54:45', '2020-07-08 07:54:45'),
('b76ed549-302d-4caa-8af0-458ecd0478d6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:30:20', '2020-06-26 08:30:20'),
('b789de14-be24-4611-b133-a51ba9b1fe92', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:57:01', '2020-06-26 09:57:01'),
('b7c95dfe-1040-4eb0-a56b-82a405c436ac', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:19:45', '2020-07-02 04:19:45'),
('b7ff2479-4df0-451e-b1b0-2bfa71fd1c24', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:33:39', '2020-06-26 07:33:39'),
('b867e230-7e04-43ae-ac7b-3ff9deff8482', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:01', '2020-06-09 15:06:01'),
('b87549db-03c2-4fe6-af3f-ad7c0cab40da', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:41', '2020-06-26 10:02:41'),
('b894b898-b69f-4e8e-8821-3c36b816eeff', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:56:54', '2020-06-26 12:56:54'),
('b89ab737-73d2-4323-bb60-42e398497dd0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:36:15', '2020-07-02 04:36:15'),
('b8bc1034-5e3c-4f18-aadb-c46c52c0a95f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:53', '2020-06-26 10:02:53'),
('b8e1a01b-459b-4ffe-a013-9da516f3f6fc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:09:49', '2020-06-11 07:09:49'),
('b8e69752-9887-4c59-a2c5-e8d274a0b30f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:41:36', '2020-07-09 08:41:36'),
('b978d3b5-7a2e-4a9b-a2e0-02e2bda0a1f6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:37:25', '2020-06-11 10:37:25'),
('b9811046-097a-4b2b-bd0b-d70b1b02b0e0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:11', '2020-06-28 05:44:11'),
('b9a906a7-d249-4594-8047-ba24433042aa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 3, '[]', NULL, '2020-06-17 04:53:20', '2020-06-17 04:53:20'),
('b9f13883-e3fe-43f7-b639-d597caca6e76', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:38:02', '2020-06-29 06:38:02'),
('ba98568a-109a-4b88-be19-4edad9287fa7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:23', '2020-06-09 15:06:23'),
('bb1ef005-a76d-409a-81fc-4d42a58f138f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:42:17', '2020-07-09 04:42:17'),
('bb332d92-627b-40b1-8047-49b37b38b5f5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:36:58', '2020-06-26 08:36:58'),
('bbc59e25-bf65-4ba6-ac0d-ab1667672613', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:45', '2020-06-28 05:46:45'),
('bc02dea9-51b5-4b26-b75e-7362a692dac8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:57:19', '2020-06-26 09:57:19'),
('bc08427a-3031-4614-93d4-b178f01eb517', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:25:36', '2020-06-10 14:25:36'),
('bc2d1ac1-3c31-4517-b599-abb58ca0a331', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:08', '2020-06-26 08:09:08'),
('bc3d56e0-3e94-4548-9d11-37283ac5b1f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:44:16', '2020-06-28 05:44:16'),
('bc4725b7-79b1-4c44-8149-c73f754c271a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:27:19', '2020-06-26 08:27:19'),
('bc545dd7-9295-413f-ae9a-dbccb09fb4a6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:03:47', '2020-07-07 07:03:47'),
('bc74680e-dd93-4b01-8a19-027b80a42554', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:09:28', '2020-06-26 12:09:28'),
('bc8ffc77-ab56-4250-a7a7-08ab09c760cc', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:13', '2020-06-28 05:25:13'),
('bd993ef3-5b3f-4afd-bca3-f6fe7a3e11bf', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:52:21', '2020-06-26 06:52:21'),
('bda0d3bc-844f-4b01-8355-1516f0558542', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:03:50', '2020-06-26 12:03:50'),
('bdaf09e9-6a24-4353-b63e-39c062ecb8d6', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:42', '2020-06-28 03:41:42'),
('be54e96d-9bf8-434c-95c4-850dd0d1fd8e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:08:16', '2020-07-08 11:08:16'),
('be731da4-d67c-44fc-91af-1474d828c06a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:42:26', '2020-06-28 12:42:26'),
('bed2782d-209c-4c33-99dc-6c201fc3cc83', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:25:55', '2020-06-10 14:25:55'),
('bfa88b69-c687-478f-aeca-06de55269f66', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:23:27', '2020-06-26 12:23:27'),
('c0348af9-3c97-4728-9f65-c7e66b502f0e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:28', '2020-06-28 05:25:28'),
('c085e226-fe1d-49b7-a7ca-6377668f1e98', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:52', '2020-07-07 07:04:52'),
('c0a0929e-93ee-472c-884d-e4382bea2b6b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:21', '2020-06-26 08:29:21'),
('c0aafa48-0de3-4494-a9c8-3cc033552fa3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 07:09:53', '2020-06-11 07:09:53'),
('c0c004d6-ab3f-47d1-bba0-5c32ceec101f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:54:32', '2020-07-08 07:54:32'),
('c0ce9219-a4dd-4c4f-86b1-b62f72413ea1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:40:08', '2020-07-02 04:40:08'),
('c14ad180-1a97-42fd-8639-b134d78a8c38', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:22:44', '2020-06-29 00:22:44'),
('c195ae52-7ba0-4440-9f10-b63d6c5ea96a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:16', '2020-07-07 07:04:16'),
('c1b66cd5-7752-4469-be4c-9af8e18490a0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:45:02', '2020-06-11 09:45:02'),
('c1e30fb3-bb32-40d4-bc9d-797dde6303b0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:23:06', '2020-06-26 08:23:06'),
('c1f04060-1dc1-4ef9-a59b-83e39541c23e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:52:52', '2020-06-28 06:52:52'),
('c209a7b3-3dca-4398-8145-739f9a318d67', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-04 10:31:43', '2020-07-04 10:31:43'),
('c30939a3-cb29-416b-9bcd-c338251c3d55', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:51:05', '2020-06-28 06:51:05'),
('c31c1e21-c3b8-4cb6-b824-d549c592bb10', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 02:59:13', '2020-06-10 02:59:13'),
('c3b3ba49-a4a7-4406-abe6-f7b3c5405b32', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:05:18', '2020-07-05 08:05:18'),
('c3c78945-c96c-473c-bda8-53855b230441', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 05:00:20', '2020-07-07 05:00:20'),
('c3d283d6-1afe-4eed-882b-82e61c030587', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:25', '2020-06-26 10:05:25'),
('c3dad767-053d-4a2f-953c-471797c252d3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:57:10', '2020-07-08 11:57:10'),
('c3dafc73-01e6-474c-8838-babf6dedffe6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:41', '2020-06-27 04:49:41'),
('c4b00509-9859-4e8f-84b2-29c90c9e18ea', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:36:21', '2020-06-26 10:36:21'),
('c522c1d4-0c65-41ac-b790-e0b10dec789a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:31:40', '2020-07-08 07:31:40'),
('c533cc4f-dda2-490c-a283-6978c60f393a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:11:59', '2020-06-29 00:11:59'),
('c5788ad0-5f82-4814-87ff-985a248664c1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:03', '2020-06-26 10:02:03'),
('c5d773c4-0e3f-44ac-b2dc-ca33ec160273', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 05:00:14', '2020-07-07 05:00:14'),
('c60e05ba-370f-49fa-8240-3e7548d76c84', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:10', '2020-06-26 10:05:10'),
('c65ec983-d026-4ca5-8353-0965d77bc66f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:22:42', '2020-06-29 01:22:42'),
('c68087d2-14d3-4cdf-ad12-26f3e37e835f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:58:15', '2020-07-07 04:58:15'),
('c6c2647d-c65b-44da-9fc2-bdeedcbe0e28', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:40:14', '2020-07-08 09:40:14'),
('c7909964-a39f-43fb-b041-bd47999cc998', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:38', '2020-06-26 10:05:38'),
('c7cec265-091c-4245-b6be-ec3da163389a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:00:33', '2020-06-09 15:00:33'),
('c85a919b-d9c5-4c45-b660-1bdb4906c7dd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:46', '2020-06-26 10:01:46'),
('c88b1837-442d-4543-853c-612cb99f38ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:37:19', '2020-07-08 07:37:19'),
('c89d4ac6-d7e5-48b2-9115-8008146e88d0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:56', '2020-06-26 10:01:56'),
('c8a83e17-a497-47fc-af30-ae529279783a', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-09 20:55:14', '2020-07-09 20:55:14'),
('c8fd27f7-8130-4234-8fb6-363ab4c20779', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:36:33', '2020-07-02 04:36:33'),
('c96558e8-4383-45f1-aa04-ce0494dbf7cd', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:47:13', '2020-07-22 00:47:13'),
('c9a8efcb-3a01-4bda-bf17-4508ef0602f8', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:28:47', '2020-07-20 11:28:47'),
('c9bceade-4b14-47b6-84d4-8e4d5fae41df', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:06', '2020-06-26 08:33:06'),
('c9d2d4e6-b8bd-41b1-a700-05bbb43d277d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:31:06', '2020-07-05 08:31:06'),
('ca3a78f9-38f8-42f0-ac7b-27de32c7bdfb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 07:06:21', '2020-07-09 07:06:21'),
('ca8be333-e027-4211-8e42-82ceb5ae41e8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:25:55', '2020-07-09 08:25:55'),
('ca93bed5-f808-43ac-a672-3b6b68db24a6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:15:15', '2020-07-09 05:15:15'),
('cadb6063-5024-4f30-8f34-9435532d07bd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 12:50:54', '2020-06-17 12:50:54'),
('cb216b56-2046-4362-85fc-91b94290994a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:05:21', '2020-06-26 10:05:21'),
('cb337af5-253d-487d-8d3b-67afaa2f625a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:35:34', '2020-07-06 05:35:34'),
('cb389b1e-329f-40ec-8cd8-5c2d949ec36c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 01:15:58', '2020-06-29 01:15:58'),
('cb614a16-358f-4704-9ecb-b2354bbdedae', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:11', '2020-06-10 14:26:11'),
('cbb5d253-7d5b-4518-92a3-ebf88038b9f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:27:11', '2020-06-11 10:27:11'),
('cc288d45-7464-4791-8056-ac5d89ac5e2c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-22 00:47:16', '2020-07-22 00:47:16'),
('cd72671f-b331-410e-9094-e60b08cd0303', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 06:12:00', '2020-06-30 06:12:00'),
('cda66f29-25ec-4bed-aa28-7dbdcd4dded6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:40:13', '2020-06-26 07:40:13'),
('cdaf6b87-92a3-4b76-a4a1-8c74dfd16770', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:15:33', '2020-07-02 03:15:33'),
('ce485374-8c22-4af3-8c1c-9925738cd9b7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:31:51', '2020-07-08 07:31:51'),
('cecdd709-8404-4282-9d5c-139f3bc252e8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:29:38', '2020-06-10 06:29:38'),
('cf4691f7-1769-4891-9492-c48732462972', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 04:19:54', '2020-06-29 04:19:54'),
('cf74d758-171d-4e41-bc5a-fa962cb33876', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 05:59:56', '2020-07-09 05:59:56'),
('cf99c7dd-0d91-48df-885b-4e145db3228c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:05:12', '2020-07-02 04:05:12'),
('cfb8cb70-9aa5-49e1-8d5a-255ad4ed3a7c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:08:05', '2020-06-26 08:08:05'),
('cfebc215-24ee-493a-9fa6-9f035baa5ae6', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:52', '2020-06-28 03:41:52'),
('cff44a4c-3d39-4977-b80d-249e0bd572d4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:26:50', '2020-06-26 12:26:50'),
('d040fdf8-8db3-4f5b-b327-697035a90c18', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:07:42', '2020-06-26 12:07:42'),
('d0ea30c4-45a4-4705-a1d0-f250ed4901c9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:27:46', '2020-07-08 12:27:46'),
('d11aa3fb-3768-4421-a54c-382422bdf95b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 09:08:59', '2020-06-12 09:08:59'),
('d191137f-7c15-4ef2-87a7-3f4df64b318f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:03:44', '2020-06-26 12:03:44'),
('d23638d4-35c5-4dac-b394-636dc9458b3f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:14:30', '2020-06-26 12:14:30'),
('d28277aa-25b1-4a2f-874f-5ecc94383922', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:04:58', '2020-06-26 10:04:58'),
('d2a0ed3e-9f43-4943-a6e1-e376f4f80bad', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:24', '2020-06-26 08:31:24'),
('d383c5e3-4b93-4632-9a05-31f2f919f898', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:23:09', '2020-06-26 08:23:09'),
('d3d22b8a-09e7-427c-b5eb-9e7d47bbb047', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:11:33', '2020-06-29 01:11:33'),
('d3f37feb-40fa-442a-b7b5-5674dd87e20b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:25', '2020-06-26 08:34:25'),
('d3fc14ae-a2db-4dc7-bbf3-55d365d13d2b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:04:13', '2020-06-12 08:04:13'),
('d418db95-e463-4eb2-8e7a-de4085c7f199', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 06:31:56', '2020-07-06 06:31:56'),
('d4a95803-d78b-445d-9c9e-7ce395c840ef', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 10:01:34', '2020-06-12 10:01:34'),
('d4afde08-d9cb-42f9-a6cf-2d59ce6fb5e5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:26', '2020-06-26 08:29:26'),
('d4b25024-1957-4093-b593-e902c11d434b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:13:52', '2020-06-09 15:13:52'),
('d513ba17-54e7-437d-bdb4-4b79b02c43f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:44', '2020-06-26 10:03:44'),
('d63420f3-facf-4373-8a0d-86840e038809', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-27 05:35:43', '2020-06-27 05:35:43'),
('d65028d3-4501-4502-8ab1-3937e7e1534a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:46:51', '2020-06-26 06:46:51'),
('d6537ace-808d-4b1f-8df7-91839d2b39a2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:28', '2020-06-26 08:09:28'),
('d6a3939b-d19e-4684-9b76-d7453c3cdf03', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:51:15', '2020-06-26 07:51:15'),
('d6c33074-bb63-470e-9c7e-1e4dd46f6494', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:35', '2020-06-26 10:06:35'),
('d6e6ec62-b418-47a9-8897-797b4da68a05', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 09:11:15', '2020-07-07 09:11:15'),
('d74b503d-84c6-4c48-ac60-ed0c0db82365', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-27 05:35:38', '2020-06-27 05:35:38'),
('d7cb9911-763f-4084-9026-bb22b736198e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:01:28', '2020-07-09 04:01:28'),
('d7e6b0d0-ac6b-4c27-b8dc-be61dca2b577', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:51:10', '2020-06-26 07:51:10'),
('d7f7d3cb-44e0-4a15-ae05-cdf5c9228e5c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:40:24', '2020-07-08 09:40:24'),
('d7f926dd-99f4-463b-9b19-edc33c6f85e8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:14:31', '2020-06-26 06:14:31'),
('d85b5b47-9e30-46ee-9b9d-8de48f62a063', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:05:02', '2020-07-07 07:05:02'),
('d874d5b6-e453-4dcd-ae44-adf79e931efb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:29:44', '2020-06-10 06:29:44'),
('d89d2097-73d7-4d3d-95c0-0eb384b6d396', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:59:31', '2020-07-08 11:59:31'),
('d8f3010d-a111-4261-a7d1-ed283e7825bc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:17:15', '2020-06-26 08:17:15'),
('d93df780-ffd8-47aa-bbf8-79852625575f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 05:46:34', '2020-06-28 05:46:34'),
('d94d5d94-ac06-4152-8218-76ccb790a81d', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:36:51', '2020-06-29 01:36:51'),
('d9e64850-e1f5-48d9-bdc5-2e7370c88273', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:00:29', '2020-06-30 10:00:29'),
('da0b67c6-0098-47ae-9ead-a738e033c7a3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:22:49', '2020-06-29 00:22:49'),
('da20bc1e-45fe-4419-a3b3-aed6542080c7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:30:41', '2020-06-30 08:30:41'),
('da99a7a1-ab7b-4544-93a5-44f40549cffd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 04:49:13', '2020-06-27 04:49:13'),
('db10f63c-9e0d-4c25-9434-ce2614656086', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:05', '2020-06-26 10:03:05'),
('db16efd3-cbd2-4e04-a62e-fb1abfd0df32', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 05:00:31', '2020-07-07 05:00:31'),
('db897d55-ead8-4add-93ec-475bf21e8d20', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:37:47', '2020-07-02 04:37:47'),
('db959684-1c03-413f-ab94-2763dfadde43', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:09:17', '2020-06-26 08:09:17'),
('dc14a65d-6973-4cb9-9cab-d55ec46ceebc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:51:19', '2020-07-08 09:51:19'),
('dca75e62-4060-4eae-a776-6ee34b0fb880', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:15:22', '2020-07-08 08:15:22'),
('dcb53342-4e59-4525-8e42-83c371c0cedc', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:44:58', '2020-06-26 09:44:58'),
('dd52f54b-96f3-4475-bb3d-af073b899255', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 11:59:00', '2020-06-26 11:59:00'),
('dd8e78c5-2978-4e81-ad22-2b45f70d3b24', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:31', '2020-06-28 03:41:31'),
('ddc345c9-6e54-4ed4-a0cd-886f0937b389', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:44:30', '2020-07-09 08:44:30'),
('ddda2b10-759f-456e-8452-878f3805b301', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:52:14', '2020-06-26 07:52:14'),
('deb8c619-f221-42d1-8f58-dbf9a14180fb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:55:28', '2020-06-26 06:55:28'),
('dedd5414-80d4-47ee-b11d-c268aa9400bc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:52:05', '2020-07-09 08:52:05'),
('df5626c8-7e75-41a4-b88e-db8a6588bdff', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:33:48', '2020-06-28 05:33:48'),
('df5b6e26-2f7b-4847-83da-edf2d4933b45', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 09:45:15', '2020-06-11 09:45:15'),
('df8cb133-5607-4669-b8b3-2dbc34740046', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:21:55', '2020-06-26 11:21:55'),
('dfa67d37-128a-46b1-b6c4-4a25a9fce141', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:19', '2020-06-09 15:06:19'),
('e0d883b4-8ec0-44b7-a2a3-1d66428dbc8b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:28:51', '2020-07-20 11:28:51'),
('e17a1fae-de60-421e-93dc-7339d01581cc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 09:11:21', '2020-07-07 09:11:21'),
('e1c7a56c-e99e-4360-a10a-7663d434292d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:02:15', '2020-06-26 09:02:15'),
('e1d3646a-bb9d-4775-8303-0c5a9a80b3ab', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 07:09:57', '2020-06-10 07:09:57'),
('e1ee6d57-7048-45f3-9f3f-0e306e43ed58', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:22:21', '2020-07-20 11:22:21'),
('e23ddc6b-184c-44ce-8d45-59e97fb8bd0c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 04:16:54', '2020-07-07 04:16:54'),
('e27d58aa-4794-45d5-80e3-f8a9039b37ce', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:29:19', '2020-06-26 10:29:19'),
('e28c8445-b901-4873-bf27-f0d9ee33c37f', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:59:47', '2020-06-29 00:59:47'),
('e2c711db-33e5-4491-93f0-600730dcb698', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:08:29', '2020-07-03 06:08:29'),
('e3084183-8b48-4095-afd7-4e04fad82098', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:15:38', '2020-07-02 03:15:38'),
('e3263328-7026-4957-9e3d-1649f415a009', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:11:28', '2020-07-03 06:11:28'),
('e3657d6a-1a43-4099-b8fe-30f98038f61a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:59:06', '2020-06-26 06:59:06'),
('e3db4346-24d6-4ddd-9314-7ec5137739de', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:37:54', '2020-07-02 04:37:54'),
('e3eb397e-334c-4c50-bb98-0aed3cff5c53', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-01 13:06:00', '2020-07-01 13:06:00'),
('e49036ae-cd8e-4c45-94da-637e3f7ed068', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:08', '2020-06-26 10:01:08'),
('e4d563ba-623f-4921-9c17-6d73d2f542da', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:34', '2020-06-29 00:15:34'),
('e4eec8f6-45ba-459b-8e35-01172bbe1ab9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 12:35:08', '2020-06-11 12:35:08'),
('e52814b6-d594-4a01-93d2-f1a8963dbada', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:26:55', '2020-06-17 05:26:55'),
('e541bfd2-c84f-443c-b5ce-8210bb17e6f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:09:32', '2020-06-10 06:09:32'),
('e568fda5-b413-4308-bcce-0272699dbbd8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:15:19', '2020-07-09 05:15:19'),
('e58151fe-ccde-4120-82bf-d962bf3c15e3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 09:53:12', '2020-06-30 09:53:12'),
('e5e913b4-7fd7-4da5-89d0-3559d852d3da', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-09 14:14:35', '2020-06-09 14:14:35'),
('e6109d81-5366-4471-94f1-28857faacc55', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:08:49', '2020-06-29 00:08:49'),
('e6b230d3-913b-4f05-b86a-df26c459e681', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:25:34', '2020-06-28 05:25:34'),
('e6c4c0a2-a2c7-4ede-9b4b-c1bb936bbe49', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:35:49', '2020-06-26 12:35:49'),
('e6f7e2ac-46bd-45f7-9684-25af4c43b15f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-09 15:06:15', '2020-06-09 15:06:15');
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('e6fb3e59-de84-40d3-b1e3-3be23469d064', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 04:57:41', '2020-07-03 04:57:41'),
('e6fb54c7-f82f-46b6-9cd7-e934990cfc34', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:34:39', '2020-06-29 01:34:39'),
('e740689d-3deb-4754-9061-1cc26b704676', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:20:09', '2020-06-26 08:20:09'),
('e79aec50-9d22-43ae-8166-a29bf28210b2', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 05:23:25', '2020-07-03 05:23:25'),
('e7e79af1-9b54-4c8e-be5d-819444347e52', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:52:37', '2020-07-08 07:52:37'),
('e82d4a0f-4b8d-4242-82d4-9bb325f3a467', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:29:17', '2020-06-26 08:29:17'),
('e87ce440-e2c6-4449-b899-15baafcd97dd', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:42', '2020-06-28 05:27:42'),
('e8803e65-c6ac-451c-b4fd-1bb84f1b31d7', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:05:25', '2020-07-05 08:05:25'),
('e8d56908-8706-45ab-9524-82b259d4a787', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 12:50:37', '2020-06-28 12:50:37'),
('e8f804eb-d28c-4bad-a23c-4b37bebe754d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 07:04:45', '2020-07-07 07:04:45'),
('e94da1b3-23d2-4e18-a236-85787620e6cd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-12 08:02:40', '2020-06-12 08:02:40'),
('e97da3b1-a28a-43e0-84ed-a890e68bf5be', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:27:25', '2020-07-09 08:27:25'),
('e9965cec-7876-4ffe-9d1a-7a1f600b2b22', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 09:39:33', '2020-06-26 09:39:33'),
('e9a701bc-2968-44f3-ba68-2535561468aa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:56:59', '2020-06-26 12:56:59'),
('e9b61d72-fce0-4b31-814f-890dbd643e71', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:46:18', '2020-07-09 08:46:18'),
('ea8575e2-3ccd-4cdf-8fa7-db8eb09824c9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 05:41:51', '2020-07-09 05:41:51'),
('eacc3335-e08a-4395-b412-96f4c0e4404e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:54:22', '2020-06-26 07:54:22'),
('eb93cb5f-155b-4bcf-8918-7a1f444cf59f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-07 06:53:23', '2020-07-07 06:53:23'),
('ec990218-9dad-4e45-82be-be239b3f3644', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 07:18:33', '2020-06-30 07:18:33'),
('ecd11230-9c87-45e1-b610-4113c2c13dfb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:30', '2020-06-26 10:06:30'),
('ed45af85-adac-4052-948b-2fe28cae7964', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 12:50:50', '2020-06-17 12:50:50'),
('ed5599ac-a3a9-4fa8-bc6f-fdc3762e86c8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-17 05:28:58', '2020-06-17 05:28:58'),
('ed5c8f24-aee3-43fc-95d2-81f4dc3e3f7c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-30 05:16:45', '2020-06-30 05:16:45'),
('ed601e26-d7f9-42a2-a9dd-d34ed6810465', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 05:22:11', '2020-07-02 05:22:11'),
('ed751951-8305-4f24-b514-df1e6bcfa4ed', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:40:23', '2020-06-26 07:40:23'),
('edba0180-350e-4513-a649-8e704d811d33', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:13:05', '2020-06-11 10:13:05'),
('edc90966-36b0-4db0-82b4-7c99f93c51cd', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:19:59', '2020-06-26 08:19:59'),
('ee13fe7f-d91b-4fdf-9e11-c3b84d5a0f4b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-29 06:36:38', '2020-06-29 06:36:38'),
('ee71e777-d91c-4d7e-84ab-5b3e3524a2c9', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:37', '2020-06-28 03:41:37'),
('ee75f585-2fe6-4073-a12f-0dd68676833d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:01:24', '2020-07-09 04:01:24'),
('ee90791e-7970-4d6b-9404-8c4ffe9c44ec', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:07:49', '2020-06-26 12:07:49'),
('ee9117d0-6a67-4dbd-8299-810a56afba01', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:37:06', '2020-06-26 10:37:06'),
('ef5a85c8-8656-46e9-baaf-1dbb9ef9bd19', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:23:06', '2020-07-08 12:23:06'),
('ef6af26e-d1e7-4b50-a5ae-5cdab4e5671b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:22:39', '2020-06-29 00:22:39'),
('ef6cd0ea-6dff-4678-8b91-ba09df11ab8d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:02:41', '2020-07-08 11:02:41'),
('ef90b6d0-1e49-472b-90b7-ff9953d33cf4', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:02:21', '2020-06-26 10:02:21'),
('ef938896-1add-4435-8092-46cc7d1b3a76', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:23:31', '2020-06-26 11:23:31'),
('efb4759b-a18c-473d-ac1a-49aecf99e550', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:33:18', '2020-06-26 08:33:18'),
('efd62d23-77ba-439e-bb60-e3c313d500c9', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:44:31', '2020-06-26 06:44:31'),
('f052dd79-5566-4367-8481-b53c9cfaa63c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:26', '2020-06-26 10:01:26'),
('f0874d54-b3cb-4179-a409-0bc9137e08aa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 07:52:27', '2020-07-08 07:52:27'),
('f0e2ec46-874d-4632-915a-36d947de36aa', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 12:19:40', '2020-07-08 12:19:40'),
('f0f1b181-11c4-4d3c-8c2f-ef860bb4ca3e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 03:49:55', '2020-07-02 03:49:55'),
('f1201d0d-f7e4-4967-b47b-c168dacb27fc', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 06:53:33', '2020-06-28 06:53:33'),
('f1577116-51c5-42c2-afc0-a2542c17032c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 07:08:21', '2020-06-30 07:08:21'),
('f1c22010-a704-4ab5-9f8a-04354ca742b3', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 03:41:46', '2020-06-28 03:41:46'),
('f1da405f-2ab3-44b2-83e3-f5eee5a16aa8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 12:42:22', '2020-06-28 12:42:22'),
('f2097cd9-30cd-4efb-b240-c05e9ac7cc79', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-12 08:27:12', '2020-06-12 08:27:12'),
('f21b83ff-876a-4512-9459-78106885d919', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-02 04:23:55', '2020-07-02 04:23:55'),
('f2ad5f0a-c127-45e9-9701-c6f588ee5e9b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 06:31:46', '2020-07-06 06:31:46'),
('f2dbb360-457c-40cc-8a98-25881f8fc9fc', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 08:15:09', '2020-07-08 08:15:09'),
('f3142040-2a6d-4fd7-825b-d63f3b1c9bda', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 2, '[]', NULL, '2020-06-28 08:38:11', '2020-06-28 08:38:11'),
('f3437a8c-8a51-4601-b5be-501f8addacea', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:40', '2020-06-29 01:27:40'),
('f3c54e73-e110-42cd-8dde-d489c719af2e', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 00:15:53', '2020-06-29 00:15:53'),
('f4502988-4769-4097-958c-fce5c621655b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 09:57:10', '2020-06-26 09:57:10'),
('f4d69d3b-28e3-4a20-a9db-75be5708cbf5', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 10:30:03', '2020-06-26 10:30:03'),
('f50a3266-6f9f-44ec-8c52-3f8ba3cbd73c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 05:03:10', '2020-07-06 05:03:10'),
('f5153e32-2c8f-411c-9a19-885c90301950', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 04:44:34', '2020-06-29 04:44:34'),
('f52ccb88-d3fd-467d-a619-5dcec35ca2c3', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:49:35', '2020-06-26 07:49:35'),
('f570da3f-a99d-48b2-b93f-8ca113d9662a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-03 06:08:23', '2020-07-03 06:08:23'),
('f57791d1-b07b-45ae-b1ed-26a501327d91', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:54:18', '2020-06-26 07:54:18'),
('f5d67985-8e34-4103-9627-1e56d2f6c97a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 06:09:32', '2020-06-27 06:09:32'),
('f61ff414-87c6-41c1-bc5b-53b29737a24c', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 11:21:50', '2020-06-26 11:21:50'),
('f687a4a1-090b-4c7f-912f-6897398946ee', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-28 03:40:04', '2020-06-28 03:40:04'),
('f6aa09a0-5aaa-4453-a084-ae6a514a0b09', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:42:28', '2020-06-28 05:42:28'),
('f795f9ca-a5c2-4c3d-aac4-b848620952a8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:27', '2020-06-26 10:03:27'),
('f797ec14-22f6-47f3-9758-fa9ea241a99a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-27 05:45:18', '2020-06-27 05:45:18'),
('f7abee7c-bf8a-4244-b8e7-0619122d8a7c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:26:00', '2020-07-09 08:26:00'),
('f7c1698b-f088-4ee2-a6e6-dff51a048210', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:09:31', '2020-07-08 11:09:31'),
('f81e7b89-d9c9-4802-8c93-187ebb79092f', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:01:52', '2020-06-26 10:01:52'),
('f84ad4f7-7c5b-4cbd-9b88-23df00315f54', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:03:26', '2020-06-26 08:03:26'),
('f86cfe87-ee40-45ae-ac43-5c6a476634b0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:16:59', '2020-06-26 08:16:59'),
('f8987dc2-86b0-4539-8c39-95b0d0244bbf', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 11:08:19', '2020-07-08 11:08:19'),
('f8b9008d-8ec6-4dc0-887d-264103893b14', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:37:16', '2020-06-26 08:37:16'),
('f8d42ad2-3322-4ccc-84d6-29562b2beb7b', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-29 01:27:36', '2020-06-29 01:27:36'),
('f9057fa9-8a85-4be4-9de2-a2fecfe85e2c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-11 10:56:38', '2020-06-11 10:56:38'),
('f914dbb4-fd82-42a2-993c-11e9432a42ca', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 10:10:40', '2020-06-30 10:10:40'),
('f91588e6-fe82-41ac-ad8d-86c45e0c3de1', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:52:25', '2020-06-26 06:52:25'),
('f93e0578-fb12-4dc1-9eec-44916fb79e27', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:39', '2020-06-26 10:03:39'),
('f948767d-99a0-4457-9b43-4a70c78daced', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-28 05:27:27', '2020-06-28 05:27:27'),
('f959e382-2e9b-43b5-8927-f442bb408496', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:41:40', '2020-07-09 08:41:40'),
('f99345b3-fb3e-4e9b-a86e-f1ce688bd220', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 08:44:34', '2020-07-09 08:44:34'),
('f9cdf0ba-bd99-415d-9341-e8347369874c', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:34:29', '2020-06-26 08:34:29'),
('f9fa8891-b22a-4049-af28-c70e8e1f56e5', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 12:05:53', '2020-06-26 12:05:53'),
('fa1f91ab-24b0-4acb-b492-943c871f8e6a', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:44:36', '2020-06-26 06:44:36'),
('fa202c5e-08ee-42c4-b70e-713afd56cfc8', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:44', '2020-06-26 10:06:44'),
('fad58dd4-4845-4f4e-b9cb-c3d91cff75f0', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 06:55:23', '2020-06-26 06:55:23'),
('fb2ed9b8-1e98-4eeb-85d8-3c3b5aa9df0d', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 3, '[]', NULL, '2020-06-17 04:53:16', '2020-06-17 04:53:16'),
('fb5b4d18-de20-49b4-9a84-037535b44cfb', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-05 08:05:13', '2020-07-05 08:05:13'),
('fb5e4e0d-c8fc-4ecf-98ea-dd4dece49ec6', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-07-20 11:25:11', '2020-07-20 11:25:11'),
('fc5aca80-1a6c-4799-afdc-e699ae6fad47', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 6, '[]', NULL, '2020-07-09 05:51:56', '2020-07-09 05:51:56'),
('fcf1c2e0-6770-4768-acea-5aab75462b26', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-08 09:40:31', '2020-07-08 09:40:31'),
('fcfce3ea-11dc-446f-b066-b5393a95fd35', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 7, '[]', NULL, '2020-06-18 03:30:55', '2020-06-18 03:30:55'),
('fd515fee-4acb-4dba-aebb-85f29a790e19', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 07:56:03', '2020-06-26 07:56:03'),
('fd6591ab-c32b-4f4d-9161-9c89fafa69cf', 'App\\Notifications\\KissingerNotifications', 'App\\User', 1, '[]', NULL, '2020-06-26 07:16:32', '2020-06-26 07:16:32'),
('fdb422ec-2222-48df-9b5b-aeca3f43d1e6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:03:17', '2020-06-26 10:03:17'),
('fdb665b2-2796-475f-a0c0-3a6e0f941ebe', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 10:06:02', '2020-06-26 10:06:02'),
('ff0496cb-d91a-4484-9bcd-6cd34965c78e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-26 08:31:20', '2020-06-26 08:31:20'),
('ff18ac6c-b49e-427c-9069-104f1094f55e', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-30 08:00:09', '2020-06-30 08:00:09'),
('ff503872-e42d-414a-ab48-a4186609827b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-06 07:49:16', '2020-07-06 07:49:16'),
('ff70551e-2e38-4781-81b4-2701b3164f18', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 06:30:52', '2020-06-10 06:30:52'),
('ffdbdfe3-8dd7-4e45-9663-7e5b420ffe6b', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-06-10 14:26:00', '2020-06-10 14:26:00'),
('ffdceadb-2f89-4a22-81c4-6d582140cea6', 'App\\Notifications\\KissingerNotifications', 'App\\Configuration', 1, '[]', NULL, '2020-07-09 04:01:33', '2020-07-09 04:01:33');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', NULL, NULL),
(2, 'customer', 'customer', NULL, NULL),
(3, 'superadmin', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(5, 'admin', 'admin', '2020-03-06 23:44:19', '2020-03-06 23:44:19'),
(6, 'user', 'user', '2020-03-06 23:46:40', '2020-03-06 23:46:40'),
(7, 'superadmin', 'superadmin', '2020-03-06 23:46:40', '2020-03-06 23:46:40');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `new_account_user_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `username`, `password`, `role_id`, `created_by`, `new_account_user_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'superadmin@kissingersolutions.com', NULL, '', '$2y$10$D8rNY6qCgjTjo5Zkae9aje57v9Mr2dQ4jO0MT6b4OoDwSRpr4Td/m', 7, 1, NULL, 1, 'tIiPvtoSXPfF9kC9HwCO9fTfhhKfyTQhIAaXRi1BLXckQdV13Pz5sFzL2FOV', '2020-03-15 02:00:00', '2020-03-16 02:00:00'),
(88, 'abhimanyu', 'abhimanyur@chetu.com', NULL, NULL, '$2y$10$RknhaCy7FcKRJOS2RvJhRue6KmNBsAt1F3xEO9yfH2UGeTsxcwjAq', 5, NULL, '9,10', 0, NULL, '2020-06-08 05:23:49', '2020-06-22 12:20:41'),
(91, 'shilpi', 'shilpi@chetu.com', NULL, NULL, '$2y$10$l5s80AdxLL9wxV4SyJadKO1w9W2QvcCezCCKieTpWdmRyLzM8rCbO', 5, NULL, '10', 0, NULL, '2020-06-08 05:50:21', '2020-06-10 03:52:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `configurations`
--
ALTER TABLE `configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `configure_parameters`
--
ALTER TABLE `configure_parameters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kaiconnection_with_accounts`
--
ALTER TABLE `kaiconnection_with_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kai_audits`
--
ALTER TABLE `kai_audits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kai_connection_statuses`
--
ALTER TABLE `kai_connection_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `new_accounts`
--
ALTER TABLE `new_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_notifications`
--
ALTER TABLE `new_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `configurations`
--
ALTER TABLE `configurations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `configure_parameters`
--
ALTER TABLE `configure_parameters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kaiconnection_with_accounts`
--
ALTER TABLE `kaiconnection_with_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `kai_audits`
--
ALTER TABLE `kai_audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kai_connection_statuses`
--
ALTER TABLE `kai_connection_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `new_accounts`
--
ALTER TABLE `new_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `new_notifications`
--
ALTER TABLE `new_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
